import React,{useEffect,useMemo,useState} from "react";
import { Link,useNavigate } from "react-router-dom";
import { ArrowLeft,Plus,MapPin,Phone,Mail,Globe,Flag,Save,Sun } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import CourseCard from "@/components/courses/CourseCard";
import CourseSetupEditor from "@/components/CourseSetupEditor";
import CourseCatalogImport from "@/components/CourseCatalogImport";
const BLANK={name:"",location:"",country:"Australia",holes:18,par:72,phone:"",email:"",club_hire:"",carts:"",membership:"",pro_shop:"",resident_pro:"",overview:"",website:""};
const FIELDS=[["name","Club name"],["location","Town / region"],["country","Country"],["holes","Holes"],["par","Course par"],["phone","Phone"],["email","Email"],["website","Website"],["club_hire","Club hire"],["carts","Carts"],["membership","Membership"],["pro_shop","Pro shop"],["resident_pro","Resident pro"],["overview","Overview"]];
export default function CourseLibrary(){
 const navigate=useNavigate(),{toast}=useToast();
 const [glare,setGlare]=useState(()=>{try{return !!JSON.parse(localStorage.getItem("drc-tourbillion-v1")||"{}").glare;}catch{return false;}});
 const toggleGlare=()=>setGlare(value=>{const next=!value;try{const saved=JSON.parse(localStorage.getItem("drc-tourbillion-v1")||"{}");localStorage.setItem("drc-tourbillion-v1",JSON.stringify({...saved,glare:next}));}catch{localStorage.setItem("drc-tourbillion-v1",JSON.stringify({glare:next}));}return next;});
 const [courses,setCourses]=useState([]),[personal,setPersonal]=useState([]),[loading,setLoading]=useState(true),[query,setQuery]=useState(""),[editing,setEditing]=useState(null),[form,setForm]=useState(BLANK),[saving,setSaving]=useState(false),[selected,setSelected]=useState(null),[setupCourse,setSetupCourse]=useState(null);
 useEffect(()=>{let active=true;Promise.all([base44.entities.Course.list("name",500),base44.auth.me().then(me=>base44.entities.PersonalCourse.filter({created_by_id:me.id},"name",500))]).then(([library,mine])=>{if(active){setCourses(library);setPersonal(mine);setLoading(false);}}).catch(()=>{if(active){setLoading(false);toast({title:"Could not load courses",variant:"destructive"});}});return()=>{active=false;};},[]);
 const all=useMemo(()=>[...personal.map(c=>({...c,_personal:true})),...courses], [personal,courses]);
 const shown=all.filter(c=>(c.name+" "+(c.location||"")).toLowerCase().includes(query.toLowerCase()));
 const edit=c=>{setEditing(c?.id||"new");setForm(c?FIELDS.reduce((a,[key])=>({...a,[key]:c[key]??BLANK[key]}),{}):BLANK);};
 const save=async()=>{if(!form.name.trim()){toast({title:"Enter the club name",variant:"destructive"});return;}
  const holeCount=Number(form.holes),coursePar=Number(form.par);
  if(!Number.isInteger(holeCount)||holeCount<1||holeCount>36||!Number.isInteger(coursePar)||coursePar<holeCount*3||coursePar>holeCount*6){toast({title:"Check holes and par",description:"Enter 1–36 holes and a course par of 3–6 per hole.",variant:"destructive"});return;}
  setSaving(true);try{const payload={...form,name:form.name.trim(),holes:holeCount,par:coursePar};
   const item=editing==="new"?await base44.entities.PersonalCourse.create(payload):await base44.entities.PersonalCourse.update(editing,payload);
   setPersonal(old=>editing==="new"?[item,...old]:old.map(c=>c.id===editing?item:c));setEditing(null);setSelected(item.id);toast({title:"Course saved"});
  }catch{toast({title:"Could not save course",variant:"destructive"});}finally{setSaving(false);}};
 return <div className={"tour-shell "+(glare?"anti-glare":"")}><header className="tour-top"><Link to="/"><ArrowLeft size={20}/></Link><div><span className="tour-kicker">DRC GOLF TOURBILLION</span><h1>COURSES</h1><small>Your club directory</small></div><button onClick={toggleGlare} aria-label="Toggle anti-glare" aria-pressed={glare}><Sun size={20}/></button></header><main className="tour-body">
 <div className="tour-row spread"><p>{loading?"Loading…":all.length+" courses"}</p><button className="tour-button" onClick={()=>edit(null)}><Plus size={16}/> ADD CLUB</button></div>
 {editing&&<section className="tour-card"><h2>{editing==="new"?"Add your course":"Edit your course"}</h2><p>Your details are private to your account.</p><div className="course-form">{FIELDS.map(([key,label])=><label key={key}>{label}{key==="overview"?<textarea value={form[key]} onChange={e=>setForm(v=>({...v,[key]:e.target.value}))}/>:<input type={["holes","par"].includes(key)?"number":"text"} value={form[key]} onChange={e=>setForm(v=>({...v,[key]:e.target.value}))}/>}</label>)}</div><div className="tour-row"><button className="tour-button gold-action" disabled={saving} onClick={save}><Save size={15}/> SAVE COURSE</button><button className="tour-button" onClick={()=>setEditing(null)}>CANCEL</button></div></section>}
 <CourseCatalogImport onImported={item=>{setPersonal(old=>old.some(c=>c.id===item.id)?old:[item,...old]);setSelected(item.id);}}/>
 <input aria-label="Search courses" placeholder="Search saved course or town" value={query} onChange={e=>setQuery(e.target.value)}/>
 <div className="course-list">{shown.map((course,i)=><div key={(course._personal?"personal":"library")+course.id}>
 <button className="course-select" onClick={()=>setSelected(selected===course.id?null:course.id)} aria-expanded={selected===course.id}><CourseCard course={course} index={i}/></button>
 {selected===course.id&&<section className="tour-card course-details"><h2>{course.name}</h2><p><MapPin size={15}/> {[course.location,course.country].filter(Boolean).join(", ")}</p><p><Flag size={15}/> {course.holes||18} holes · Par {course.par||72}</p>{course.overview&&<p>{course.overview}</p>}{course.notes&&<p>{course.notes}</p>}{course.phone&&<p><Phone size={15}/> <a href={"tel:"+course.phone}>{course.phone}</a></p>}{course.email&&<p><Mail size={15}/> <a href={"mailto:"+course.email}>{course.email}</a></p>}{course.website&&<p><Globe size={15}/> <a href={course.website} target="_blank" rel="noreferrer">{course.website}</a></p>}{course.source_url&&<p><Globe size={15}/> <a href={course.source_url} target="_blank" rel="noreferrer">COURSE SOURCE / SCORECARD ↗</a></p>}
 {["club_hire","carts","membership","pro_shop","resident_pro"].map(key=>course[key]&&<p key={key}><strong>{key.replaceAll("_"," ")}:</strong> {course[key]}</p>)}
 <div className="tour-row"><button className="tour-button gold-action" onClick={()=>navigate("/?course="+encodeURIComponent(course.id))}>START ROUND</button><button className="tour-button" onClick={()=>setSetupCourse(course)}>EDIT HOLES</button>{course._personal&&<button className="tour-button" onClick={()=>edit(course)}>EDIT CLUB</button>}</div>
 </section>}</div>)}</div>{setupCourse&&<CourseSetupEditor key={setupCourse.id} course={setupCourse} onClose={()=>setSetupCourse(null)}/>} {!loading&&shown.length===0&&<p className="tour-card">No matching courses. Add your club above.</p>}</main><nav className="tour-nav"><Link to="/">HOME</Link><Link to="/courses">COURSES</Link><Link to="/bag">BAG</Link><Link to="/records">RECORDS</Link><Link to="/tools">MORE</Link></nav></div>;
}
