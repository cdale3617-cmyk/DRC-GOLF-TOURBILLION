import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, UserRound } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function Profile() {
  const [user, setUser] = useState(null);
  useEffect(() => { let active = true; base44.auth.me().then(me => { if(active) setUser(me); }); return () => { active=false; }; }, []);
  return <main className="min-h-screen bg-[#071b14] px-4 py-5 text-[#f4ead0]">
    <div className="mx-auto max-w-xl">
      <Link to="/" className="mb-5 inline-flex items-center gap-2 text-sm text-[#d8bd77]"><ArrowLeft size={18}/> Home</Link>
      <div className="rounded-2xl border border-[#b69a59] bg-gradient-to-br from-[#19543a] to-[#08271b] p-6 shadow-xl">
        <UserRound className="mb-4 text-[#e1c47c]" size={42}/>
        <h1 className="font-display text-2xl">Profile</h1>
        <p className="mt-4 text-lg">{user?.full_name || "Your account"}</p>
        {user?.email && <p className="mt-1 text-sm text-[#c5cbbd]">{user.email}</p>}
      </div>
      <div className="mt-5 grid grid-cols-2 gap-3">
        <Link to="/bag" className="rounded-xl border border-[#9a824a] bg-[#103b29] p-4">My Bag</Link>
        <Link to="/records" className="rounded-xl border border-[#9a824a] bg-[#103b29] p-4">My Records</Link>
      </div>
    </div>
  </main>;
}