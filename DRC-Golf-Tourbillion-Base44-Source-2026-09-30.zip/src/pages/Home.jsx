import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { BriefcaseBusiness, MapPin, History, Flag, Menu, Sun, RotateCcw, ChevronRight } from "lucide-react";
import HomeTileArt from "@/components/home/HomeTileArt";
import HomeScene from "@/components/home/HomeScene";
import "./Home3D.css";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import NewRoundDialog from "@/components/home/NewRoundDialog";

export default function Home() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [user, setUser] = useState(null);
  const [courses, setCourses] = useState([]);
  const [resumeRound, setResumeRound] = useState(null);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    let active = true;

    const load = async () => {
      const me = await base44.auth.me();
      const [courseList, myCourses, rounds] = await Promise.all([
        base44.entities.Course.list("name", 500),
        base44.entities.PersonalCourse.filter({created_by_id:me.id},"name",500).catch(()=>[]),
        base44.entities.Round.filter(
          { created_by_id: me.id, status: "in_progress" },
          "-updated_date",
          1
        ),
      ]);
      if (!active) return;
      setUser(me);
      const combined=[...myCourses,...courseList];
      setCourses(combined);
      const requested=new URLSearchParams(window.location.search).get("course");
      const match=combined.find(c=>c.id===requested);
      if(match){setSelectedCourse(match);setDialogOpen(true);window.history.replaceState({},"",window.location.pathname);}
      setResumeRound(rounds[0] || null);
      setLoading(false);
    };

    load().catch(()=>{if(active){setLoading(false);toast({title:"Could not load Home",variant:"destructive"});}});
    return () => {
      active = false;
    };
  }, []);

  const openRoundDialog = (course) => {
    setSelectedCourse(course || null);
    setDialogOpen(true);
  };

  const handleStartRound = async ({ course, players }) => {
    setSubmitting(true);
    try {
      const setup = await base44.entities.CourseSetup.filter({course_id:course.id,created_by_id:user.id},"-updated_date",1).catch(()=>[]);
      const round = await base44.entities.Round.create({
        hole_pars: setup[0]?.hole_pars?.length ? setup[0].hole_pars : (course.hole_pars || []),
        hole_distances: setup[0]?.hole_distances?.length ? setup[0].hole_distances : (course.hole_distances || []),
        hole_greens: setup[0]?.hole_greens || [],
        course_id: course.id,
        course_name: course.name,
        course_location: course.location,
        holes: course.holes || 18,
        par: course.par || 72,
        players:players.length?players:[user.full_name||"Player"],
        status: "in_progress",
        started_at: new Date().toISOString(),
      });
      setDialogOpen(false);
      navigate(`/round/${round.id}`);
    } catch (error) {
      toast({
        title: "Couldn't start the round",
        description: "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const rawName = user?.full_name?.trim().split(/\s+/)[0] || "Golfer";
  const firstName = rawName.charAt(0).toUpperCase() + rawName.slice(1);
  const cards = [
    { title: "My Bag", detail: "Clubs & carry", to: "/bag" },
    { title: "Courses", detail: "Your courses", to: "/courses" },
    { title: "Golf Lab", detail: "Practice tools", to: "/tools" },
    { title: "Records", detail: "Rounds & stats", to: "/records" },
    { title: "Scorecard", detail: resumeRound ? "Current round" : "Past cards", action: () => navigate(resumeRound ? `/round/${resumeRound.id}/card` : "/records") },
    { title: "Profile", detail: "Your account", to: "/profile" },
  ];
  const [glare, setGlare] = useState(() => { try { return !!JSON.parse(localStorage.getItem("drc-tourbillion-v1") || "{}").glare; } catch { return false; } });
  const toggleGlare = () => { const next = !glare; setGlare(next); try { const saved=JSON.parse(localStorage.getItem("drc-tourbillion-v1") || "{}"); localStorage.setItem("drc-tourbillion-v1",JSON.stringify({...saved,glare:next})); } catch { localStorage.setItem("drc-tourbillion-v1",JSON.stringify({glare:next})); } };
  const tilt = event => { if(event.pointerType === "touch") return; const tile=event.currentTarget, bounds=tile.getBoundingClientRect(); const x=(event.clientX-bounds.left)/bounds.width-.5, y=(event.clientY-bounds.top)/bounds.height-.5; tile.style.transform=`perspective(650px) rotateX(${-y*9}deg) rotateY(${x*9}deg) translateY(-3px)`; };
  const resetTilt = event => { event.currentTarget.style.transform=""; };

  return (
    <div className={`drc-home ${glare ? "drc-home--matte" : ""}`}>
      <div className="drc-shell">
        <header className="drc-mast">
          <Link to="/tools" className="drc-icon-button" aria-label="More tools"><Menu size={21}/></Link>
          <div className="drc-brand"><strong>DRC</strong><span>GOLF TOURBILLION</span></div>
          <button type="button" className="drc-icon-button" onClick={toggleGlare} aria-label="Toggle anti glare" aria-pressed={glare}><Sun size={21}/></button>
        </header>
        <div className="drc-welcome">Welcome, {firstName}</div>
        <section className="drc-next">
          <div className="drc-next-badge"><Flag size={22}/></div>
          <div className="drc-next-copy">
            <small>{resumeRound ? "ROUND IN PROGRESS" : "READY TO PLAY"}</small>
            <strong>{resumeRound?.course_name || "Choose your course"}</strong>
            <span>{resumeRound ? `Hole ${resumeRound.current_hole || 1} · Continue your card` : "Start the Caddie Engine"}</span>
          </div>
          {resumeRound && <button className="drc-next-go" onClick={() => navigate(`/round/${resumeRound.id}`)} aria-label="Resume round"><ChevronRight/></button>}
        </section>
        <section className="drc-hero" aria-label="3D golf scene">
          <HomeScene glare={glare}/>
          <div className="drc-hero-vignette"/>
          <div className="drc-hero-copy"><span>YOUR COURSE. YOUR DECISION.</span><strong>Play the next shot.</strong></div>
          <button className="drc-start" onClick={() => resumeRound ? navigate(`/round/${resumeRound.id}`) : openRoundDialog(null)}>{resumeRound ? <RotateCcw size={17}/> : <Flag size={17}/>} {resumeRound ? "RESUME CADDIE ENGINE" : "START CADDIE ENGINE"}</button>
        </section>
        <div className="drc-grid">
          {cards.map(({title,detail,to,action}) => {
            const inside = <><div className="drc-tile-art"><HomeTileArt title={title}/></div><strong>{title}</strong><span>{detail}</span></>;
            return to ? <Link className="drc-tile" to={to} key={title} onPointerMove={tilt} onPointerLeave={resetTilt}>{inside}</Link> : <button className="drc-tile" onClick={action} key={title} onPointerMove={tilt} onPointerLeave={resetTilt}>{inside}</button>;
          })}
        </div>
      </div>
      <nav className="drc-bottom" aria-label="Main navigation">
        <Link to="/" aria-label="Home" className="active"><Flag/></Link>
        <Link to="/records" aria-label="Records"><History/></Link>
        <Link to="/courses" aria-label="Courses"><MapPin/></Link>
        <Link to="/bag" aria-label="My Bag"><BriefcaseBusiness/></Link>
        <Link to="/tools" aria-label="More"><Menu/></Link>
      </nav>
      <NewRoundDialog open={dialogOpen} onOpenChange={setDialogOpen} courses={courses} initialCourse={selectedCourse} onStart={handleStartRound} submitting={submitting}/>
    </div>
  );}