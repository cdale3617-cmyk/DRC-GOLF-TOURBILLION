import React, { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, ArrowRight, Compass, Flag, Save, Plus, Navigation, Sun, Crosshair, Target } from "lucide-react";
import * as THREE from "three";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import FunctionalLab from "@/components/FunctionalLab";
import { HoleInfo, ShotLog } from "@/components/RoundDetails";
import GroupScorecard from "@/components/GroupScorecard";
import ShotTracer from "@/components/ShotTracer";
import BagView from "@/components/BagView";
import Fusion from "@/components/Fusion";
import { LiveScoreControls, syncLiveBoard } from "@/components/LiveScores";
import RoundAnalytics from "@/components/RoundAnalytics";
import ScoreTable from "@/components/ScoreTable";

const CLUBS = ["Driver","3 Wood","5 Wood","4 Hybrid","5 Iron","6 Iron","7 Iron","8 Iron","9 Iron","Pitching Wedge","Gap Wedge","Sand Wedge","Lob Wedge","Putter"];
const INITIAL = [220,195,180,165,155,145,135,125,115,100,85,70,55,0];
const LOFT = [10,15,18,22,25,28,32,36,41,46,50,56,60,3];
const MODULES = [
  ["Caddie","Club choice and aim"],["Plan","Shot strategy"],["Score","Gross score and putts"],["Bag","Club distances and lofts"],
  ["Shot Tracer","Log a shot"],["Biometrics","Manual health log"],["Kinetics","Swing notes"],["Green Reading","Measured slope entry"],
  ["Strokes Gained","Round comparison"],["Dispersion","Shot pattern"],["Putting Lab","Putting log"],["Short Game","Inside 100 metres"],
  ["Wedge Matrix","Wedge distances"],["Fusion","Round overview"],["Pre-Round","Checklist"],["Equipment","Club setup"],["Records","Previous rounds"],["How To","Guide"]
];
const STORAGE = "drc-tourbillion-v1";
function readSaved() { try { return JSON.parse(localStorage.getItem(STORAGE) || "{}"); } catch { return {}; } }
function useGlarePreference(){const [glare,setGlare]=useState(()=>!!readSaved().glare);const toggle=()=>setGlare(current=>{const next=!current;localStorage.setItem(STORAGE,JSON.stringify({...readSaved(),glare:next}));return next;});return [glare,toggle];}
function metresBetween(a,b){const rad=Math.PI/180,dLat=(b.lat-a.lat)*rad,dLng=(b.lng-a.lng)*rad;const h=Math.sin(dLat/2)**2+Math.cos(a.lat*rad)*Math.cos(b.lat*rad)*Math.sin(dLng/2)**2;return 6371000*2*Math.atan2(Math.sqrt(h),Math.sqrt(1-h));}
function HoleScene({ hole, glare }) {
  const mount = useRef(null);
  useEffect(() => {
    const root = mount.current;
    if (!root) return;
    const width = root.clientWidth, height = root.clientHeight;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(glare ? 0x142c22 : 0x06130e);
    const camera = new THREE.PerspectiveCamera(40, width / height, .1, 100);
    camera.position.set(0, 11, 16);
    camera.lookAt(0, 0, 0);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setSize(width, height); renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    root.appendChild(renderer.domElement);
    let angle=0, dragging=false, lastX=0;
    const pointerDown=e=>{dragging=true;lastX=e.clientX;renderer.domElement.setPointerCapture(e.pointerId);};
    const pointerMove=e=>{if(!dragging)return;angle+=(e.clientX-lastX)*.008;lastX=e.clientX;camera.position.set(Math.sin(angle)*16,11,Math.cos(angle)*16);camera.lookAt(0,0,0);};
    const pointerUp=()=>{dragging=false;};
    renderer.domElement.addEventListener("pointerdown",pointerDown);
    renderer.domElement.addEventListener("pointermove",pointerMove);
    renderer.domElement.addEventListener("pointerup",pointerUp);
    renderer.domElement.addEventListener("pointercancel",pointerUp);
    const light = new THREE.DirectionalLight(0xffefc5, 2.4); light.position.set(-4, 8, 7); scene.add(light);
    scene.add(new THREE.AmbientLight(0xc1ffe1, 1.1));
    const make = (geometry, color, x, y, z) => { const mesh = new THREE.Mesh(geometry,new THREE.MeshStandardMaterial({color,roughness:.8})); mesh.position.set(x,y,z); scene.add(mesh); return mesh; };
    make(new THREE.PlaneGeometry(12,23), 0x103527,0,-.25,0).rotation.x=-Math.PI/2;
    const bend = Math.sin(hole * 1.74) * .85;
    const fairway = make(new THREE.CapsuleGeometry(2.12, 11, 8, 18),0x287047,bend*.35,-.19,.3);
    fairway.rotation.x=-Math.PI/2; fairway.rotation.z=-bend*.09;
    make(new THREE.CylinderGeometry(1.75,1.6,.08,40),0x56aa68,bend,-.11,-6);
    for(let i=0;i<3;i++) {
      const z = 4-i*3.8, x = ((i+hole)%2 ? -1:1)*(2.2+i*.35);
      const bunker=make(new THREE.SphereGeometry(.62,16,8),0xd4c58a,x,-.09,z);
      bunker.scale.set(1.5,.12,.72);
    }
    for(let i=0;i<8;i++) {
      const z=7-i*1.85, x=((i+hole)%2 ? -1:1)*(3.1+(i%3)*.35);
      make(new THREE.ConeGeometry(.35,.9,8),0x0b6242,x,.23,z);
      make(new THREE.CylinderGeometry(.06,.07,.42,8),0x785e36,x,-.10,z);
    }
    make(new THREE.CylinderGeometry(.035,.035,1.3,10),0xe9d498,bend,.55,-6);
    const flag=make(new THREE.PlaneGeometry(.52,.32),0xb52e2a,bend+.27,1.04,-6);
    flag.rotation.y=.18;
    const tee=make(new THREE.SphereGeometry(.15,16,12),0xeedca4,0,.03,7);
    let frame;
    const animate=()=>{ frame=requestAnimationFrame(animate); flag.rotation.y=.18+Math.sin(Date.now()/650)*.12; tee.scale.setScalar(1+Math.sin(Date.now()/450)*.09); renderer.render(scene,camera); };
    animate();
    const observer=new ResizeObserver(()=>{ const w=root.clientWidth,h=root.clientHeight; camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h); });
    observer.observe(root);
    return ()=>{ observer.disconnect();cancelAnimationFrame(frame);renderer.domElement.removeEventListener("pointerdown",pointerDown);renderer.domElement.removeEventListener("pointermove",pointerMove);renderer.domElement.removeEventListener("pointerup",pointerUp);renderer.domElement.removeEventListener("pointercancel",pointerUp);root.removeChild(renderer.domElement);renderer.dispose();scene.traverse(o=>{if(o.geometry)o.geometry.dispose();if(o.material)o.material.dispose();}); };
  },[hole,glare]);
  return <div className="hole-canvas" ref={mount} aria-label={"Schematic 3D fairway for hole "+hole}/>;
}
function Button({children,onClick,active=false,disabled=false,className=""}) { return <button type="button" disabled={disabled} onClick={onClick} className={"tour-button "+(active?"active ":"")+className}>{children}</button>; }
function Shell({title,subtitle,children,back="/",glare=false,onGlare}) {
  return <div className={"tour-shell "+(glare?"anti-glare":"")}>
    <header className="tour-top"><Link to={back} aria-label="Back"><ArrowLeft size={20}/></Link><div><span className="tour-kicker">DRC GOLF TOURBILLION</span><h1>{title}</h1>{subtitle&&<small>{subtitle}</small>}</div><button onClick={onGlare} aria-label="Toggle anti-glare" title="Anti-glare"><Sun size={20}/></button></header>
    <main className="tour-body">{children}</main>
    <nav className="tour-nav"><Link to="/">HOME</Link><Link to="/courses">COURSES</Link><Link to="/bag">BAG</Link><Link to="/records">RECORDS</Link><Link to="/tools">MORE</Link></nav>
  </div>;
}
export function TourbillionRound() {
  const {roundId}=useParams(); const navigate=useNavigate(); const {toast}=useToast();
  const [round,setRound]=useState(null),[busy,setBusy]=useState(true),[hole,setHole]=useState(1),[panel,setPanel]=useState("Caddie");
  const [saved,setSaved]=useState(readSaved);
  const bagProfileId=useRef(null);
  const [bagReady,setBagReady]=useState(false);
  const [score,setScore]=useState(""),[putts,setPutts]=useState(""),[penalties,setPenalties]=useState("");
  const [wind,setWind]=useState(""),[windDirection,setWindDirection]=useState("Unaligned"),[distance,setDistance]=useState(""),[note,setNote]=useState("");
  const [weather,setWeather]=useState(null),[windLoading,setWindLoading]=useState(false);
  const [location,setLocation]=useState(null);
  useEffect(()=>{let active=true;base44.auth.me().then(me=>base44.entities.BagProfile.filter({created_by_id:me.id},"-updated_date",1)).then(items=>{if(!active)return;const profile=items[0];if(profile){bagProfileId.current=profile.id;setSaved(current=>{const next={...current,clubs:profile.clubs||current.clubs,unit:profile.unit||current.unit};localStorage.setItem(STORAGE,JSON.stringify(next));return next;});}setBagReady(true);}).catch(()=>{if(active)setBagReady(true);});return()=>{active=false;};},[]);
  useEffect(()=>{let mounted=true;base44.entities.Round.get(roundId).then(r=>{if(mounted){setRound(r);setHole(r.current_hole||1);setBusy(false);}}).catch(()=>{if(mounted){setBusy(false);toast({title:"Round unavailable",variant:"destructive"});}});return()=>{mounted=false;};},[roundId]);
  const scores=round?.scores||{};
  useEffect(()=>{if(!round)return;const metres=round.hole_distances?.[hole-1];setDistance(metres?String(Math.round(metres*((saved.unit||"m")==="yd"?1.09361:1))):"");},[hole,round?.id,saved.unit]);
  useEffect(()=>{const item=scores[String(hole)]||{};setScore(item.gross??"");setPutts(item.putts??"");setPenalties(item.penalties??"");setNote(item.note??"");},[hole,round?.scores]);
  const setPreference=(patch)=>setSaved(s=>{const next={...s,...patch};localStorage.setItem(STORAGE,JSON.stringify(next));return next;});
  const jump=async next=>{if(!round)return;const target=Math.max(1,Math.min(round.holes||18,next));setHole(target);setPanel("Caddie");try{await base44.entities.Round.update(roundId,{current_hole:target});}catch{}};
  const persist=async (goNext=false)=>{if(!round)return;const gross=Number(score);if(!Number.isInteger(gross)||gross<1){toast({title:"Enter a gross score first",variant:"destructive"});return;}
    if([putts,penalties].some(value=>value!==""&&(!Number.isInteger(Number(value))||Number(value)<0))){toast({title:"Putts and penalties must be whole numbers of zero or more",variant:"destructive"});return;}
    const entry={gross,putts:putts===""?null:Number(putts),penalties:penalties===""?null:Number(penalties),note};
    const nextScores={...scores,[String(hole)]:entry};
    try{const changed=await base44.entities.Round.update(roundId,{scores:nextScores,current_hole:goNext?Math.min(hole+1,round.holes||18):hole});setRound(changed);syncLiveBoard(changed);toast({title:"Score saved"});if(goNext&&hole<(round.holes||18))setHole(hole+1);}catch{toast({title:"Could not save score",variant:"destructive"});}
  };
  const getGPS=()=>{if(!navigator.geolocation){toast({title:"Location is unavailable"});return;}
    setWindLoading(true);
    navigator.geolocation.getCurrentPosition(async p=>{
      const point={lat:p.coords.latitude,lng:p.coords.longitude,accuracy:p.coords.accuracy};setLocation(point);
      try{
        const reply=await base44.functions.invoke("current-wind",{latitude:point.lat,longitude:point.lng});
        const reading=reply.data;setWeather(reading);setWind(String(Math.round(Number(reading.speed_kph)*((saved.windUnit||"km/h")==="mph"?.621371:1))));setWindDirection("Unaligned");
        toast({title:"Local wind loaded"});
      }catch(error){toast({title:error?.response?.data?.code==="NO_WEATHER_KEY"?"GPS ready; live wind needs a provider key":"GPS ready; live wind unavailable"});}
      finally{setWindLoading(false);}
    },()=>{setWindLoading(false);toast({title:"Location permission or signal unavailable"});},{enableHighAccuracy:true,timeout:12000});
  };
  const clubs=saved.clubs||CLUBS.map((name,i)=>({name,carry:INITIAL[i],loft:LOFT[i]}));
  const toggleDistanceUnit=async()=>{const currentUnit=saved.unit||"m";const nextUnit=currentUnit==="m"?"yd":"m";const nextClubs=clubs.map(c=>({...c,carry:Math.round(Number(c.carry)*(currentUnit==="m"?1.09361:.9144))}));setPreference({unit:nextUnit,clubs:nextClubs});try{if(bagProfileId.current)await base44.entities.BagProfile.update(bagProfileId.current,{unit:nextUnit,clubs:nextClubs});else{const created=await base44.entities.BagProfile.create({unit:nextUnit,clubs:nextClubs});bagProfileId.current=created.id;}}catch{toast({title:"Unit saved on this device; account sync unavailable"});}};
  const green=round?.hole_greens?.[hole-1];
  const gpsMetres=location&&Number.isFinite(green?.lat)&&Number.isFinite(green?.lng)?metresBetween(location,green):null;
  const gpsDistance=gpsMetres!==null?Math.round(gpsMetres*((saved.unit||"m")==="yd"?1.09361:1)):null;
  const target=Number(distance), windSpeed=Number(wind)*((saved.windUnit||"km/h")==="mph"?1.60934:1); const adjustment=Number.isFinite(windSpeed)?Math.round(windSpeed*(windDirection==="Headwind"?.35:windDirection==="Tailwind"?-.25:0)*(saved.unit==="yd"?1.09361:1)):0;
  const club=clubs.filter(c=>c.carry>0).reduce((best,c)=>!best||Math.abs(c.carry-(target+adjustment))<Math.abs(best.carry-(target+adjustment))?c:best,null);
  if(busy)return <div className="tour-loading">Loading round…</div>;
  if(!round)return <Shell title="Round unavailable"><Button onClick={()=>navigate("/")}>Home</Button></Shell>;
  const unit=saved.unit||"m";
  return <Shell title={"HOLE "+hole} subtitle={round.course_name} glare={saved.glare} onGlare={()=>setPreference({glare:!saved.glare})}>
    <div className="tour-row"><span className="tour-pill"><Flag size={14}/> Hole {hole} / {round.holes||18}</span><span className="tour-pill">Par {round.hole_pars?.[hole-1]||"—"}</span>{round.hole_distances?.[hole-1]>0&&<span className="tour-pill">{Math.round(round.hole_distances[hole-1]*(unit==="yd"?1.09361:1))} {unit}</span>}<Button disabled={!bagReady} onClick={toggleDistanceUnit}>{bagReady?(unit==="m"?"METRES":"YARDS"):"LOADING BAG…"}</Button></div>
    <div className="wind-controls"><label>WIND <input type="number" inputMode="decimal" min="0" value={wind} onChange={e=>{setWind(e.target.value);setWeather(null);}} placeholder="Speed"/></label><span>{saved.windUnit||"km/h"}</span><label>DIRECTION <select value={windDirection} onChange={e=>setWindDirection(e.target.value)}>{["Unaligned","L→R","R→L","Headwind","Tailwind","Calm"].map(v=><option key={v}>{v}</option>)}</select></label></div>
    <div className="hole-layout"><section className="hole-map"><div className="hole-caption"><span>3D HOLE VIEW</span><span>DRAG TO TURN · SCHEMATIC</span></div>{gpsDistance!==null&&<div className="wind-badge">GPS TO GREEN CENTRE {gpsDistance} {unit} · ±{Math.round(location.accuracy)} m · REFRESH GPS FOR CURRENT POSITION</div>}<div className="wind-badge">{weather?<>WIND {wind} {saved.windUnit||"km/h"} FROM {weather.from_compass} · GUST {Math.round(Number(weather.gust_kph)*((saved.windUnit||"km/h")==="mph"?.621371:1))} · WeatherAPI.com</>:wind?<>WIND {wind} {saved.windUnit||"km/h"} · {windDirection} (MANUAL)</>:"WIND: SET ABOVE"}</div><HoleScene hole={hole} glare={saved.glare}/>{Number(wind)>0&&windDirection!=="Calm"&&<div className={"wind-stream "+(windDirection==="Unaligned"?"wind-unknown":"")} aria-hidden="true" style={{"--from-x":windDirection==="R→L"?"24px":windDirection==="L→R"?"-24px":"0px","--to-x":windDirection==="R→L"?"-24px":windDirection==="L→R"?"24px":"0px","--from-y":windDirection==="Headwind"?"-24px":windDirection==="Tailwind"?"24px":"0px","--to-y":windDirection==="Headwind"?"24px":windDirection==="Tailwind"?"-24px":"0px"}}>{Array.from({length:4},(_,i)=><span key={i} style={{animationDelay:(i*.5)+"s"}}>{windDirection==="Unaligned"?"⇄":<svg viewBox="0 0 62 20" style={{transform:"rotate("+(windDirection==="R→L"?180:windDirection==="Headwind"?90:windDirection==="Tailwind"?-90:0)+"deg)"}}><path d="M 3 10 H 53 M 46 3 L 54 10 L 46 17" fill="none" stroke="white" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"/></svg>}</span>)}</div>}<div className="hole-compass"><Compass size={17}/> N ↑ &nbsp; Course orientation unverified</div></section>
      <aside className="hole-tabs">{["Caddie","Plan","Score","Hole Info","Shots","Shot Tracer","Green Reading","Putting Lab"].map(x=><Button key={x} active={panel===x} onClick={()=>setPanel(x)}>{x}</Button>)}</aside></div>
    <div className="tour-row spread"><Button disabled={hole<=1} onClick={()=>jump(hole-1)}><ArrowLeft size={16}/> PREV</Button><Button disabled={windLoading} onClick={getGPS}><Navigation size={16}/> {windLoading?"LOCATING…":"GPS"}</Button><Button disabled={hole>=(round.holes||18)} onClick={()=>jump(hole+1)}>NEXT <ArrowRight size={16}/></Button></div>
    {panel==="Caddie"&&<section className="tour-card"><h2><Target size={18}/> Caddie engine</h2><p>Enter a measured distance. Club choice uses your bag carry values.</p><div className="tour-form"><label>Distance to target ({unit})<input inputMode="decimal" type="number" min="0" value={distance} onChange={e=>setDistance(e.target.value)} placeholder="Enter distance"/></label></div><p>Set wind speed and direction in the strip above the hole.</p>{target>0&&<div className="tour-result"><strong>{club?.name||"Set up your bag"}</strong><span>Playing distance about {Math.max(0,target+adjustment)} {unit}. {windDirection==="Unaligned"?"Wind adjustment awaits hole-relative direction.":"Wind adjustment is an estimate."} Check lie and elevation.</span></div>}<Button onClick={()=>{const oldUnit=saved.windUnit||"km/h";setWind(w=>w?String(Math.round(Number(w)*(oldUnit==="km/h"?.621371:1.60934))):"");setPreference({windUnit:oldUnit==="km/h"?"mph":"km/h"});}}>WIND: {saved.windUnit||"km/h"} ⇄</Button> <Button disabled={windLoading} onClick={getGPS}><Navigation size={16}/> {windLoading?"LOADING WIND…":"GET LOCAL WIND + GPS"}</Button>{weather&&<small>WeatherAPI.com · {weather.observed_at} · Wind from {weather.from_compass} ({weather.from_degrees}°). Select its direction relative to this hole before using it for club choice.</small>}{location&&<small>GPS {location.lat.toFixed(5)}, {location.lng.toFixed(5)} (±{Math.round(location.accuracy)} m). {gpsDistance===null?"Save a verified green centre in Hole Info to get distance.":"Green centre distance is straight line, subject to GPS and pin position."}</small>}</section>}
    {panel==="Hole Info"&&<HoleInfo round={round} hole={hole} onRound={setRound} unit={unit}/>}
    {panel==="Shots"&&<ShotLog round={round} hole={hole} onRound={setRound} clubs={clubs} unit={unit}/>}
    {panel==="Plan"&&<section className="tour-card"><h2><Crosshair size={18}/> Shot plan</h2><p>Pick the safe target, account for your usual miss, and note the next shot.</p><textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="Aim point, hazard, lay-up distance…"/><Button onClick={()=>setPanel("Score")}>CONTINUE TO SCORE</Button></section>}
    {panel==="Score"&&<section className="tour-card"><h2><Flag size={18}/> Score hole {hole}</h2><div className="tour-form"><label>Gross strokes<input type="number" inputMode="numeric" min="1" value={score} onChange={e=>setScore(e.target.value)}/></label><label>Putts<input type="number" inputMode="numeric" min="0" value={putts} onChange={e=>setPutts(e.target.value)}/></label><label>Penalty strokes<input type="number" inputMode="numeric" min="0" value={penalties} onChange={e=>setPenalties(e.target.value)}/></label></div><Button className="gold-action" onClick={()=>persist(true)}><Save size={16}/> SAVE SCORE & NEXT</Button><Button onClick={()=>persist(false)}>SAVE THIS HOLE</Button><Link className="tour-link" to={"/round/"+roundId+"/card"}>OPEN FULL SCORECARD →</Link></section>}
    {panel==="Shot Tracer"&&<ShotTracer/>}
    {["Green Reading","Putting Lab"].includes(panel)&&<RoundTool title={panel} hole={hole} saved={saved} onSave={setPreference}/>}
    <p className="tour-caution">This view is a 3D schematic. It does not show surveyed hole geometry, on-course wind measurements, AR depth, or a measured green slope. Check local rules for device use in competition.</p>
  </Shell>;
}
function RoundTool({title,hole,saved,onSave}) {
  const key=title.toLowerCase().replaceAll(" ","_")+"_"+hole;const entries=saved[key]||[];
  const [value,setValue]=useState("");
  return <section className="tour-card"><h2>{title}</h2><p>{title==="Green Reading"?"Enter a slope you measured on the green. No camera depth reading is active in this web app.":title==="Shot Tracer"?"Log a shot and its result. Video tracing needs a camera processing engine.":"Record the distance and result of each putt."}</p><div className="tour-inline"><input value={value} onChange={e=>setValue(e.target.value)} placeholder={title==="Green Reading"?"Slope %, break and direction":"Distance and result"} /><Button onClick={()=>{if(!value.trim())return;onSave({[key]:[...entries,{text:value.trim(),at:new Date().toISOString()}]});setValue("");}}><Plus size={16}/> ADD</Button></div>{entries.map((e,i)=><div className="tour-entry" key={i}>{e.text}<button onClick={()=>onSave({[key]:entries.filter((_,j)=>i!==j)})} aria-label="Delete entry">×</button></div>)}</section>;
}
export function Scorecard() {
  const {roundId}=useParams();const navigate=useNavigate();const [round,setRound]=useState(null); const {toast}=useToast();const [glare,toggleGlare]=useGlarePreference();
  const openHole=async hole=>{try{await base44.entities.Round.update(roundId,{current_hole:hole});navigate("/round/"+roundId);}catch{toast({title:"Could not open hole",variant:"destructive"});}};
  useEffect(()=>{base44.entities.Round.get(roundId).then(setRound).catch(()=>{});},[roundId]);
  if(!round)return <div className="tour-loading">Loading scorecard…</div>;
  const scores=round.scores||{}, holes=round.holes||18;
  const total=Object.values(scores).reduce((sum,s)=>sum+(Number(s.gross)||0),0);
  const puttsTotal=Object.values(scores).reduce((sum,s)=>sum+(Number(s.putts)||0),0);
  const penaltiesTotal=Object.values(scores).reduce((sum,s)=>sum+(Number(s.penalties)||0),0);
  const parKnown=Object.entries(scores).filter(([h])=>Number(round.hole_pars?.[Number(h)-1])>0).reduce((sum,[h])=>sum+Number(round.hole_pars[Number(h)-1]),0);
  const scoredWithPar=Object.entries(scores).filter(([h])=>Number(round.hole_pars?.[Number(h)-1])>0).reduce((sum,[,s])=>sum+Number(s.gross),0);
  const finish=async()=>{const missing=Array.from({length:holes},(_,i)=>i+1).filter(h=>!Number(scores[String(h)]?.gross));if(missing.length){toast({title:"Score holes before finishing",description:"Missing: "+missing.join(", "),variant:"destructive"});return;}try{setRound(await base44.entities.Round.update(roundId,{status:"completed",completed_at:new Date().toISOString()}));toast({title:"Round completed"});}catch{toast({title:"Could not finish round",variant:"destructive"});}};
  return <Shell title="SCORECARD" subtitle={round.course_name} back={"/round/"+roundId} glare={glare} onGlare={toggleGlare}><section className="tour-card scorecard-sheet"><h2>Gross {total||"—"} · {Object.keys(scores).length}/{holes} holes</h2><p>{parKnown>0?"Against entered pars: "+(scoredWithPar-parKnown>0?"+":"")+(scoredWithPar-parKnown):"Enter hole pars for comparison"} · Putts {puttsTotal} · Penalties {penaltiesTotal}</p><ScoreTable round={round} onHole={openHole}/>{round.status!=="completed"&&<Button className="gold-action" onClick={finish}>FINISH ROUND</Button>}<Button onClick={()=>window.print()}>PRINT SCORECARD</Button><GroupScorecard round={round} onRound={setRound}/><div className="score-signature"><span>Player signature</span><span>Marker signature</span></div><LiveScoreControls round={round} onRound={setRound}/><p>Review the gross scores and sign the official paper card when required.</p></section></Shell>;
}
export function Bag() {
  const [saved,setSaved]=useState(readSaved);
  const [remoteReady,setRemoteReady]=useState(false),[syncState,setSyncState]=useState("Loading bag…");
  const profileRef=useRef(null),savingRef=useRef(false),latestRef=useRef(null),versionRef=useRef(0),writtenRef=useRef(0);
  const clubs=saved.clubs||CLUBS.map((name,i)=>({name,carry:INITIAL[i],loft:LOFT[i],make:"",model:""}));
  const unit=saved.unit||"m";
  useEffect(()=>{
    let active=true;
    base44.auth.me().then(me=>base44.entities.BagProfile.filter({created_by_id:me.id},"-updated_date",1)).then(items=>{
      if(!active)return;
      const profile=items[0];
      if(profile){profileRef.current=profile.id;setSaved(s=>{const next={...s,clubs:profile.clubs||s.clubs,unit:profile.unit||s.unit};localStorage.setItem(STORAGE,JSON.stringify(next));return next;});}
      setRemoteReady(true);setSyncState("Bag ready");
    }).catch(()=>{if(active){setRemoteReady(true);setSyncState("Saved on this device; cloud unavailable");}});
    return()=>{active=false};
  },[]);
  useEffect(()=>{
    if(!remoteReady)return;
    latestRef.current={unit,clubs:clubs.map(c=>({...c,carry:Number(c.carry)||0,loft:Number(c.loft)||0}))};
    ++versionRef.current;
    const flush=async()=>{
      if(savingRef.current)return;
      savingRef.current=true;setSyncState("Saving bag…");
      const savingVersion=versionRef.current;
      try{
        const data=latestRef.current;
        if(profileRef.current)await base44.entities.BagProfile.update(profileRef.current,data);
        else{const created=await base44.entities.BagProfile.create(data);profileRef.current=created.id;}
        writtenRef.current=savingVersion;
        setSyncState("Bag saved to your account");
      }catch{setSyncState("Saved on this device; cloud unavailable");}
      finally{savingRef.current=false;if(versionRef.current>savingVersion)setTimeout(flush,700);}
    };
    const timer=setTimeout(flush,700);
    return()=>clearTimeout(timer);
  },[saved.clubs,unit,remoteReady]);
  const saveClubs=(next)=>setSaved(s=>{const updated={...s,clubs:next};localStorage.setItem(STORAGE,JSON.stringify(updated));return updated;});
  const update=(i,field,value)=>saveClubs(clubs.map((c,j)=>j===i?{...c,[field]:value}:c));
  const onUnit=()=>setSaved(s=>{const updated={...s,unit:unit==="m"?"yd":"m",clubs:clubs.map(c=>({...c,carry:Math.round(Number(c.carry)*(unit==="m"?1.09361:.9144))}))};localStorage.setItem(STORAGE,JSON.stringify(updated));return updated;});
  const onGlare=()=>setSaved(s=>{const updated={...s,glare:!s.glare};localStorage.setItem(STORAGE,JSON.stringify(updated));return updated;});
  return <Shell title="MY BAG" subtitle="Club · Make · Carry · Loft" glare={saved.glare} onGlare={onGlare}><p className="bag-sync" role="status">{syncState}</p><BagView clubs={clubs} unit={unit} onUpdate={update} onUnit={onUnit} onAdd={()=>saveClubs([...clubs,{name:"New club",type:"Irons",carry:0,loft:0,make:"",model:""}])} onRemove={i=>saveClubs(clubs.filter((_,j)=>j!==i))}/></Shell>;
}
function PreRound({saved,onSave}) {
  const tasks=["Confirm tee time and course","Charge phone and enable location","Check bag and club carry values","Check weather and wind","Warm up with purpose","Choose a target and routine"];
  const checks=saved.preRoundChecks||{};
  return <section className="tour-card"><h2>Pre-Round</h2><p>Your own checklist. Tick each item before you tee off.</p>{tasks.map((task,i)=><label className="tour-check" key={task}><input type="checkbox" checked={!!checks[i]} onChange={e=>onSave({preRoundChecks:{...checks,[i]:e.target.checked}})}/><span>{task}</span></label>)}<p>{tasks.filter((_,i)=>checks[i]).length} of {tasks.length} ready.</p></section>;
}
export function ToolsHub() {
  const [saved,setSaved]=useState(readSaved),[active,setActive]=useState("Pre-Round"),[entry,setEntry]=useState("");
  const save=(patch)=>setSaved(s=>{const next={...s,...patch};localStorage.setItem(STORAGE,JSON.stringify(next));return next;});
  const key="module_"+active; const items=saved[key]||[];
  const isCalculated=["Dispersion","Wedge Matrix","Putting Lab","Short Game","Green Reading","Biometrics","Kinetics","Strokes Gained"].includes(active);
  return <Shell title="GOLF LAB" subtitle={active} glare={saved.glare} onGlare={()=>save({glare:!saved.glare})}><div className="module-grid">{MODULES.filter(([name])=>!["Caddie","Plan","Score","Bag"].includes(name)).map(([name,hint])=><Button key={name} active={active===name} onClick={()=>setActive(name)}><strong>{name}</strong><small>{hint}</small></Button>)}</div>{active==="Pre-Round"?<PreRound saved={saved} onSave={save}/>:active==="Shot Tracer"?<ShotTracer/>:active==="Fusion"?<Fusion/>:active==="Equipment"?<section className="tour-card"><h2>Equipment</h2><p>Set the make, model, carry, loft and type for every club in your bag.</p><Link className="tour-link" to="/bag">OPEN MY BAG →</Link></section>:active==="Records"?<section className="tour-card"><h2>Records</h2><Link className="tour-link" to="/records">OPEN ROUND HISTORY →</Link></section>:isCalculated?<FunctionalLab key={active} kind={active}/>:<section className="tour-card"><h2>{active}</h2><p>{active==="How To"?"Start a round from Home. Use the tall hole map and right side tabs. Enter gross strokes after each hole. Bag holds your personal carry distances. The course rendering is illustrative.":active==="Green Reading"?"Record measured slope, break and confidence. Raw Depth and camera measurement require an Android native module.":active==="Biometrics"?"Record a manual observation. Device sensors and Samsung Health are not connected in this web build.":active==="Shot Tracer"?"Record a shot result here. Camera ball tracking needs a dedicated vision engine.":active==="Strokes Gained"?"Record a baseline or observation. Calculated strokes gained requires shot location data and reference benchmarks.":active==="Dispersion"?"Record left/right miss and distance for a club.":"Keep your notes and observations here."}</p>{active!=="How To"&&<><div className="tour-inline"><input value={entry} onChange={e=>setEntry(e.target.value)} placeholder={"Add "+active.toLowerCase()+" entry"}/><Button onClick={()=>{if(!entry.trim())return;save({[key]:[...items,{text:entry.trim(),date:new Date().toISOString()}]});setEntry("");}}><Plus size={16}/> SAVE</Button></div>{items.map((item,i)=><div className="tour-entry" key={i}>{item.text}<button onClick={()=>save({[key]:items.filter((_,j)=>i!==j)})} aria-label="Delete entry">×</button></div>)}</>}</section>}</Shell>;
}
export function Records() {
  const [rounds,setRounds]=useState([]),[loading,setLoading]=useState(true);const [glare,toggleGlare]=useGlarePreference();
  useEffect(()=>{let mounted=true;base44.auth.me().then(me=>base44.entities.Round.filter({created_by_id:me.id},"-created_date",100)).then(data=>{if(!mounted)return;setRounds(data);setLoading(false);}).catch(()=>{if(mounted)setLoading(false);});return()=>{mounted=false;};},[]);
  const completed=rounds.filter(r=>r.status==="completed"&&Object.keys(r.scores||{}).length===(r.holes||18));
  const gross=completed.map(r=>Object.values(r.scores||{}).reduce((a,s)=>a+(Number(s.gross)||0),0));
  const roundAverage=gross.length?Math.round(gross.reduce((a,b)=>a+b,0)/gross.length):null;
  return <Shell title="RECORDS" subtitle="Your rounds" glare={glare} onGlare={toggleGlare}><section className="tour-card"><h2>Round history</h2>{completed.length>0&&<div className="tour-stats"><div><strong>{completed.length}</strong><small>Completed</small></div><div><strong>{roundAverage}</strong><small>Average gross</small></div><div><strong>{Math.min(...gross)}</strong><small>Best gross</small></div></div>}{loading?<p>Loading…</p>:rounds.length===0?<p>No rounds yet.</p>:rounds.map(r=><Link className="record-line" key={r.id} to={r.status==="completed"?"/round/"+r.id+"/card":"/round/"+r.id}><strong>{r.course_name}</strong><span>{r.status.replace("_"," ")} · {Object.values(r.scores||{}).reduce((a,b)=>a+(Number(b.gross)||0),0)||"—"} gross</span></Link>)}</section><RoundAnalytics rounds={rounds}/></Shell>;
}