import React,{useState} from "react";
import { base44 } from "@/api/base44Client";
import "./CourseCatalogImport.css";

const displayName=c=>c.club_name===c.course_name?c.club_name:[c.club_name,c.course_name].filter(Boolean).join(" · ");
const errorText=e=>{
 const code=e?.response?.data?.code;
 if(code==="NO_COURSE_KEY")return "Worldwide course search needs a GolfCourseAPI key in the app settings.";
 if(code==="RATE_LIMIT")return "The course provider's daily search limit has been reached.";
 return "Course search is unavailable. Your saved courses still work.";
};
export default function CourseCatalogImport({onImported}){
 const [query,setQuery]=useState(""),[results,setResults]=useState([]),[detail,setDetail]=useState(null),[teeIndex,setTeeIndex]=useState(0),[loading,setLoading]=useState(false),[saving,setSaving]=useState(false),[message,setMessage]=useState("");
 const search=async()=>{
  if(query.trim().length<3){setMessage("Enter at least 3 letters.");return;}
  setLoading(true);setMessage("");setDetail(null);
  try{const reply=await base44.functions.invoke("course-catalog",{action:"search",query:query.trim()});setResults(reply.data.courses||[]);if(!reply.data.courses?.length)setMessage("No matching courses found.");}
  catch(e){setResults([]);setMessage(errorText(e));}finally{setLoading(false);}
 };
 const choose=async course=>{
  setLoading(true);setMessage("");
  try{const reply=await base44.functions.invoke("course-catalog",{action:"detail",id:course.id});setDetail(reply.data.course);setTeeIndex(0);}
  catch(e){setMessage(errorText(e));}finally{setLoading(false);}
 };
 const tees=Object.entries(detail?.tees||{}).flatMap(([group,items])=>Array.isArray(items)?items.map(tee=>({...tee,group})):[]);
 const selected=tees[teeIndex];
 const importCourse=async()=>{
  if(!detail||!selected)return;
  const holes=selected.holes||[],count=Number(selected.number_of_holes)||holes.length;
  if(!Number.isInteger(count)||count<1||count>36||holes.length!==count){setMessage("This tee has no complete hole card. Choose another tee.");return;}
  const pars=holes.map(h=>Number(h.par)||0);
  if(pars.some(p=>!Number.isInteger(p)||p<3||p>6)){setMessage("This tee's hole pars need checking before import.");return;}
  const distances=holes.map(h=>Number(h.meters)>0?Math.round(Number(h.meters)):Number(h.yardage)>0?Math.round(Number(h.yardage)*.9144):0);
  setSaving(true);setMessage("");
  try{
   const me=await base44.auth.me();
   const existing=await base44.entities.PersonalCourse.filter({api_course_id:detail.id,created_by_id:me.id},"-updated_date",1);
   if(existing[0]){onImported(existing[0]);setMessage("Course already in your library.");return;}
   const location=detail.location||{},name=displayName(detail);
   const created=await base44.entities.PersonalCourse.create({
    name,location:[location.city,location.state].filter(Boolean).join(", "),country:location.country||"",
    holes:count,par:pars.reduce((a,b)=>a+b,0),api_course_id:detail.id,
    overview:"Imported from GolfCourseAPI · "+selected.tee_name+" tee. Check the club's current scorecard before play.",
    source_url:detail.scorecard_url||"",
    ...(Number.isFinite(location.latitude)?{latitude:location.latitude}:{}),
    ...(Number.isFinite(location.longitude)?{longitude:location.longitude}:{})
   });
   try{await base44.entities.CourseSetup.create({course_id:created.id,course_name:name,hole_pars:pars,hole_distances:distances});setMessage("Course and "+selected.tee_name+" tee saved.");}
   catch{setMessage("Course added, but its hole card could not be saved. Open Edit Holes to enter it.");}
   onImported(created);
  }catch{setMessage("Could not add this course. Try again.");}finally{setSaving(false);}
 };
 return <section className="tour-card"><h2>Find a course worldwide</h2><p>Search the course catalog and save a tee to your private library. Provider data should be checked against the club scorecard.</p>
  <div className="tour-inline"><input aria-label="Worldwide course search" value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>{if(e.key==="Enter")search();}} placeholder="Club or course name"/><button className="tour-button" disabled={loading} onClick={search}>{loading?"SEARCHING…":"SEARCH"}</button></div>
  {message&&<p role="status">{message}</p>}
  {results.length>0&&!detail&&<div className="course-list">{results.map(course=><button className="catalog-result" key={course.id} disabled={loading} onClick={()=>choose(course)}><strong>{displayName(course)}</strong><small>{[course.location?.city,course.location?.state,course.location?.country].filter(Boolean).join(", ")}</small></button>)}</div>}
  {detail&&<div className="tour-card catalog-detail"><h3>{displayName(detail)}</h3><p>{[detail.location?.city,detail.location?.state,detail.location?.country].filter(Boolean).join(", ")}</p>
   {tees.length?<><label>TEE <select value={teeIndex} onChange={e=>setTeeIndex(Number(e.target.value))}>{tees.map((tee,i)=><option value={i} key={i}>{tee.tee_name} · {tee.number_of_holes||tee.holes?.length} holes · Par {tee.par_total||"—"} · {tee.total_meters||Math.round(Number(tee.total_yards)*.9144)||"—"} m</option>)}</select></label><p>{selected?.holes?.length||0} hole records. Distances without metres are converted from yards.</p><button className="tour-button gold-action" disabled={saving} onClick={importCourse}>{saving?"SAVING…":"ADD THIS TEE TO MY COURSES"}</button></>:<p>No tee scorecard is available for this course.</p>}
   <button className="tour-button" onClick={()=>setDetail(null)}>BACK TO RESULTS</button>
  </div>}
 </section>;
}
