import React,{useEffect,useState} from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import "./Fusion.css";
export default function Fusion() {
 const [rounds,setRounds]=useState([]),[loading,setLoading]=useState(true);
 useEffect(()=>{let active=true;base44.auth.me().then(u=>base44.entities.Round.filter({created_by_id:u.id},"-created_date",30)).then(items=>{if(active){setRounds(items);setLoading(false)}}).catch(()=>{if(active)setLoading(false)});return()=>{active=false}},[]);
 const scored=rounds.filter(r=>Object.keys(r.scores||{}).length>0);
 const values=scored.flatMap(r=>Object.values(r.scores||{}));
 const sum=(field)=>values.reduce((n,s)=>n+(Number(s[field])||0),0);
 const gross=sum("gross"), putts=sum("putts"), penalties=sum("penalties");
 const holes=values.length;
 const latest=scored[0];
 const lab=(()=>{try{return JSON.parse(localStorage.getItem("drc-tourbillion-lab-v1")||"{}")}catch{return {}}})();
 const practice=["Dispersion","Wedge Matrix","Putting Lab","Short Game","Green Reading","Biometrics","Kinetics","Strokes Gained"].map(k=>({name:k,count:(lab[k]||[]).length}));
 return <section className="tour-card fusion-dashboard"><h2>Fusion overview</h2><p>Round results and practice entries from this device.</p>
 {loading?<p>Loading rounds…</p>:<><div className="fusion-stats"><div><strong>{scored.length}</strong><small>Rounds with scores</small></div><div><strong>{holes}</strong><small>Holes scored</small></div><div><strong>{holes?(gross/holes).toFixed(1):"—"}</strong><small>Gross per hole</small></div><div><strong>{holes?(putts/holes).toFixed(1):"—"}</strong><small>Putts per hole</small></div></div>
 {holes>0&&<p>{penalties} penalty strokes logged · {latest?.course_name} was your latest scored course.</p>}
 <div className="fusion-practice"><h3>Practice activity</h3>{practice.map(item=><div key={item.name}><span>{item.name}</span><div><i style={{width:Math.min(100,item.count*10)+"%"}}/></div><b>{item.count}</b></div>)}</div>
 {holes===0&&<p>Start a round and save hole scores to fill this dashboard.</p>}
 <Link className="tour-link" to="/records">OPEN ROUND RECORDS →</Link></>}
 </section>;
}