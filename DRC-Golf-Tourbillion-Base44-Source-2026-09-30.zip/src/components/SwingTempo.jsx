import React,{useRef,useState} from "react";
import "./SwingTempo.css";
export default function SwingTempo({onMeasured}){
 const clock=useRef({}),[phase,setPhase]=useState("ready"),[measure,setMeasure]=useState(null),[status,setStatus]=useState("");
 const start=()=>{clock.current={start:performance.now()};setMeasure(null);setPhase("backswing");setStatus("Tap TOP at the end of the backswing.");};
 const top=()=>{clock.current.top=performance.now();setPhase("downswing");setStatus("Tap IMPACT when the club meets the ball.");};
 const impact=()=>{
  const end=performance.now(),back=(clock.current.top-clock.current.start)/1000,down=(end-clock.current.top)/1000;
  if(back<=0||down<=0)return;
  const item={backswing:Number(back.toFixed(2)),downswing:Number(down.toFixed(2)),ratio:Number((back/down).toFixed(2)),at:new Date().toISOString(),source:"manual taps"};
  setMeasure(item);setPhase("done");setStatus("Measured from your three taps. Timing depends on the observer.");
  onMeasured(item);
 };
 return <div className="swing-tempo"><h3>Swing tempo</h3><p>Have someone tap during your swing or tap along to a recorded swing. Start → Top → Impact.</p><div className="tour-row"><button className="tour-button" onClick={start}>START</button><button className="tour-button" disabled={phase!=="backswing"} onClick={top}>TOP</button><button className="tour-button gold-action" disabled={phase!=="downswing"} onClick={impact}>IMPACT</button></div>{measure&&<div className="tempo-result"><div><strong>{measure.backswing}s</strong><small>Backswing</small></div><div><strong>{measure.downswing}s</strong><small>Downswing</small></div><div><strong>{measure.ratio}:1</strong><small>Tempo ratio</small></div></div>}<p role="status">{status}</p></div>;
}