import React,{useEffect,useRef,useState} from "react";
export default function ShotTracer(){
 const video=useRef(null),[url,setUrl]=useState(""),[points,setPoints]=useState([]),[drawing,setDrawing]=useState(false),[ratio,setRatio]=useState("9 / 16"),[message,setMessage]=useState("");
 useEffect(()=>()=>{if(url)URL.revokeObjectURL(url)},[url]);
 const choose=e=>{const file=e.target.files?.[0];if(!file)return;setUrl(URL.createObjectURL(file));setPoints([]);setMessage(file.name);};
 const point=e=>{const box=e.currentTarget.getBoundingClientRect();return {x:(e.clientX-box.left)/box.width,y:(e.clientY-box.top)/box.height};};
 const down=e=>{video.current?.pause();e.currentTarget.setPointerCapture(e.pointerId);setDrawing(true);setPoints([point(e)]);};
 const move=e=>{if(drawing)setPoints(p=>[...p,point(e)]);};
 const line=points.map(p=>(p.x*100).toFixed(2)+","+(p.y*100).toFixed(2)).join(" ");
 const save=()=>{const v=video.current;if(!v||v.readyState<2||points.length<2){setMessage("Pause a frame and draw the ball path first.");return;}
  const canvas=document.createElement("canvas");canvas.width=v.videoWidth;canvas.height=v.videoHeight;const ctx=canvas.getContext("2d");ctx.drawImage(v,0,0,canvas.width,canvas.height);
  ctx.beginPath();ctx.moveTo(points[0].x*canvas.width,points[0].y*canvas.height);points.slice(1).forEach(p=>ctx.lineTo(p.x*canvas.width,p.y*canvas.height));
  ctx.strokeStyle="#ffffff";ctx.lineWidth=Math.max(3,canvas.width*.004);ctx.lineCap="round";ctx.lineJoin="round";ctx.shadowColor="#ffffff";ctx.shadowBlur=5;ctx.stroke();
  canvas.toBlob(blob=>{if(!blob){setMessage("Could not save this frame.");return;}const link=document.createElement("a"),imageUrl=URL.createObjectURL(blob);link.href=imageUrl;link.download="DRC-shot-trace.png";link.click();setTimeout(()=>URL.revokeObjectURL(imageUrl),1000);setMessage("Trace image saved to your device.");},"image/png");
 };
 return <section className="tour-card"><h2>Shot Tracer</h2><p>Choose a golf video, pause at a frame, and draw the ball path with your finger. Save the marked frame. This is manual tracing; automatic ball tracking needs a native vision engine.</p><label className="tour-file">CHOOSE OR RECORD VIDEO<input type="file" accept="video/*" capture="environment" onChange={choose}/></label>{url&&<><div className="tracer-stage" style={{aspectRatio:ratio}}><video ref={video} src={url} controls playsInline onLoadedMetadata={e=>setRatio(e.currentTarget.videoWidth+" / "+e.currentTarget.videoHeight)}/><svg viewBox="0 0 100 100" preserveAspectRatio="none"><polyline points={line} fill="none" stroke="white" strokeWidth=".65" strokeLinecap="round" strokeLinejoin="round"/></svg><div className="tracer-touch" onPointerDown={down} onPointerMove={move} onPointerUp={()=>setDrawing(false)} onPointerCancel={()=>setDrawing(false)} aria-label="Draw the shot path"/></div><div className="tour-row"><button className="tour-button" onClick={()=>setPoints([])}>CLEAR TRACE</button><button className="tour-button gold-action" onClick={save}>SAVE MARKED FRAME</button></div></>}{message&&<p role="status">{message}</p>}</section>;
}
