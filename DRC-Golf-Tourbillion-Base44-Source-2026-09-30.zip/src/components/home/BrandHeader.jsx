import React from "react";

export default function BrandHeader({ greeting }) {
  return (
    <header className="flex flex-col items-center text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-full border border-gold/40">
        <span className="gold-text font-display text-base tracking-[0.16em]">DRC</span>
      </div>
      <h1 className="mt-5 font-display text-xl font-semibold uppercase tracking-[0.3em] text-foreground">
        DRC Golf
      </h1>
      <p className="mt-1.5 text-[0.6rem] font-medium uppercase tracking-[0.48em] text-gold/85">
        Tourbillion
      </p>
      <div className="gold-hairline mt-6 h-px w-24" />
      {greeting ? (
        <p className="mt-5 text-sm font-light text-muted-foreground">{greeting}</p>
      ) : null}
    </header>
  );
}