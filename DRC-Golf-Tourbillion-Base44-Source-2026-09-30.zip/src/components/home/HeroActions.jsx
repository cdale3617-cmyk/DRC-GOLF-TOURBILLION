import React from "react";
import { Flag, RotateCcw, ChevronRight } from "lucide-react";

export default function HeroActions({ onStart, onResume, resumeRound, loading }) {
  return (
    <section className="tour-home-hero surface-hero relative overflow-hidden rounded-[1.75rem] border border-gold/60 px-6 py-7">
      <p className="text-[0.6rem] font-medium uppercase tracking-[0.34em] text-gold/85">
        GOLF CADDIE · ROUND CONTROL
      </p>
      <h2 className="mt-3 font-display text-2xl leading-snug text-foreground">
        Every hole. Every decision.
      </h2>
      <p className="mt-2 max-w-[16rem] text-sm font-light leading-relaxed text-muted-foreground">
        Your course, clubs and card in one place.
      </p>

      <button
        type="button"
        onClick={onStart}
        className="mt-6 flex h-12 w-full items-center justify-center rounded-full bg-gold-sheen text-[0.72rem] font-semibold uppercase tracking-[0.2em] text-gold-foreground transition hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/60 focus-visible:ring-offset-2 focus-visible:ring-offset-background"
      >
        <Flag className="mr-2 h-4 w-4" />
        START CADDIE ENGINE
      </button>

      {resumeRound ? (
        <button
          type="button"
          onClick={onResume}
          className="mt-3 flex w-full items-center gap-3 rounded-2xl border border-gold/25 bg-secondary/40 px-4 py-3 text-left transition hover:border-gold/45 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/40"
        >
          <RotateCcw className="h-4 w-4 shrink-0 text-gold" />
          <span className="min-w-0 flex-1">
            <span className="block text-[0.72rem] font-semibold uppercase tracking-[0.18em] text-foreground">
              Resume Round
            </span>
            <span className="mt-0.5 block truncate text-xs font-light text-muted-foreground">
              {resumeRound.course_name}
            </span>
          </span>
          <ChevronRight className="h-4 w-4 shrink-0 text-gold/70" />
        </button>
      ) : (
        <div className="mt-3 flex items-center gap-3 rounded-2xl border border-border/70 px-4 py-3 opacity-70">
          <RotateCcw className="h-4 w-4 shrink-0 text-muted-foreground" />
          <span className="text-xs font-light text-muted-foreground">
            {loading ? "Checking for a round in progress…" : "No round in progress"}
          </span>
        </div>
      )}
    </section>
  );
}