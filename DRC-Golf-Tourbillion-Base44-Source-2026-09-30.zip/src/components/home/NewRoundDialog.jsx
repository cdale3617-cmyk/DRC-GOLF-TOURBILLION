import React, { useEffect, useState } from "react";
import { Flag, MapPin, ArrowLeft } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import CoursePicker from "@/components/CoursePicker";

export default function NewRoundDialog({
  open,
  onOpenChange,
  courses,
  initialCourse,
  onStart,
  submitting,
}) {
  const [course, setCourse] = useState(initialCourse || null);
  const [players, setPlayers] = useState("");

  useEffect(() => {
    if (open) {
      setCourse(initialCourse || null);
      setPlayers("");
    }
  }, [open, initialCourse]);

  const handleStart = () => {
    if (!course) return;
    onStart({
      course,
      players: players
        .split(",")
        .map((name) => name.trim())
        .filter(Boolean),
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-3xl border-gold/20 bg-card sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-foreground">
            Start a new round
          </DialogTitle>
          <DialogDescription className="text-xs font-light text-muted-foreground">
            {course ? "Confirm the course and tee off." : "Choose the course you're playing."}
          </DialogDescription>
        </DialogHeader>

        {course ? (
          <div className="space-y-4">
            <div className="surface-tile rounded-2xl border border-gold/20 p-4">
              <p className="font-display text-lg leading-snug text-foreground">{course.name}</p>
              <p className="mt-1 flex items-center gap-1.5 text-xs font-light text-muted-foreground">
                <MapPin className="h-3.5 w-3.5 text-gold/80" />
                {[course.location, course.country].filter(Boolean).join(", ")}
              </p>
              <p className="mt-3 text-[0.6rem] font-medium uppercase tracking-[0.24em] text-gold/85">
                {course.holes || 18} holes · Par {course.par || 72}
              </p>
            </div>

            <div>
              <label className="text-[0.6rem] font-medium uppercase tracking-[0.24em] text-muted-foreground">
                Players (optional)
              </label>
              <Input
                value={players}
                onChange={(event) => setPlayers(event.target.value)}
                placeholder="Your name, playing partners"
                className="mt-2 h-11 rounded-xl border-border/70 bg-background/60 text-sm font-light placeholder:text-muted-foreground/70 focus-visible:ring-gold/50"
              />
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setCourse(null)}
                className="flex h-11 items-center rounded-full px-4 text-[0.65rem] font-medium uppercase tracking-[0.2em] text-muted-foreground transition hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/40"
              >
                <ArrowLeft className="mr-1.5 h-3.5 w-3.5" />
                Change
              </button>
              <button
                type="button"
                disabled={submitting}
                onClick={handleStart}
                className="flex h-11 flex-1 items-center justify-center rounded-full bg-gold-sheen text-[0.68rem] font-semibold uppercase tracking-[0.2em] text-gold-foreground transition hover:opacity-90 disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/60"
              >
                <Flag className="mr-2 h-4 w-4" />
                {submitting ? "Starting…" : "Tee off"}
              </button>
            </div>
          </div>
        ) : (
          <CoursePicker
            courses={courses}
            onSelect={setCourse}
            autoFocus
            limit={5}
            placeholder="Search courses…"
          />
        )}
      </DialogContent>
    </Dialog>
  );
}