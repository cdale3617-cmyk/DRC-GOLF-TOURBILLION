import React from "react";
const art={
 "My Bag": <><path d="M29 24 40 17 66 19 73 26 68 66 Q48 75 29 63Z" fill="#174b37" stroke="#e1c274" strokeWidth="2"/><path d="M29 28 Q49 36 72 27M32 58 Q48 65 69 58" fill="none" stroke="#ead18a" strokeWidth="2"/><path d="M44 18 42 4M52 18 54 2M61 19 70 6" stroke="#d7c98d" strokeWidth="2"/><ellipse cx="42" cy="4" rx="7" ry="3" fill="#d2bd7c"/><path d="M54 3 Q61 0 64 5 L56 8Z" fill="#d2bd7c"/><path d="M69 6 Q77 0 80 7 L72 11Z" fill="#d2bd7c"/></>,
 "Courses": <><path d="M8 58 Q28 36 48 43 Q69 29 92 55 L87 67 Q45 76 11 64Z" fill="#2d7b4d" stroke="#b9a76c" strokeWidth="2"/><path d="M15 56 Q42 67 83 52M26 64 Q54 47 79 62" fill="none" stroke="#81a86c" opacity=".9"/><ellipse cx="59" cy="44" rx="15" ry="7" fill="#66a769"/><path d="M59 44V10" stroke="#e9d99c" strokeWidth="2"/><path d="M60 11 78 17 60 22Z" fill="#b74333"/><ellipse cx="76" cy="58" rx="8" ry="3" fill="#cbb787"/></>,
 "Golf Lab": <><path d="M14 17 80 12 87 55 19 62Z" fill="#112c28" stroke="#d8bd78" strokeWidth="3"/><path d="M21 24 74 20 78 48 25 53Z" fill="#193f38"/><path d="M26 46 35 37 45 39 54 27 64 32 74 23" fill="none" stroke="#d6c276" strokeWidth="2"/><path d="M56 39h3m4-5h3m4-9h3" stroke="#67a76c" strokeWidth="3"/><path d="M45 61v8m-19 1h41" stroke="#bda465" strokeWidth="3"/></>,
 "Records": <><path d="M25 14 70 11 75 65 29 69Z" fill="#705137" stroke="#d0aa6d" strokeWidth="2"/><path d="M31 20 65 18 69 58 34 61Z" fill="#e2d5ad"/><path d="M36 29 65 27M37 39 66 37M38 49 67 47M46 21l3 38M57 20l3 38" stroke="#8f9a78" strokeWidth="1.5"/><circle cx="59" cy="55" r="7" fill="#ba9b55" stroke="#fff0b9"/></>,
 "Scorecard": <><path d="M25 12 74 13 76 66 25 66Z" fill="#2f543e" stroke="#e2c67e" strokeWidth="3"/><path d="M31 19h38v39H31Z" fill="#e6d5a5"/><path d="M33 27h33M33 37h33M33 47h33M46 21v35M58 21v35" stroke="#8b9c77" strokeWidth="1.7"/><path d="M35 24h7M49 34h6M61 44h5" stroke="#9c4f32" strokeWidth="2.5"/><circle cx="72" cy="61" r="8" fill="#c8a35d" stroke="#ffeba9"/></>,
 "Profile": <><circle cx="50" cy="38" r="31" fill="#5c593b" stroke="#e4c989" strokeWidth="4"/><circle cx="50" cy="38" r="24" fill="#0c3125" stroke="#ac9a62"/><circle cx="50" cy="30" r="8" fill="#c8ad73"/><path d="M33 53 Q35 43 50 43 Q65 43 67 53" fill="#c8ad73"/><path d="M50 8V3M50 73v-5M18 38h6M76 38h6" stroke="#e9d79e" strokeWidth="2"/></>
};
export default function HomeTileArt({title}){
 const id=title.replaceAll(" ","");
 return <svg className="drc-tile-illustration" viewBox="0 0 100 80" role="img" aria-label={title+" illustration"}>
  <defs><filter id={"glow"+id} x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="3" dy="5" stdDeviation="3" floodColor="#00150e" floodOpacity=".85"/></filter></defs>
  <g filter={"url(#glow"+id+")"}>{art[title]}</g>
 </svg>;
}