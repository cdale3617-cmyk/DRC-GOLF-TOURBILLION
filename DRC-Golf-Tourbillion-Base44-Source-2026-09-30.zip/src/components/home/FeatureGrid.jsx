import React from "react";
import { Link } from "react-router-dom";
import { MapPin, BriefcaseBusiness, Activity, History } from "lucide-react";

const FEATURES = [
  { label: "My Bag", hint: "Clubs, carry and loft", to: "/bag", Icon: BriefcaseBusiness },
  { label: "Courses", hint: "Browse clubs", to: "/courses", Icon: MapPin },
  { label: "Golf Lab", hint: "Practice and tools", to: "/tools", Icon: Activity },
  { label: "Records", hint: "Rounds and scores", to: "/records", Icon: History },
];

export default function FeatureGrid() {
  return (
    <div className="grid grid-cols-2 gap-3">
      {FEATURES.map(({ label, hint, to, Icon }) => (
        <Link
          key={to}
          to={to}
          className="surface-tile rounded-2xl border border-border/70 px-4 py-4 transition hover:border-gold/35 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/40"
        >
          <Icon className="h-4 w-4 text-gold" />
          <p className="mt-3 text-sm text-foreground">{label}</p>
          <p className="mt-0.5 text-[0.7rem] font-light text-muted-foreground">{hint}</p>
        </Link>
      ))}
    </div>
  );
}