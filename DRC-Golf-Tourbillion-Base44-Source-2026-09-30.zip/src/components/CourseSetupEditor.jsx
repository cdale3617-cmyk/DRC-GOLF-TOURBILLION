import React,{useEffect,useState} from "react";
import { base44 } from "@/api/base44Client";
import "./CourseSetupEditor.css";
export default function CourseSetupEditor({course,onClose}){
 const count=Number(course.holes)||18;
 const [pars,setPars]=useState(()=>Array.from({length:count},(_,i)=>course.hole_pars?.[i]||"")),[distances,setDistances]=useState(()=>Array.from({length:count},(_,i)=>course.hole_distances?.[i]||"")),[setupId,setSetupId]=useState(null),[unit,setUnit]=useState("m"),[busy,setBusy]=useState(false),[message,setMessage]=useState("");
 useEffect(()=>{let active=true;base44.auth.me().then(me=>base44.entities.CourseSetup.filter({course_id:course.id,created_by_id:me.id},"-updated_date",1)).then(items=>{
  if(!active||!items[0])return;const data=items[0];setSetupId(data.id);setPars(Array.from({length:count},(_,i)=>data.hole_pars?.[i]||""));setDistances(Array.from({length:count},(_,i)=>data.hole_distances?.[i]||""));
 }).catch(()=>{});return()=>{active=false}},[course.id,count]);
 const change=(setter,i,value)=>setter(old=>old.map((x,j)=>j===i?value:x));
 const save=async()=>{
  if(pars.some(p=>p!==""&&(!Number.isInteger(Number(p))||Number(p)<3||Number(p)>6))||distances.some(d=>d!==""&&(!Number.isFinite(Number(d))||Number(d)<1))){setMessage("Par must be 3–6 and distance positive.");return;}
  setBusy(true);setMessage("");
  const payload={course_id:course.id,course_name:course.name,hole_pars:pars.map(p=>Number(p)||0),hole_distances:distances.map(d=>d===""?0:Math.round(Number(d)*(unit==="yd"?.9144:1)))};
  try{const item=setupId?await base44.entities.CourseSetup.update(setupId,payload):await base44.entities.CourseSetup.create(payload);setSetupId(item.id);setMessage("Hole card saved. New rounds will use these values.");}
  catch{setMessage("Could not save hole card.");}finally{setBusy(false);}
 };
 const toggle=()=>{setDistances(old=>old.map(v=>v===""?"":Math.round(Number(v)*(unit==="m"?1.09361:.9144))));setUnit(unit==="m"?"yd":"m");};
 return <section className="tour-card course-setup"><h2>{course.name} · Hole card</h2><p>Copy par and tee distances from your scorecard. Blanks stay unknown; the 3D map remains a schematic.</p><div className="tour-row"><button className="tour-button" onClick={toggle}>DISTANCE: {unit==="m"?"METRES":"YARDS"} ⇄</button><button className="tour-button" onClick={onClose}>CLOSE</button></div><div className="course-hole-head"><span>HOLE</span><span>PAR</span><span>TEE ({unit})</span></div>{pars.map((p,i)=><div className="course-hole-row" key={i}><strong>{i+1}</strong><input aria-label={"Hole "+(i+1)+" par"} type="number" inputMode="numeric" min="3" max="6" value={p} onChange={e=>change(setPars,i,e.target.value)}/><input aria-label={"Hole "+(i+1)+" tee distance "+unit} type="number" inputMode="numeric" min="1" value={distances[i]} onChange={e=>change(setDistances,i,e.target.value)}/></div>)}<p>Entered par total: {pars.reduce((a,p)=>a+(Number(p)||0),0)}</p><button className="tour-button gold-action" disabled={busy} onClick={save}>{busy?"SAVING…":"SAVE HOLE CARD"}</button>{message&&<p role="status">{message}</p>}</section>;
}