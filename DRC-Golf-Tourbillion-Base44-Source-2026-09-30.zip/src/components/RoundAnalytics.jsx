import React from "react";
import "./RoundAnalytics.css";
export default function RoundAnalytics({rounds}){
 const complete=rounds.filter(r=>r.status==="completed"&&Object.keys(r.scores||{}).length===(r.holes||18));
 const recent=complete.slice(0,8).reverse();
 const values=recent.map(r=>Object.values(r.scores||{}).reduce((n,s)=>n+(Number(s.gross)||0),0));
 const min=Math.min(...values,60),max=Math.max(...values,100);
 const exportCSV=()=>{
  const rows=[["Date","Course","Holes","Gross","Putts","Penalties"],...rounds.map(r=>{
   const scores=Object.values(r.scores||{});
   return [r.started_at||r.created_date||"",r.course_name||"",scores.length,scores.reduce((n,s)=>n+(Number(s.gross)||0),0),scores.reduce((n,s)=>n+(Number(s.putts)||0),0),scores.reduce((n,s)=>n+(Number(s.penalties)||0),0)];
  })];
  const csv=rows.map(row=>row.map(cell=>'"'+String(cell).replaceAll('"','""')+'"').join(",")).join("\r\n");
  const url=URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8"})),anchor=document.createElement("a");
  anchor.href=url;anchor.download="DRC-round-records.csv";anchor.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
 };
 return <section className="tour-card round-analytics"><h2>Score trend</h2><p>Completed rounds with every hole scored. Lower gross is better; courses may have different pars.</p>
 {recent.length?<div className="round-bars">{recent.map((r,i)=><div key={r.id} className="round-bar"><strong>{values[i]}</strong><span style={{height:(25+75*(max-values[i])/Math.max(1,max-min))+"%"}}/><small>{new Date(r.completed_at||r.created_date).toLocaleDateString(undefined,{day:"numeric",month:"short"})}</small></div>)}</div>:<p>Finish a full round to see your trend.</p>}
 <button className="tour-button" disabled={!rounds.length} onClick={exportCSV}>EXPORT ROUND RECORDS CSV</button>
 </section>;
}