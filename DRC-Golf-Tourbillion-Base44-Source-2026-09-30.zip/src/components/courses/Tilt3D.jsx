import React from "react";
import { motion, useSpring } from "framer-motion";

const REST_X = 7;
const REST_Y = -7;

export default function Tilt3D({ children, className = "", strength = 1 }) {
  const rx = useSpring(REST_X, { stiffness: 120, damping: 16 });
  const ry = useSpring(REST_Y, { stiffness: 120, damping: 16 });

  const move = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5;
    const y = (e.clientY - r.top) / r.height - 0.5;
    ry.set(x * 22 * strength);
    rx.set(REST_X - y * 18 * strength);
  };
  const leave = () => {
    rx.set(REST_X);
    ry.set(REST_Y);
  };

  return (
    <div className="[perspective:900px]" onPointerMove={move} onPointerLeave={leave}>
      <motion.div
        style={{ rotateX: rx, rotateY: ry, transformStyle: "preserve-3d" }}
        className={`relative shadow-[1px_1px_0_hsl(var(--gold-deep)/0.7),2px_2px_0_hsl(var(--gold-deep)/0.65),3px_3px_0_hsl(var(--gold-deep)/0.6),4px_4px_0_hsl(var(--gold-deep)/0.55),5px_5px_0_hsl(var(--gold-deep)/0.5),6px_6px_0_hsl(var(--gold-deep)/0.45),0_32px_36px_-16px_rgba(0,0,0,0.95)] ${className}`}
      >
        {children}
      </motion.div>
    </div>
  );
}