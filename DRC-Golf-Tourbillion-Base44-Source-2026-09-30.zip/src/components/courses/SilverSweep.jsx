import React from "react";
import { motion } from "framer-motion";

export default function SilverSweep({ duration = 4.5, delay = 0 }) {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden rounded-[inherit]" aria-hidden="true">
      <motion.div
        className="absolute inset-y-0 w-[3px] bg-gradient-to-b from-transparent via-slate-100 to-transparent shadow-[0_0_14px_5px_rgba(226,232,240,0.55)]"
        initial={{ left: "-4%" }}
        animate={{ left: "104%" }}
        transition={{ duration, delay, repeat: Infinity, repeatDelay: 1.2, ease: "easeInOut" }}
      />
    </div>
  );
}