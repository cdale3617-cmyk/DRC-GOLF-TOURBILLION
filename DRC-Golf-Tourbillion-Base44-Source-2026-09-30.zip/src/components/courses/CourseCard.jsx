import React from "react";
import { MapPin, Flag, Star } from "lucide-react";
import Tilt3D from "@/components/courses/Tilt3D";
import SilverSweep from "@/components/courses/SilverSweep";
import ClubCrest from "@/components/courses/ClubCrest";

export default function CourseCard({ course, index = 0 }) {
  return (
    <article className="mr-2 mb-2">
      <Tilt3D strength={0.7} className="surface-hero overflow-hidden rounded-2xl border border-gold/30 px-4 py-4">
        <div className="gold-hairline absolute inset-x-0 top-0 h-px" aria-hidden="true" />
        <div className="flex gap-4">
          <ClubCrest
            name={course.name}
            className="h-24 w-20 shrink-0 drop-shadow-[0_10px_10px_rgba(0,0,0,0.8)]"
          />
          <div className="min-w-0 flex-1">
            <div className="flex items-start justify-between gap-2">
              <h2 className="font-display text-base leading-snug text-foreground">{course.name}</h2>
              {course.rating ? (
                <span className="flex shrink-0 items-center gap-1 text-[0.65rem] font-medium text-gold">
                  <Star className="h-3 w-3" />
                  {course.rating}
                </span>
              ) : null}
            </div>
            <p className="mt-1.5 flex items-center gap-1.5 text-xs font-light text-muted-foreground">
              <MapPin className="h-3.5 w-3.5 shrink-0 text-gold/80" />
              <span className="truncate">
                {[course.location, course.country].filter(Boolean).join(", ") || "Location to be added"}
              </span>
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <span className="flex items-center gap-1.5 rounded-full border border-gold/25 px-3 py-1 text-[0.62rem] font-medium uppercase tracking-[0.14em] text-muted-foreground">
                <Flag className="h-3 w-3 text-gold/80" />
                {course.holes || 18} holes
              </span>
              <span className="rounded-full border border-gold/25 px-3 py-1 text-[0.62rem] font-medium uppercase tracking-[0.14em] text-muted-foreground">
                Par {course.par || 72}
              </span>
            </div>
          </div>
        </div>
        {course.notes ? (
          <p className="mt-3 text-xs font-light italic leading-relaxed text-muted-foreground/85">{course.notes}</p>
        ) : null}
        <SilverSweep duration={5} delay={index * 0.6} />
      </Tilt3D>
    </article>
  );
}