import React from "react";

const getInitials = (name = "") =>
  name
    .split(/\s+/)
    .filter((w) => w && !/^(golf|club|the|and|&|country|links|course)$/i.test(w))
    .slice(0, 2)
    .map((w) => w[0].toUpperCase())
    .join("") || "DRC";

export default function ClubCrest({ name, className = "" }) {
  const id = `g-${(name || "club").replace(/[^a-z0-9]/gi, "")}`;
  return (
    <svg viewBox="0 0 100 120" className={className} fill="none" role="img" aria-label={`${name} crest`}>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#8a6a25" />
          <stop offset="0.45" stopColor="#e2b752" />
          <stop offset="0.75" stopColor="#f3dc9c" />
          <stop offset="1" stopColor="#c9962f" />
        </linearGradient>
        <linearGradient id={`${id}-f`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0f3d2a" />
          <stop offset="1" stopColor="#050d09" />
        </linearGradient>
      </defs>
      <path d="M50 4 L92 18 V58 C92 88 72 106 50 116 C28 106 8 88 8 58 V18 Z" fill={`url(#${id}-f)`} stroke={`url(#${id})`} strokeWidth="2.5" />
      <path d="M50 11 L85 23 V57 C85 82 68 98 50 107 C32 98 15 82 15 57 V23 Z" stroke={`url(#${id})`} strokeWidth="0.9" opacity="0.7" />
      <g stroke={`url(#${id})`} strokeWidth="2" strokeLinecap="round">
        <path d="M26 34 L66 78" />
        <path d="M74 34 L34 78" />
        <path d="M62 76 L70 80 L66 84 L60 80 Z" fill={`url(#${id})`} />
        <path d="M38 76 L30 80 L34 84 L40 80 Z" fill={`url(#${id})`} />
      </g>
      <circle cx="50" cy="56" r="7" stroke={`url(#${id})`} strokeWidth="1.6" fill="#0a1a12" />
      <path d="M50 22 V40 M50 22 L62 27 L50 32" stroke={`url(#${id})`} strokeWidth="1.6" strokeLinejoin="round" />
      <text x="50" y="98" textAnchor="middle" fontSize="13" fontWeight="600" letterSpacing="2" fill={`url(#${id})`} style={{ fontFamily: "var(--font-display)" }}>
        {getInitials(name)}
      </text>
    </svg>
  );
}