import React from "react";
import { Image } from "@/components/ui/image";
import Tilt3D from "@/components/courses/Tilt3D";
import SilverSweep from "@/components/courses/SilverSweep";

const CREST_ARTWORK_URL =
  "https://media.base44.com/images/public/6abc1ffce2caa9810f084f74/2bbdbbd66_generated_59b7713b.png";

export default function CrestArtwork() {
  return (
    <div className="relative mx-auto w-full">
      <div className="pointer-events-none absolute -inset-8 rounded-[50%] bg-gold/10 blur-3xl" aria-hidden="true" />
      <Tilt3D className="rounded-[1.75rem] border border-gold/40 bg-card p-2">
        <div className="relative overflow-hidden rounded-[1.35rem]">
          <Image
            src={CREST_ARTWORK_URL}
            alt="Gold line crest: a golfer flanked by a driver, iron and putter"
            className="block h-48 w-full"
          />
          <SilverSweep />
        </div>
      </Tilt3D>
    </div>
  );
}