import React,{useEffect,useState} from "react";
import { Link,useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import "./LiveScores.css";

const boardData=round=>({
  code:round.live_code,round_id:round.id,course_name:round.course_name,
  holes:round.holes||18,players:round.players||[],
  scores:round.scores||{},partner_scores:round.partner_scores||{},
  updated_at:new Date().toISOString()
});
export async function syncLiveBoard(round){
 if(!round.live_board_id)return;
 try{await base44.entities.LiveBoard.update(round.live_board_id,boardData(round));}
 catch(error){console.warn("Live scores could not sync",error);}
}
export function LiveScoreControls({round,onRound}){
 const [busy,setBusy]=useState(false),[copied,setCopied]=useState(false),[error,setError]=useState("");
 const link=round.live_code?window.location.origin+"/live/"+round.live_code:"";
 const start=async()=>{
  setBusy(true);setError("");
  let board;
  try{
   const code=crypto.randomUUID().replaceAll("-","");
   board=await base44.entities.LiveBoard.create({...boardData({...round,live_code:code}),code});
   const next=await base44.entities.Round.update(round.id,{live_board_id:board.id,live_code:code});
   onRound(next);
  }catch{if(board?.id)await base44.entities.LiveBoard.delete(board.id).catch(()=>{});setError("Could not start live scores. Try again.");}
  finally{setBusy(false);}
 };
 const stop=async()=>{
  setBusy(true);setError("");
  try{
   await base44.entities.LiveBoard.delete(round.live_board_id);
   onRound(await base44.entities.Round.update(round.id,{live_board_id:"",live_code:""}));
  }catch{setError("Could not update sharing. Try again.");}finally{setBusy(false);}
 };
 const copy=async()=>{try{await navigator.clipboard.writeText(link);setCopied(true);}catch{setCopied(false);}};
 return <section className="tour-card live-control"><h2>Live scores</h2>
  <p>Start a public live board for player names, course and gross scores. Share its link with your group. Stop sharing whenever you want.</p>{error&&<p role="alert">{error}</p>}
  {round.live_board_id?<><div className="tour-inline"><input aria-label="Live scores link" value={link} readOnly/><button className="tour-button" onClick={copy}>{copied?"COPIED":"COPY LINK"}</button></div><Link className="tour-link" to={"/live/"+round.live_code}>OPEN LIVE BOARD →</Link><button className="tour-button" disabled={busy} onClick={stop}>STOP SHARING</button></>:<button className="tour-button gold-action" disabled={busy} onClick={start}>{busy?"STARTING…":"START LIVE SCORES"}</button>}
 </section>;
}
export default function LiveScores(){
 const {code}=useParams(),[board,setBoard]=useState(null),[loading,setLoading]=useState(true);
 useEffect(()=>{
  let active=true;
  base44.entities.LiveBoard.filter({code},"-updated_date",1).then(items=>{if(active){setBoard(items[0]||null);setLoading(false);}}).catch(()=>{if(active)setLoading(false)});
  const unsubscribe=base44.entities.LiveBoard.subscribe(event=>{if(!active)return;if(event.data?.code===code){setBoard(event.type==="delete"?null:event.data);}else if(event.type==="delete")setBoard(current=>current?.id===event.id?null:current);});
  const refresh=setInterval(()=>base44.entities.LiveBoard.filter({code},"-updated_date",1).then(items=>{if(active)setBoard(items[0]||null)}).catch(()=>{}),20000);
  return()=>{active=false;unsubscribe();clearInterval(refresh);};
 },[code]);
 if(loading)return <div className="tour-loading">Loading live scores…</div>;
 if(!board)return <main className="live-page"><h1>Live scores unavailable</h1><p>The link may have expired or sharing has stopped.</p><Link to="/">Home</Link></main>;
 const players=board.players?.length?board.players:["Player"], scores=board.scores||{}, partner=board.partner_scores||{};
 const playerScore=(i,h)=>i===0?scores[String(h)]?.gross:partner[String(i)]?.[String(h)];
 const total=i=>Array.from({length:board.holes||18},(_,x)=>Number(playerScore(i,x+1))||0).reduce((a,b)=>a+b,0);
 return <main className="live-page"><div className="live-shell"><small>DRC GOLF TOURBILLION · LIVE</small><h1>{board.course_name}</h1><p>Updated {board.updated_at?new Date(board.updated_at).toLocaleString():"recently"}</p><div className="live-overflow"><table><thead><tr><th>Player</th>{Array.from({length:board.holes||18},(_,i)=><th key={i}>{i+1}</th>)}<th>Total</th></tr></thead><tbody>{players.map((name,i)=><tr key={i}><th>{name}</th>{Array.from({length:board.holes||18},(_,j)=><td key={j}>{playerScore(i,j+1)??"—"}</td>)}<td><strong>{total(i)||"—"}</strong></td></tr>)}</tbody></table></div><p>Gross scores entered by the round owner. Refresh if the connection pauses.</p></div></main>;
}