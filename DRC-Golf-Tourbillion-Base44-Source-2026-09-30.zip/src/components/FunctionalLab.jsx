import React,{useEffect,useRef,useState} from "react";
import { base44 } from "@/api/base44Client";
import SwingTempo from "@/components/SwingTempo";
const KEY="drc-tourbillion-lab-v1", DIRTY="drc-tourbillion-lab-dirty";
const load=()=>{try{return JSON.parse(localStorage.getItem(KEY)||"{}")}catch{return {}}};
const number=x=>Number(x)||0;
export default function FunctionalLab({kind}){
 const [message,setMessage]=useState(""),[syncStatus,setSyncStatus]=useState("Loading practice log…"),[ready,setReady]=useState(false);
 const profileRef=useRef(null),savingRef=useRef(false),latestRef=useRef(null),versionRef=useRef(0);
 const [data,setData]=useState(load),[v,setV]=useState({club:"7 Iron",carry:"",side:"",distance:"",result:"",effort:"Half",heart:"",slope:"",direction:"L→R",elevation:"Uphill",shots:"",target:"",lie:"Fairway"});
 useEffect(()=>{let active=true;base44.auth.me().then(me=>base44.entities.PracticeProfile.filter({created_by_id:me.id},"-updated_date",1)).then(items=>{
  if(!active)return;const profile=items[0];if(profile){profileRef.current=profile.id;setData(local=>{const current=localStorage.getItem(DIRTY)==="1"?local:(profile.entries||{});localStorage.setItem(KEY,JSON.stringify(current));return current;});}
  setReady(true);setSyncStatus("Practice log ready");
 }).catch(()=>{if(active)setSyncStatus("Saved on this device; cloud unavailable")});return()=>{active=false};},[]);
 useEffect(()=>{if(!ready)return;latestRef.current=data;++versionRef.current;const flush=async()=>{if(savingRef.current)return;savingRef.current=true;const version=versionRef.current;setSyncStatus("Saving practice…");try{const snapshot=JSON.stringify(latestRef.current);if(profileRef.current)await base44.entities.PracticeProfile.update(profileRef.current,{entries:latestRef.current});else{const profile=await base44.entities.PracticeProfile.create({entries:latestRef.current});profileRef.current=profile.id;}if(versionRef.current===version&&localStorage.getItem(KEY)===snapshot)localStorage.removeItem(DIRTY);setSyncStatus("Practice saved to your account");}catch{setSyncStatus("Saved on this device; cloud unavailable");}finally{savingRef.current=false;if(versionRef.current>version)setTimeout(flush,700);}};const timer=setTimeout(flush,700);return()=>clearTimeout(timer);},[data,ready]);
 const entries=data[kind]||[];
 const change=(key,value)=>setV(old=>({...old,[key]:value}));
 const add=()=>{
  const required={Dispersion:["carry","side"],"Wedge Matrix":["carry"],"Putting Lab":["distance"],"Short Game":["distance","result"],"Green Reading":["slope"],Biometrics:["heart"],Kinetics:[],"Strokes Gained":["shots","target"]}[kind]||[];
  if(required.some(key=>v[key]===""||!Number.isFinite(Number(v[key])))){setMessage("Enter the measured values before saving.");return;}
  if((["Dispersion","Wedge Matrix"].includes(kind)&&Number(v.carry)<=0)||(kind==="Biometrics"&&(Number(v.heart)<30||Number(v.heart)>220))||(kind==="Short Game"&&(Number(v.distance)<=0||Number(v.distance)>100||Number(v.result)<0))||(kind==="Putting Lab"&&Number(v.distance)<=0)||(kind==="Green Reading"&&Number(v.slope)<0)||(kind==="Strokes Gained"&&(Number(v.shots)<0||Number(v.target)<0))){setMessage("Check the measurement range.");return;}
  setMessage("");const next={...data,[kind]:[{...v,at:new Date().toISOString()},...entries].slice(0,250)};setData(next);localStorage.setItem(KEY,JSON.stringify(next));localStorage.setItem(DIRTY,"1");setV(old=>({...old,carry:"",side:"",distance:"",result:"",heart:"",slope:"",shots:"",target:""}));};
 const remove=i=>{const next={...data,[kind]:entries.filter((_,j)=>i!==j)};setData(next);localStorage.setItem(KEY,JSON.stringify(next));localStorage.setItem(DIRTY,"1");};
 const addMeasured=item=>{const next={...data,Kinetics:[item,...entries].slice(0,250)};setData(next);localStorage.setItem(KEY,JSON.stringify(next));localStorage.setItem(DIRTY,"1");};
 const average=arr=>arr.length?arr.reduce((a,b)=>a+b,0)/arr.length:0;
 const field=(label,key,options)=><label>{label}{options?<select value={v[key]} onChange={e=>change(key,e.target.value)}>{options.map(o=><option key={o}>{o}</option>)}</select>:<input inputMode="decimal" type="number" value={v[key]} onChange={e=>change(key,e.target.value)} placeholder={label}/>}</label>;
 let fields,result,caption;
 if(kind==="Dispersion"){
  fields=<>{field("Club","club",["Driver","3 Wood","7 Iron","Wedge"])}{field("Carry (m)","carry")}{field("Miss (m; left negative)","side")}</>;
  const list=entries.filter(e=>e.club===v.club), sides=list.map(e=>number(e.side));
  result=list.length?list.length+" shots: average carry "+Math.round(average(list.map(e=>number(e.carry))))+" m; average miss "+average(sides).toFixed(1)+" m; spread "+Math.round(Math.sqrt(average(sides.map(x=>(x-average(sides))**2))))+" m.":"Add shots to see your pattern.";
  caption="Enter carry and signed left/right miss for each shot.";
 }else if(kind==="Wedge Matrix"){
  fields=<>{field("Club","club",["Pitching Wedge","Gap Wedge","Sand Wedge","Lob Wedge"])}{field("Effort","effort",["Quarter","Half","Three-quarter","Full"])}{field("Carry (m)","carry")}</>;
  const list=entries.filter(e=>e.club===v.club&&e.effort===v.effort);
  result=list.length?v.club+" "+v.effort+": "+Math.round(average(list.map(e=>number(e.carry))))+" m average from "+list.length+" shots.":"Log carries at different swing lengths.";
  caption="Build your personal wedge carry chart.";
 }else if(kind==="Putting Lab"){
  fields=<>{field("Putt length (m)","distance")}{field("Result","result",["Holed","Missed left","Missed right","Short","Long"])}</>;
  const made=entries.filter(e=>e.result==="Holed").length;
  result=entries.length?made+" of "+entries.length+" holed ("+Math.round(100*made/entries.length)+"%). Average length "+average(entries.map(e=>number(e.distance))).toFixed(1)+" m.":"Log putts to measure the result.";
  caption="Record real practice or round putts.";
 }else if(kind==="Short Game"){
  fields=<>{field("Shot distance (m)","distance")}{field("Lie","lie",["Fairway","Rough","Bunker","Fringe"])}{field("Finish distance (m)","result")}</>;
  result=entries.length?entries.filter(e=>number(e.result)<=3).length+" of "+entries.length+" finished within 3 m. Average finish "+average(entries.map(e=>number(e.result))).toFixed(1)+" m.":"Log shots inside 100 m.";
  caption="Enter distance to cup before and after each shot.";
 }else if(kind==="Green Reading"){
  fields=<>{field("Measured slope (%)","slope")}{field("Break","direction",["L→R","R→L","Straight"])}{field("Elevation","elevation",["Uphill","Downhill","Level"])}</>;
  result=entries.length?"Last reading: "+entries[0].slope+"% "+entries[0].direction+", "+entries[0].elevation+".":"Enter a measured slope.";
  caption="Manual reading. Camera depth measurement is not connected.";
 }else if(kind==="Biometrics"){
  fields=<>{field("Heart rate (bpm)","heart")}{field("Effort","effort",["Resting","Light","Moderate","Hard"])}</>;
  result=entries.length?"Last "+entries[0].heart+" bpm; average "+Math.round(average(entries.map(e=>number(e.heart))))+" bpm.":"Log an observed reading.";
  caption="Manual entry. Health sensors are not connected.";
 }else if(kind==="Kinetics"){
  fields=<>{field("Club","club",["Driver","7 Iron","Wedge"])}{field("Swing result","result",["Solid","Thin","Fat","Push","Pull","Slice","Hook"])}</>;
  const observed=entries.filter(e=>e.result);
  result=observed.length?observed.filter(e=>e.result==="Solid").length+" solid swings of "+observed.length+" observed.":"Log swings to spot a pattern.";
  caption="Observation log. Camera motion capture is not connected.";
 }else if(kind==="Strokes Gained"){
  fields=<>{field("Shots to hole out","shots")}{field("Your benchmark strokes","target")}</>;
  result=entries.length?"Versus your benchmark: "+entries.reduce((a,e)=>a+number(e.target)-number(e.shots),0).toFixed(1)+" strokes over "+entries.length+" situations.":"Add shots and a benchmark.";
  caption="Personal comparison only. Official strokes gained needs shot positions and reference data.";
 }else return null;
 return <section className="tour-card"><h2>{kind}</h2><p>{caption}</p><small role="status">{syncStatus}</small><div className="tour-form">{fields}</div><button type="button" className="tour-button gold-action" onClick={add}>SAVE ENTRY</button>{message&&<p role="alert">{message}</p>}<div className="tour-result"><strong>{result}</strong></div>{kind==="Kinetics"&&<SwingTempo onMeasured={addMeasured}/>}{entries.slice(0,12).map((e,i)=><div className="tour-entry" key={e.at+i}><span>{new Date(e.at).toLocaleDateString()} · {e.club||e.lie||e.direction||""} {e.ratio?e.ratio+":1 tempo":e.carry?e.carry+" m":e.distance?e.distance+" m":e.heart?e.heart+" bpm":e.slope?e.slope+"%":e.result||""}</span><button aria-label="Delete entry" onClick={()=>remove(i)}>×</button></div>)}</section>;
}
