import React,{useEffect,useState} from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
export function HoleInfo({round,hole,onRound,unit}) {
 const {toast}=useToast();
 const [par,setPar]=useState(""),[distance,setDistance]=useState(""),[lat,setLat]=useState(""),[lng,setLng]=useState(""),[saving,setSaving]=useState(false),[locating,setLocating]=useState(false),[accuracy,setAccuracy]=useState(null);
 useEffect(()=>{
  setPar(round.hole_pars?.[hole-1]||"");
  setDistance(round.hole_distances?.[hole-1]?Math.round(round.hole_distances[hole-1]*(unit==="yd"?1.09361:1)):"");
  setLat(round.hole_greens?.[hole-1]?.lat??"");setLng(round.hole_greens?.[hole-1]?.lng??"");
  setAccuracy(null);
 },[round.hole_pars,round.hole_distances,round.hole_greens,hole,unit]);
 const capture=()=>{
  if(!navigator.geolocation){toast({title:"Location is unavailable",variant:"destructive"});return;}
  setLocating(true);
  navigator.geolocation.getCurrentPosition(p=>{setLat(p.coords.latitude.toFixed(7));setLng(p.coords.longitude.toFixed(7));setAccuracy(Math.round(p.coords.accuracy));setLocating(false);toast({title:"Position captured. Save hole details to keep it."});},()=>{setLocating(false);toast({title:"Could not capture location",variant:"destructive"});},{enableHighAccuracy:true,timeout:15000,maximumAge:0});
 };
 const save=async()=>{
  const p=Number(par),d=Number(distance),latitude=Number(lat),longitude=Number(lng),hasPosition=lat!==""||lng!=="";
  if(!Number.isInteger(p)||p<3||p>6||!Number.isFinite(d)||d<=0){toast({title:"Enter par 3–6 and a positive tee distance",variant:"destructive"});return;}
  if(hasPosition&&(lat===""||lng===""||!Number.isFinite(latitude)||!Number.isFinite(longitude)||latitude< -90||latitude>90||longitude< -180||longitude>180)){toast({title:"Enter valid latitude and longitude",variant:"destructive"});return;}
  setSaving(true);
  const count=round.holes||18,pars=Array.from({length:count},(_,i)=>Number(round.hole_pars?.[i])||0),distances=Array.from({length:count},(_,i)=>Number(round.hole_distances?.[i])||0),greens=Array.from({length:count},(_,i)=>round.hole_greens?.[i]||{});
  pars[hole-1]=p;distances[hole-1]=Math.round(d*(unit==="yd"?.9144:1));greens[hole-1]=hasPosition?{lat:latitude,lng:longitude}:{};
  try{
   const changed=await base44.entities.Round.update(round.id,{hole_pars:pars,hole_distances:distances,hole_greens:greens});onRound(changed);
   let remembered=false;
   if(round.course_id){try{
    const me=await base44.auth.me();
    const matches=await base44.entities.CourseSetup.filter({course_id:round.course_id,created_by_id:me.id},"-updated_date",1);
    const payload={course_id:round.course_id,course_name:round.course_name,hole_pars:pars,hole_distances:distances,hole_greens:greens};
    if(matches[0])await base44.entities.CourseSetup.update(matches[0].id,payload);else await base44.entities.CourseSetup.create(payload);
    remembered=true;
   }catch{remembered=false;}}
   toast({title:remembered?"Saved for this course and round":"Saved for this round"});
  }catch{toast({title:"Could not save hole details",variant:"destructive"});}finally{setSaving(false);}
 };
 return <section className="tour-card"><h2>Hole {hole} details</h2><p>Enter par and tee distance from your card. For real GPS distance, save the green centre position while standing there, or enter verified coordinates. The 3D view remains schematic.</p>
  <div className="tour-form"><label>Par<input type="number" inputMode="numeric" min="3" max="6" value={par} onChange={e=>setPar(e.target.value)}/></label><label>Tee distance ({unit})<input type="number" inputMode="numeric" min="1" value={distance} onChange={e=>setDistance(e.target.value)}/></label><label>Green latitude<input type="number" inputMode="decimal" step="any" value={lat} onChange={e=>setLat(e.target.value)}/></label><label>Green longitude<input type="number" inputMode="decimal" step="any" value={lng} onChange={e=>setLng(e.target.value)}/></label></div>
  <button className="tour-button" disabled={locating} onClick={capture}>{locating?"LOCATING…":"CAPTURE GREEN POSITION"}</button>{accuracy!==null&&<p>Phone reported accuracy ±{accuracy} m. Check the point before using it.</p>}
  <button className="tour-button gold-action" disabled={saving} onClick={save}>SAVE HOLE DETAILS</button>
 </section>;
}
export function ShotLog({round,hole,onRound,clubs,unit}) {
 const {toast}=useToast();const [club,setClub]=useState("Driver"),[carry,setCarry]=useState(""),[side,setSide]=useState(""),[lie,setLie]=useState("Tee"),[result,setResult]=useState("Fairway"),[saving,setSaving]=useState(false);
 const shots=(round.shots||[]).filter(s=>s.hole===hole);
 const save=async()=>{const dist=Number(carry),miss=Number(side);if(!Number.isFinite(dist)||dist<0||carry===""||!Number.isFinite(miss)){toast({title:"Enter carry and left/right miss",variant:"destructive"});return;}
 setSaving(true);const next=[...(round.shots||[]),{hole,club,carry:Math.round(dist*(unit==="yd"?.9144:1)),side:Math.round(miss*(unit==="yd"?.9144:1)),lie,result,at:new Date().toISOString()}];
 try{onRound(await base44.entities.Round.update(round.id,{shots:next}));setCarry("");setSide("");toast({title:"Shot saved"});}catch{toast({title:"Could not save shot",variant:"destructive"});}finally{setSaving(false);}
 };
 const remove=async shot=>{try{onRound(await base44.entities.Round.update(round.id,{shots:(round.shots||[]).filter(s=>s!==shot)}));}catch{toast({title:"Could not remove shot",variant:"destructive"});}};
 const avg=shots.length?Math.round(shots.reduce((n,s)=>n+Number(s.carry),0)/shots.length):0;
 return <section className="tour-card"><h2>Shot log · Hole {hole}</h2><p>Record measured shots and your miss. Left is negative; right is positive. Entries stay with this round.</p><div className="tour-form"><label>Club<select value={club} onChange={e=>setClub(e.target.value)}>{clubs.map(c=><option key={c.name}>{c.name}</option>)}</select></label><label>Carry ({unit})<input type="number" inputMode="decimal" min="0" value={carry} onChange={e=>setCarry(e.target.value)}/></label><label>Left / right miss ({unit})<input type="number" inputMode="decimal" value={side} onChange={e=>setSide(e.target.value)}/></label><label>Lie<select value={lie} onChange={e=>setLie(e.target.value)}>{["Tee","Fairway","Rough","Sand","Green"].map(x=><option key={x}>{x}</option>)}</select></label><label>Result<select value={result} onChange={e=>setResult(e.target.value)}>{["Fairway","Green","Rough","Sand","Penalty","Holed"].map(x=><option key={x}>{x}</option>)}</select></label></div><button className="tour-button gold-action" disabled={saving} onClick={save}>SAVE SHOT</button><p>{shots.length} shots logged · Average carry {shots.length?Math.round(avg*(unit==="yd"?1.09361:1))+" "+unit:"—"}</p>{shots.map((s,i)=><div className="tour-entry" key={s.at+i}><span>{s.club} · {Math.round(s.carry*(unit==="yd"?1.09361:1))} {unit} · {Number(s.side)<0?"L":"R"} {Math.round(Math.abs(Number(s.side))*(unit==="yd"?1.09361:1))} {unit} · {s.result}</span><button onClick={()=>remove(s)} aria-label="Delete shot">×</button></div>)}</section>;
}