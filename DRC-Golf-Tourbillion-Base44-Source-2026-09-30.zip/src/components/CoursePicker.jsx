import React, { useMemo, useState } from "react";
import { Search, MapPin, ChevronRight } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function CoursePicker({
  courses,
  onSelect,
  placeholder = "Search by course or town",
  limit = 5,
  autoFocus = false,
}) {
  const [query, setQuery] = useState("");

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = q
      ? courses.filter((course) =>
          `${course.name} ${course.location || ""} ${course.country || ""}`
            .toLowerCase()
            .includes(q)
        )
      : courses;
    return list.slice(0, limit);
  }, [courses, query, limit]);

  return (
    <div>
      <div className="relative">
        <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-gold/70" />
        <Input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          autoFocus={autoFocus}
          placeholder={placeholder}
          className="h-12 rounded-full border-border/70 bg-card/70 pl-11 pr-4 text-sm font-light placeholder:text-muted-foreground/70 focus-visible:ring-gold/50"
        />
      </div>

      <ul className="mt-3 space-y-1.5">
        {results.map((course) => (
          <li key={course.id}>
            <button
              type="button"
              onClick={() => onSelect(course)}
              className="flex w-full items-center gap-3 rounded-2xl border border-transparent bg-card/50 px-4 py-3 text-left transition hover:border-gold/25 hover:bg-card focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/40"
            >
              <MapPin className="h-4 w-4 shrink-0 text-gold/80" />
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm text-foreground">{course.name}</span>
                <span className="mt-0.5 block truncate text-xs font-light text-muted-foreground">
                  {[
                    course.location,
                    `${course.holes || 18} holes`,
                    `Par ${course.par || 72}`,
                  ]
                    .filter(Boolean)
                    .join(" · ")}
                </span>
              </span>
              <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground/70" />
            </button>
          </li>
        ))}

        {results.length === 0 ? (
          <li className="rounded-2xl border border-dashed border-border/70 px-4 py-6 text-center text-xs font-light text-muted-foreground">
            No courses match &ldquo;{query}&rdquo;.
          </li>
        ) : null}
      </ul>
    </div>
  );
}