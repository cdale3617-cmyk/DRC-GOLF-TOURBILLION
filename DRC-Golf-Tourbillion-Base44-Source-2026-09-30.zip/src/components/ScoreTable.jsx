import React from "react";
import "./ScoreTable.css";
export default function ScoreTable({round,onHole}){
 const holes=round.holes||18,scores=round.scores||{},pars=round.hole_pars||[];
 const sum=(start,end,field)=>Array.from({length:end-start+1},(_,i)=>scores[String(start+i)]?.[field]).reduce((n,v)=>n+(Number(v)||0),0);
 const parSum=(start,end)=>pars.slice(start-1,end).reduce((n,v)=>n+(Number(v)||0),0);
 const row=(label,start,end)=><div className="score-total" key={label}><strong>{label}</strong><strong>{parSum(start,end)||"—"}</strong><strong>{sum(start,end,"gross")||"—"}</strong><strong>{sum(start,end,"putts")||"—"}</strong></div>;
 return <div className="score-table"><div className="score-head"><span>HOLE</span><span>PAR</span><span>GROSS</span><span>PUTTS</span></div>
  {Array.from({length:holes},(_,i)=><React.Fragment key={i+1}><button type="button" onClick={()=>onHole(i+1)} className="score-line"><span>{i+1}</span><span>{pars[i]||"—"}</span><span>{scores[String(i+1)]?.gross??"—"}</span><span>{scores[String(i+1)]?.putts??"—"}</span></button>{i===8&&row("OUT",1,9)}{i===17&&row("IN",10,18)}</React.Fragment>)}
  {row("TOTAL",1,holes)}
 </div>;
}