import React,{useEffect,useState} from "react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { syncLiveBoard } from "@/components/LiveScores";
import "./ScoreTableExtra.css";
export default function GroupScorecard({round,onRound}){
 const {toast}=useToast(),[hole,setHole]=useState(1),[values,setValues]=useState({}),[newName,setNewName]=useState(""),[saving,setSaving]=useState(false);
 const players=round.players?.length?round.players:["Player"];
 const partners=round.partner_scores||{};
 useEffect(()=>{const next={};players.slice(1).forEach((_,i)=>{next[i+1]=partners[String(i+1)]?.[String(hole)]??"";});setValues(next);},[hole,round.partner_scores,round.players]);
 const save=async()=>{if(players.slice(1).some((_,i)=>{const value=values[i+1];return value!==""&&value!=null&&(!Number.isInteger(Number(value))||Number(value)<1);})){toast({title:"Enter whole gross scores of one or more",variant:"destructive"});return;}setSaving(true);const next={...partners};
 players.slice(1).forEach((_,i)=>{const key=String(i+1),v=values[i+1];next[key]={...(partners[key]||{})};if(v===""||v==null)delete next[key][String(hole)];else next[key][String(hole)]=Number(v);});
 try{const changed=await base44.entities.Round.update(round.id,{partner_scores:next});onRound(changed);syncLiveBoard(changed);toast({title:"Group card saved"});}catch{toast({title:"Could not save group card",variant:"destructive"});}finally{setSaving(false);}};
 const add=async()=>{const name=newName.trim();if(!name)return;try{const changed=await base44.entities.Round.update(round.id,{players:[...players,name]});onRound(changed);syncLiveBoard(changed);setNewName("");toast({title:"Player added"});}catch{toast({title:"Could not add player",variant:"destructive"});}};
 const total=index=>index===0?Object.values(round.scores||{}).reduce((a,v)=>a+(Number(v.gross)||0),0):Object.values(partners[String(index)]||{}).reduce((a,v)=>a+(Number(v)||0),0);
 return <section className="tour-card"><h2>Group card</h2><p>Scores entered on this device are saved with the round. The first player uses the main scorecard.</p><div className="group-table"><div className="group-head"><span>PLAYER</span><span>HOLES</span><span>GROSS</span></div>{players.map((name,i)=><div className="group-line" key={i}><span>{name}</span><span>{i===0?Object.keys(round.scores||{}).length:Object.keys(partners[String(i)]||{}).length}</span><strong>{total(i)||"—"}</strong></div>)}</div>
 <div className="group-hole-scroll"><table><thead><tr><th>Hole</th>{players.map((name,i)=><th key={i}>{name}</th>)}</tr></thead><tbody>{Array.from({length:round.holes||18},(_,i)=><tr key={i}><th>{i+1}</th>{players.map((_,j)=><td key={j}>{j===0?round.scores?.[String(i+1)]?.gross??"—":partners[String(j)]?.[String(i+1)]??"—"}</td>)}</tr>)}</tbody></table></div>
 <div className="tour-inline"><input aria-label="Add player name" value={newName} onChange={e=>setNewName(e.target.value)} placeholder="Add playing partner"/><button type="button" className="tour-button" onClick={add}>ADD</button></div>
 {players.length>1&&<><div className="tour-form"><label>Hole<select value={hole} onChange={e=>setHole(Number(e.target.value))}>{Array.from({length:round.holes||18},(_,i)=><option key={i+1} value={i+1}>Hole {i+1}</option>)}</select></label>{players.slice(1).map((name,i)=><label key={i}>{name} gross<input type="number" inputMode="numeric" min="1" value={values[i+1]??""} onChange={e=>setValues(v=>({...v,[i+1]:e.target.value}))}/></label>)}</div><button type="button" className="tour-button gold-action" disabled={saving} onClick={save}>SAVE GROUP SCORES</button></>}
 </section>;
}
