import React from "react";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

export default function ComingSoon({ title, description }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background px-6 text-center">
      <div className="gold-hairline h-px w-16" />
      <h1 className="mt-6 font-display text-2xl leading-snug text-foreground">{title}</h1>
      <p className="mt-3 max-w-xs text-sm font-light leading-relaxed text-muted-foreground">
        {description || "This screen is next on the build list."}
      </p>
      <Link
        to="/"
        className="mt-8 inline-flex items-center gap-2 rounded-full border border-gold/30 px-5 py-2.5 text-[0.65rem] font-medium uppercase tracking-[0.2em] text-gold transition hover:border-gold/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/40"
      >
        <ArrowLeft className="h-3.5 w-3.5" />
        Home
      </Link>
    </div>
  );
}