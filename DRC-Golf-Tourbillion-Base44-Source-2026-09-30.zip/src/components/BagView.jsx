import React, { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import "./BagView.css";
const TYPES = ["Driver","Fairway Woods","Hybrids","Irons","Wedges","Putter"];
const initialType = (name) => /driver/i.test(name) ? "Driver" : /putter/i.test(name) ? "Putter" : /wedge/i.test(name) ? "Wedges" : /hybrid/i.test(name) ? "Hybrids" : /wood/i.test(name) ? "Fairway Woods" : "Irons";
const typeForClub = (club) => /driver/i.test(club.name||"") ? "Driver" : TYPES.includes(club.type) ? club.type : initialType(club.name||"");
export function ClubGraphic({ type, large=false }) {
  const head = type==="Driver" ? <path d="M30 147 Q39 127 70 127 Q102 126 116 142 Q120 155 99 161 L47 166 Q26 162 30 147Z"/> :
    type==="Fairway Woods" ? <path d="M38 147 Q43 131 69 129 Q98 127 109 142 Q108 157 89 161 L50 163 Q36 158 38 147Z"/> :
    type==="Hybrids" ? <path d="M42 142 Q56 129 86 132 Q108 138 108 154 Q92 164 56 160 Q42 157 42 142Z"/> :
    type==="Putter" ? <path d="M35 143 L107 141 Q115 144 112 153 L106 160 L41 160 Q34 156 35 143Z"/> :
    <path d="M47 134 Q71 140 107 133 L111 159 Q87 171 51 160Z"/>;
  return <svg className={large?"club-art club-art-large":"club-art"} viewBox="0 0 150 180" role="img" aria-label={type+" club illustration"}>
    <defs><linearGradient id={"metal-"+type.replaceAll(" ","")} x1="0" x2="1" y1="0" y2="1"><stop stopColor="#f7e6ae"/><stop offset=".35" stopColor="#b1a373"/><stop offset=".68" stopColor="#e8d79b"/><stop offset="1" stopColor="#776a48"/></linearGradient><linearGradient id="shaft-metal" x1="0" x2="1"><stop stopColor="#f5e7bc"/><stop offset=".5" stopColor="#8d957e"/><stop offset="1" stopColor="#ead7a0"/></linearGradient></defs>
    <path d="M72 133 L81 20" stroke="url(#shaft-metal)" strokeWidth="4" strokeLinecap="round"/>
    <path d="M81 19 L85 6" stroke="#101813" strokeWidth="9" strokeLinecap="round"/>
    <g fill={"url(#metal-"+type.replaceAll(" ","")+")"} stroke="#3c3a2b" strokeWidth="2">{head}</g>
    <path d="M51 150 Q76 158 103 148" fill="none" stroke="#fff3bd" strokeWidth="2" opacity=".7"/>
    <path d="M71 134 L78 39" stroke="#fff4c8" opacity=".55"/>
  </svg>;
}
export default function BagView({ clubs, unit, onUpdate, onUnit, onAdd, onRemove }) {
  const [open,setOpen]=useState("Driver");
  return <>
    <section className="tour-card bag-summary">
      <h2>Bag summary</h2>
      <p>{clubs.length} clubs · Carry in {unit==="m"?"metres":"yards"}. Add each club's make, model and measured carry.</p>
      <div className="bag-showcase"><ClubGraphic type="Driver" large/><ClubGraphic type="Irons" large/><ClubGraphic type="Putter" large/></div>
      <button className="tour-button" onClick={onUnit}>SWITCH TO {unit==="m"?"YARDS":"METRES"}</button>
      <button className="tour-button" onClick={onAdd}><Plus size={16}/> ADD CLUB</button>
    </section>
    {TYPES.map(type=>{
      const group=clubs.map((club,index)=>({club,index})).filter(({club})=>typeForClub(club)===type);
      return <section className="tour-card bag-section" key={type}>
        <button className="bag-section-title" onClick={()=>setOpen(open===type?"":type)} aria-expanded={open===type}><ClubGraphic type={type}/><span><strong>{type}</strong><small>{group.length} {group.length===1?"club":"clubs"}</small></span><b>{open===type?"−":"+"}</b></button>
        {open===type&&<div className="bag-clubs">
          {group.length===0&&<p>No clubs in this section. Use Add Club, then select this type.</p>}
          {group.map(({club,index})=><div className="bag-club" key={index}>
            <div className="bag-club-head"><ClubGraphic type={type}/><strong>{club.name||"New club"}</strong><button onClick={()=>onRemove(index)} aria-label={"Remove "+(club.name||"club")}><Trash2 size={17}/></button></div>
            <div className="bag-fields">
              <label>CLUB<input value={club.name} onChange={e=>onUpdate(index,"name",e.target.value)}/></label>
              <label>MAKE<input value={club.make||""} onChange={e=>onUpdate(index,"make",e.target.value)} placeholder="e.g. Titleist"/></label>
              <label>MODEL<input value={club.model||""} onChange={e=>onUpdate(index,"model",e.target.value)} placeholder="Model"/></label>
              <label>TYPE<select value={typeForClub(club)} onChange={e=>onUpdate(index,"type",e.target.value)}>{TYPES.map(item=><option key={item}>{item}</option>)}</select></label>
              <label>CARRY ({unit})<input type="number" inputMode="decimal" value={club.carry} onChange={e=>onUpdate(index,"carry",e.target.value)}/></label>
              <label>LOFT (°)<input type="number" inputMode="decimal" value={club.loft} onChange={e=>onUpdate(index,"loft",e.target.value)}/></label>
            </div>
          </div>)}
        </div>}
      </section>;
    })}
  </>;
}