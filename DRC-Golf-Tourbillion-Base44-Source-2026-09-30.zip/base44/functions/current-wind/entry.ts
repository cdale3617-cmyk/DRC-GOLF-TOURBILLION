import { createClientFromRequest } from "npm:@base44/sdk";
Deno.serve(async (req) => {
  try {
    const base44=createClientFromRequest(req);
    await base44.auth.me();
    const {latitude,longitude}=await req.json();
    const lat=Number(latitude),lon=Number(longitude);
    if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180) return Response.json({error:"Invalid location"},{status:400});
    const key=Deno.env.get("WEATHERAPI_KEY");
    if(!key) return Response.json({error:"Wind provider key not configured",code:"NO_WEATHER_KEY"},{status:503});
    const url=new URL("https://api.weatherapi.com/v1/current.json");
    url.searchParams.set("key",key);
    url.searchParams.set("q",lat+","+lon);
    url.searchParams.set("aqi","no");
    const response=await fetch(url,{headers:{"Accept":"application/json"}});
    if(!response.ok) return Response.json({error:"Wind provider unavailable"},{status:502});
    const data=await response.json(),current=data.current;
    return Response.json({speed_kph:current.wind_kph,gust_kph:current.gust_kph,from_degrees:current.wind_degree,from_compass:current.wind_dir,temperature_c:current.temp_c,observed_at:current.last_updated,source:"WeatherAPI.com",location_name:data.location?.name});
  }catch(error){return Response.json({error:"Could not load wind"},{status:500});}
});