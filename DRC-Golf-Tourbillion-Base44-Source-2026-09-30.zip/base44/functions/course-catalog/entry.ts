import { createClientFromRequest } from "npm:@base44/sdk";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    await base44.auth.me();
    const key = Deno.env.get("GOLF_COURSE_API_KEY");
    if (!key) return Response.json({ error: "Course provider key not configured", code: "NO_COURSE_KEY" }, { status: 503 });
    const body = await req.json();
    const action = body?.action;
    let url;
    if (action === "search") {
      const query = String(body.query || "").trim();
      if (query.length < 3 || query.length > 80) return Response.json({ error: "Enter at least 3 characters" }, { status: 400 });
      url = new URL("https://api.golfcourseapi.com/v1/search");
      url.searchParams.set("search_query", query);
    } else if (action === "detail") {
      const id = String(body.id || "").toLowerCase();
      if (!/^[0-9abcdefghjkmnpqrstvwxyz]{8}$/.test(id)) return Response.json({ error: "Invalid course ID" }, { status: 400 });
      url = new URL("https://api.golfcourseapi.com/v1/courses/" + id);
    } else return Response.json({ error: "Invalid action" }, { status: 400 });
    const response = await fetch(url, { headers: { Authorization: "Bearer " + key, Accept: "application/json" }, signal: AbortSignal.timeout(10000) });
    if (response.status === 429) return Response.json({ error: "Course search daily limit reached", code: "RATE_LIMIT" }, { status: 429 });
    if (!response.ok) return Response.json({ error: "Course provider unavailable", code: "PROVIDER_ERROR" }, { status: 502 });
    const data = await response.json();
    return Response.json(action === "search" ? { courses: Array.isArray(data.courses) ? data.courses.slice(0, 25) : [] } : { course: data });
  } catch {
    return Response.json({ error: "Could not load course data", code: "COURSE_ERROR" }, { status: 502 });
  }
});
