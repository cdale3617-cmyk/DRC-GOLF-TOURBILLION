---
name: Approved visual continuity
description: Distinguishing requested mobile identity continuity from verified parity with the external approved master.
---

The mobile build began without approved Base44 screen exports, source, or reference screenshots. Matching the stated palette and product structure does not prove exact screen parity.

**Why:** The user describes this as the next stage of an already approved product, not an invitation to invent a new visual direction.

**How to apply:** Before claiming an exact match or materially restyling a screen, obtain the approved reference assets and compare against them. Until then, describe visual continuity as following the supplied identity constraints rather than verified parity.