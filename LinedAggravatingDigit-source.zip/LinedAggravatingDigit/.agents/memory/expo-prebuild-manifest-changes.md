---
name: Expo prebuild manifest changes
description: Expo prebuild can modify workspace package manifests independently of dependency installation.
---

Inspect the mobile package manifest after Expo prebuild. It may add or relocate core runtime packages into a `dependencies` block even when prebuild runs with installation disabled. Reconcile those edits with the workspace's package-placement convention and lockfile rather than assuming the manifest was untouched.

**Why:** A prebuild in this workspace added a second core dependency block with versions that were not reflected in the pnpm lockfile. Keeping it would have introduced package-manager inconsistency.

**How to apply:** After every prebuild, inspect the package manifest diff and run the workspace's lockfile check before building or committing.