---
name: Android build environment
description: Replit-specific JVM and cache requirements for local Android Gradle builds.
---

For local Android Gradle builds in Replit, use JDK 17 with `GLIBC_TUNABLES=glibc.cpu.hwcaps=-AVX512F` and `JAVA_TOOL_OPTIONS=-XX:-UsePerfData -XX:TieredStopAtLevel=1`. Keep the Android SDK and Gradle user home inside the workspace, and point `ANDROID_HOME`, `ANDROID_SDK_ROOT`, and `GRADLE_USER_HOME` directly at those directories instead of relying on home-directory symlinks.

**Why:** GraalVM 19 and OpenJDK 17 C2 builds crashed in this environment; the JDK 17 C1 configuration progressed reliably. A workspace restart removed home-directory cache symlinks even though the workspace-local SDK and Gradle caches survived.

**How to apply:** Before building, confirm JDK 17 and set the compatibility flags. Use workspace-local cache paths, and after a restart reuse surviving Android build intermediates instead of cleaning or downloading the toolchain again.