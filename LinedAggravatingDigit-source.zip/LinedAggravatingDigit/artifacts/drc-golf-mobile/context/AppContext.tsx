import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AppState, CaptureRec, Club, Course, HoleScore, Shot, Units } from '@/lib/types';
import { uid } from '@/lib/units';

const KEY = 'drc-golf-tourbillion:v1';
const EMPTY: AppState = { profile: { name: '', units: 'm' }, courses: [], rounds: [], clubs: [], shots: [], captures: [] };

interface Ctx extends AppState {
  loaded: boolean;
  activeRound: AppState['rounds'][number] | undefined;
  setUnits: (u: Units) => void;
  setName: (n: string) => void;
  saveCourse: (c: Omit<Course, 'id'> & { id?: string }) => void;
  deleteCourse: (id: string) => void;
  startRound: (courseId: string) => string | null;
  endRound: (id: string) => void;
  deleteRound: (id: string) => void;
  setScore: (roundId: string, hole: number, patch: HoleScore) => void;
  saveClub: (c: Omit<Club, 'id'> & { id?: string }) => void;
  deleteClub: (id: string) => void;
  addShot: (s: Omit<Shot, 'id' | 'recordedAt'>) => void;
  deleteShot: (id: string) => void;
  addCapture: (r: Omit<CaptureRec, 'id'>) => void;
  deleteCapture: (id: string) => void;
  resetAll: () => void;
}
const AppCtx = createContext<Ctx | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState>(EMPTY);
  const [loaded, setLoaded] = useState(false);
  const ready = useRef(false);

  useEffect(() => {
    AsyncStorage.getItem(KEY)
      .then((raw) => { if (raw) setState({ ...EMPTY, ...JSON.parse(raw) }); })
      .catch(() => {})
      .finally(() => { ready.current = true; setLoaded(true); });
  }, []);
  useEffect(() => {
    if (ready.current) AsyncStorage.setItem(KEY, JSON.stringify(state)).catch(() => {});
  }, [state]);

  const activeRound = useMemo(() => state.rounds.find((r) => !r.endedAt), [state.rounds]);
  const upd = useCallback((f: (s: AppState) => AppState) => setState(f), []);

  const value = useMemo<Ctx>(() => ({
    ...state, loaded, activeRound,
    setUnits: (units) => upd((s) => ({ ...s, profile: { ...s.profile, units } })),
    setName: (name) => upd((s) => ({ ...s, profile: { ...s.profile, name } })),
    saveCourse: (c) => upd((s) => {
      const id = c.id ?? uid();
      const course: Course = { id, name: c.name, holes: c.holes };
      return { ...s, courses: s.courses.some((x) => x.id === id) ? s.courses.map((x) => (x.id === id ? course : x)) : [...s.courses, course] };
    }),
    deleteCourse: (id) => upd((s) => ({ ...s, courses: s.courses.filter((c) => c.id !== id) })),
    startRound: (courseId) => {
      const course = state.courses.find((c) => c.id === courseId);
      if (!course || state.rounds.some((r) => !r.endedAt)) return null;
      const id = uid();
      upd((s) => ({ ...s, rounds: [{ id, courseId, courseName: course.name, startedAt: new Date().toISOString(), holes: course.holes, scores: {} }, ...s.rounds] }));
      return id;
    },
    endRound: (id) => upd((s) => ({ ...s, rounds: s.rounds.map((r) => (r.id === id ? { ...r, endedAt: new Date().toISOString() } : r)) })),
    deleteRound: (id) => upd((s) => ({ ...s, rounds: s.rounds.filter((r) => r.id !== id) })),
    setScore: (roundId, hole, patch) => upd((s) => ({
      ...s, rounds: s.rounds.map((r) => (r.id === roundId ? { ...r, scores: { ...r.scores, [hole]: { ...r.scores[hole], ...patch } } } : r)),
    })),
    saveClub: (c) => upd((s) => {
      const id = c.id ?? uid();
      const club: Club = { ...c, id };
      return { ...s, clubs: s.clubs.some((x) => x.id === id) ? s.clubs.map((x) => (x.id === id ? club : x)) : [...s.clubs, club] };
    }),
    deleteClub: (id) => upd((s) => ({ ...s, clubs: s.clubs.filter((c) => c.id !== id) })),
    addShot: (sh) => upd((s) => ({ ...s, shots: [{ ...sh, id: uid(), recordedAt: new Date().toISOString() }, ...s.shots] })),
    deleteShot: (id) => upd((s) => ({ ...s, shots: s.shots.filter((x) => x.id !== id) })),
    addCapture: (r) => upd((s) => ({ ...s, captures: [{ ...r, id: uid() }, ...s.captures] })),
    deleteCapture: (id) => upd((s) => ({ ...s, captures: s.captures.filter((x) => x.id !== id) })),
    resetAll: () => upd((s) => ({ ...EMPTY, profile: s.profile })),
  }), [state, loaded, activeRound, upd]);

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}
export function useApp() {
  const c = useContext(AppCtx);
  if (!c) throw new Error('useApp must be used within AppProvider');
  return c;
}
