# DRC Golf Tourbillion — mobile integration boundary

This is a separate Android-first mobile foundation. It does not connect to, alter, or replace the approved Base44 web master. Approved screen exports and brand assets should be supplied before pixel-for-pixel parity can be verified.

## Working foundation

- Local on-device records, with no simulated rounds or sensor measurements.
- Foreground location requests only. Users explicitly request each fix. Distance calculation uses actual GPS coordinates and reports accuracy; it is not surveyed carry distance.
- Native video capture and library selection. A captured/imported video is a source recording, not a ball-flight trajectory or a completed swing analysis.
- Camera and location permission requests occur at the relevant action, not at app launch.
- Default distance storage is metres; yards are a presentation/input conversion.

## Native integration requirements

### Health and biometrics

Health measurements are different from fingerprint/face authentication. No authentication sensor should be presented as a heart-rate sensor.

Android Health Connect and iOS HealthKit adapters must:

1. Detect the native bridge, provider installation/version, hardware/data-source availability and consent independently.
2. Request only the data types required for the feature, with explicit user consent.
3. Return timestamp, units, source and measurement value with every record.
4. Distinguish unavailable, not connected, permission denied, no samples, and stale data.
5. Never derive an invented pulse, readiness score or calorie measurement from an empty stream.

The native adapters request read access only for heart rate and steps. Health Connect can report
granted read permissions and provider update status; its current React Native bridge does not expose
a numeric provider version. HealthKit intentionally does not expose whether read access was granted,
so an empty HealthKit query must be labelled as no readable samples with that ambiguity explained,
not as a definite denial or definite absence of data. Neither provider supplies a confidence score
for these measurements; report the source and timestamp and state when confidence is not provided.

Health Connect and HealthKit adapters and native permission configuration are implemented. Provider availability, type support and consent are checked independently at runtime. Physical-device support and returned sample sources are still **not verified**; a custom native build and real provider data are required.

### Green Reading

Android ARCore/depth and supported iOS AR/depth adapters must verify the native session and device capabilities at runtime. OS identity alone is not evidence that depth is available.

A useful surface reading requires depth samples, camera pose, scale, confidence and a calibrated coordinate frame. GPS altitude is not accurate enough to generate a putting slope. Phone orientation alone does not establish the slope of a green. Never draw a generated slope grid over an unmeasured surface.

Native AR/depth support checks and direct depth/mesh raycasting are implemented. Hardware compatibility and measurement behavior remain **unverified on physical devices**; no capability is inferred from the OS.

The depth adapter requires a live session capability check, camera consent and
normal tracking independently. Only direct depth/mesh hits in the native metric world frame may be
used for a measured surface plane. If the bridge does not expose sample confidence or provider
version, say so; do not substitute a calculated fit residual for sensor confidence. Surface tilt
alone is not a ball-to-hole break direction and must not produce an aim line.

### Shot Tracer and Swing Monitor

Source capture is available on compatible native devices after permission. Analysis needs a validated local/native or server pipeline, with model/version, calibration, timestamps, confidence, and explicit failure reporting. The foundation does not claim to detect a ball, club speed, launch angle, joint angles or a 3D trajectory.

### Courses and caddie

Manually entered course data is labelled as recorded, not certified course mapping. A pin coordinate supports straight-line GPS distance only. A mapped hole needs an actual course geometry source. No invented weather, hazards, elevations or club recommendations should be mistaken for verified course data.

## Data stewardship

Local records are not cloud-backed. Removing the app or clearing its storage can remove records. Camera/library URIs can become inaccessible if the underlying file is removed. Durable media archiving and backup/export are later work; never call a transient URI a cloud upload.

No account, external service, health provider or Base44 synchronization is configured. Do not add one without agreeing its scope and consent requirements.