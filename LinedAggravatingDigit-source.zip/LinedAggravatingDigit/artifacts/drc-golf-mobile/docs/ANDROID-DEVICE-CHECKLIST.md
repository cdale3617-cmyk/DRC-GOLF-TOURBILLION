# Android device acceptance checklist

This checklist is for subsequent real-device testing. Passing a browser preview does not certify physical sensors or native permissions.

## Launch and identity

- Launch on a physical Android phone; confirm green/black/gold identity and readable controls at narrow widths.
- Verify that every requested product area is accessible from navigation.
- Confirm no Base44 web-master changes or calls are made.

## Local records

- Create a course and configure holes, then begin a round.
- Record scores, putts and penalties; correct a score; finish the round.
- Relaunch and confirm round history and profile settings persist.
- Create, edit and remove an equipment record.
- Record measured shots; verify the dispersion view contains only these records.
- Confirm wedge summaries use recorded shots only.
- Switch metres to yards and back; verify conversions do not change stored distances.
- Deny/corrupt storage access where feasible; confirm errors are visible rather than claiming success.

## Location

- Request a GPS fix outdoors with foreground permissions granted.
- Confirm coordinates, timestamp and accuracy are from the actual device.
- Turn location services off; verify an actionable error, not fabricated coordinates.
- Deny permission; verify recovery guidance. Permanently deny; verify settings recovery.
- Mark a shot start/end; compare the result with an independently known distance, acknowledging GPS uncertainty.
- Enter a recorded pin coordinate and verify straight-line distance updates from a real fix.
- Confirm there is no background tracking.

## Camera/video

- Capture a short actual video; cancel capture; import a gallery video.
- Deny camera/microphone/library permissions and confirm recovery paths.
- Verify capture metadata persists and no analysis is claimed.
- Confirm no fabricated tracer overlays, joint angles or swing metrics.
- Delete a source file; confirm any failure to access it is handled honestly.

## Native extensions

- Biometrics must say the health integration is not connected and hardware/data support has not been verified.
- Green Reading must say the AR/depth integration is not connected; no fictitious slope data.
- Device support can only be established after installing and exercising the relevant native bridges.

## Remaining release gates

Physical device testing, durable media storage, backup/export, permission and privacy review, and verified native health/AR/analysis adapters are required before representing those advanced features as production-ready.