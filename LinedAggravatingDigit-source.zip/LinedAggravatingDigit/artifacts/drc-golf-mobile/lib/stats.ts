import type { Round, Shot } from './types';
export const mean = (a: number[]) => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0);
export function sd(a: number[]): number | null {
  if (a.length < 2) return null;
  const m = mean(a);
  return Math.sqrt(a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - 1));
}
export function roundTotals(r: Round) {
  let strokes = 0, putts = 0, penalties = 0, par = 0, played = 0;
  for (const h of r.holes) {
    const s = r.scores[h.number];
    if (s?.strokes != null) { strokes += s.strokes; par += h.par; played++; }
    putts += s?.putts ?? 0;
    penalties += s?.penalties ?? 0;
  }
  return { strokes, putts, penalties, par, played, toPar: strokes - par, totalPar: r.holes.reduce((s, h) => s + h.par, 0) };
}
export const fmtToPar = (n: number) => (n === 0 ? 'E' : n > 0 ? `+${n}` : `${n}`);
export function dispersion(shots: Shot[]) {
  const d = shots.map((s) => s.distanceM);
  const lat = shots.filter((s) => s.lateralM != null).map((s) => s.lateralM as number);
  return {
    n: shots.length, nLat: lat.length,
    meanDist: d.length ? mean(d) : null, sdDist: sd(d),
    minDist: d.length ? Math.min(...d) : null, maxDist: d.length ? Math.max(...d) : null,
    meanLat: lat.length ? mean(lat) : null, sdLat: sd(lat),
  };
}
