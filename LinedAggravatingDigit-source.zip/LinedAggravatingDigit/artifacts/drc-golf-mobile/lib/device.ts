import { Platform } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Linking from 'expo-linking';
import * as Location from 'expo-location';

export type GPSFix = {
  latitude: number;
  longitude: number;
  accuracy: number | null;
  timestamp: number;
};

export class CameraPermissionError extends Error {
  constructor(public readonly canAskAgain: boolean) {
    super(
      canAskAgain
        ? 'Camera access was denied. Allow camera access when prompted, or enable it in Settings.'
        : 'Camera access was denied. Enable camera access in Settings, then try again.',
    );
    this.name = 'CameraPermissionError';
  }
}

function browserLocationError(error: GeolocationPositionError): Error {
  if (error.code === error.PERMISSION_DENIED) {
    return new Error(
      'Location access was denied. Allow location access for this site in your browser settings, then try again.',
    );
  }
  if (error.code === error.POSITION_UNAVAILABLE) {
    return new Error(
      'Your browser could not determine a GPS position. Check that location services are enabled and try again.',
    );
  }
  return new Error(
    'The browser timed out while waiting for a GPS fix. Move to an area with a clearer view of the sky and try again.',
  );
}

export async function getGPSFix(): Promise<GPSFix> {
  if (Platform.OS === 'web') {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      throw new Error('This browser does not provide geolocation.');
    }

    return new Promise<GPSFix>((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        ({ coords, timestamp }) => {
          resolve({
            latitude: coords.latitude,
            longitude: coords.longitude,
            accuracy: Number.isFinite(coords.accuracy) ? coords.accuracy : null,
            timestamp,
          });
        },
        (error) => reject(browserLocationError(error)),
        { enableHighAccuracy: true, maximumAge: 0, timeout: 20000 },
      );
    });
  }

  let permission = await Location.getForegroundPermissionsAsync();
  if (!permission.granted) {
    permission = await Location.requestForegroundPermissionsAsync();
  }
  if (!permission.granted) {
    throw new Error(
      permission.canAskAgain
        ? 'Location permission was denied. Grant location access when prompted; if it was denied permanently, enable it in device Settings.'
        : 'Location permission was denied. Enable location access for this app in device Settings, then try again.',
    );
  }

  const servicesEnabled = await Location.hasServicesEnabledAsync();
  if (!servicesEnabled) {
    throw new Error(
      'Location Services are turned off. Turn them on in device Settings and try again.',
    );
  }

  const position = await Location.getCurrentPositionAsync({
    accuracy: Location.LocationAccuracy.High,
  });
  return {
    latitude: position.coords.latitude,
    longitude: position.coords.longitude,
    accuracy: position.coords.accuracy,
    timestamp: position.timestamp,
  };
}

export function distanceMetres(a: GPSFix, b: GPSFix): number {
  const earthRadiusMetres = 6_371_000;
  const toRadians = (degrees: number) => (degrees * Math.PI) / 180;
  const latitudeDelta = toRadians(b.latitude - a.latitude);
  const longitudeDelta = toRadians(b.longitude - a.longitude);
  const latitudeA = toRadians(a.latitude);
  const latitudeB = toRadians(b.latitude);
  const haversine =
    Math.sin(latitudeDelta / 2) ** 2 +
    Math.cos(latitudeA) *
      Math.cos(latitudeB) *
      Math.sin(longitudeDelta / 2) ** 2;

  return 2 * earthRadiusMetres * Math.asin(Math.sqrt(haversine));
}

export async function captureVideo(): Promise<{
  uri: string;
  recordedAt: string;
} | null> {
  if (Platform.OS === 'web') {
    throw new Error(
      'Video capture with the device camera is unavailable on web. Use Import instead.',
    );
  }

  let permission = await ImagePicker.getCameraPermissionsAsync();
  if (!permission.granted) {
    permission = await ImagePicker.requestCameraPermissionsAsync();
  }
  if (!permission.granted) {
    throw new CameraPermissionError(permission.canAskAgain);
  }

  const result = await ImagePicker.launchCameraAsync({ mediaTypes: ['videos'] });
  if (result.canceled) {
    return null;
  }

  const asset = result.assets[0];
  if (!asset || (asset.type && asset.type !== 'video')) {
    throw new Error('The camera did not return a video. Please try again.');
  }

  return { uri: asset.uri, recordedAt: new Date().toISOString() };
}

export async function importVideo(): Promise<{
  uri: string;
  recordedAt: string;
} | null> {
  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ['videos'],
  });
  if (result.canceled) {
    return null;
  }

  const asset = result.assets[0];
  if (!asset || (asset.type && asset.type !== 'video')) {
    throw new Error('The selected item is not a video. Please choose a video.');
  }

  return { uri: asset.uri, recordedAt: new Date().toISOString() };
}

export async function openDeviceSettings(): Promise<void> {
  if (Platform.OS === 'web') {
    throw new Error('Open your browser settings to change this site’s permissions.');
  }
  await Linking.openSettings();
}