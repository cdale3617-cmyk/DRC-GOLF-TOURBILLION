import { router } from 'expo-router';
import type { Feather } from '@expo/vector-icons';
type Icon = React.ComponentProps<typeof Feather>['name'];
export interface Tool { id: string; title: string; blurb: string; icon: Icon; group: 'Play' | 'Lab' | 'Records' | 'Setup' }
export const TOOLS: Tool[] = [
  { id: 'live', title: 'Live Hole', blurb: 'On-course caddie, GPS and scoring', icon: 'flag', group: 'Play' },
  { id: 'preround', title: 'Pre-Round', blurb: 'Pick a course and start a round', icon: 'play-circle', group: 'Play' },
  { id: 'scorecard', title: 'Scorecard', blurb: 'Edit score, putts, penalties', icon: 'edit-3', group: 'Play' },
  { id: 'greenreading', title: 'Green Reading', blurb: 'AR and depth capability status', icon: 'eye', group: 'Lab' },
  { id: 'tracer', title: 'Shot Tracer', blurb: 'Capture or import shot video', icon: 'video', group: 'Lab' },
  { id: 'swing', title: 'Swing Monitor', blurb: 'Capture swings, kinetics status', icon: 'activity', group: 'Lab' },
  { id: 'dispersion', title: 'Shot Pattern', blurb: 'Dispersion from measured shots', icon: 'crosshair', group: 'Lab' },
  { id: 'putting', title: 'Putting Practice', blurb: 'Log measured putts', icon: 'circle', group: 'Lab' },
  { id: 'shortgame', title: 'Short Game', blurb: 'Log pitches and wedge shots', icon: 'target', group: 'Lab' },
  { id: 'chipping', title: 'Greenside Chipping', blurb: 'Log chips by distance and offset', icon: 'corner-right-down', group: 'Lab' },
  { id: 'wedges', title: 'Wedge Matrix', blurb: 'Club by swing length from records', icon: 'grid', group: 'Lab' },
  { id: 'compare', title: 'Score Comparison', blurb: 'Compare two recorded rounds', icon: 'bar-chart-2', group: 'Records' },
  { id: 'overview', title: 'Round Overview', blurb: 'Totals for a recorded round', icon: 'layers', group: 'Records' },
  { id: 'history', title: 'Round History', blurb: 'Every round you have recorded', icon: 'clock', group: 'Records' },
  { id: 'biometrics', title: 'Biometrics', blurb: 'Health integration status', icon: 'heart', group: 'Records' },
  { id: 'courses', title: 'Courses', blurb: 'Create courses and hole data', icon: 'map', group: 'Setup' },
  { id: 'equipment', title: 'Equipment', blurb: 'Manage clubs', icon: 'briefcase', group: 'Setup' },
  { id: 'profile', title: 'Profile', blurb: 'Name and distance units', icon: 'user', group: 'Setup' },
  { id: 'howto', title: 'How To', blurb: 'Guides and limitations', icon: 'book-open', group: 'Setup' },
];
export function openTool(id: string, extra?: Record<string, string>) {
  if (id === 'live') { router.navigate('/caddie' as never); return; }
  router.push({ pathname: '/tool/[id]', params: { id, ...(extra ?? {}) } } as never);
}
