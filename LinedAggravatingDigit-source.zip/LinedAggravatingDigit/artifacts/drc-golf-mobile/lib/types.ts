export type Units = 'm' | 'yd';
export interface Coord { latitude: number; longitude: number }
export interface HoleDef { number: number; par: number; lengthM?: number; pin?: Coord }
export interface Course { id: string; name: string; holes: HoleDef[] }
export interface HoleScore { strokes?: number; putts?: number; penalties?: number }
export interface Round {
  id: string; courseId: string; courseName: string; startedAt: string; endedAt?: string;
  holes: HoleDef[]; scores: Record<number, HoleScore>;
}
export type ClubCategory = 'Driver' | 'Wood' | 'Hybrid' | 'Iron' | 'Wedge' | 'Putter' | 'Other';
export interface Club { id: string; name: string; category: ClubCategory; loftDeg?: number; brand?: string; notes?: string }
export type ShotContext = 'tee' | 'full' | 'wedge' | 'chip' | 'putt' | 'swing';
export interface Shot {
  id: string; recordedAt: string; clubId?: string; clubName?: string; context: ShotContext;
  distanceM: number; lateralM?: number; swingLength?: string; holed?: boolean; note?: string;
  source: 'manual' | 'gps'; gps?: { startAcc: number | null; endAcc: number | null }; roundId?: string;
}
export interface CaptureRec { id: string; uri: string; recordedAt: string; kind: string }
export interface Profile { name: string; units: Units }
export interface AppState {
  profile: Profile; courses: Course[]; rounds: Round[]; clubs: Club[]; shots: Shot[]; captures: CaptureRec[];
}
