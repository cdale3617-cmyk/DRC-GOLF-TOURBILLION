export interface DepthSurfacePoint {
  x: number;
  y: number;
  z: number;
}

export interface SurfaceTilt {
  degrees: number;
  fitResidualMetres: number;
  spanMetres: number;
}

/**
 * Fits y = ax + bz + c in the AR session's gravity-aligned, metre-scale world frame.
 * This reports plane tilt only; it does not infer a ball-to-hole break direction.
 */
export function fitDepthSurface(points: readonly DepthSurfacePoint[]): SurfaceTilt | null {
  if (points.length < 5 || points.some((p) => ![p.x, p.y, p.z].every(Number.isFinite))) {
    return null;
  }

  const meanX = points.reduce((sum, p) => sum + p.x, 0) / points.length;
  const meanY = points.reduce((sum, p) => sum + p.y, 0) / points.length;
  const meanZ = points.reduce((sum, p) => sum + p.z, 0) / points.length;

  let xx = 0;
  let zz = 0;
  let xz = 0;
  let xy = 0;
  let zy = 0;
  let spanMetres = 0;
  for (let i = 0; i < points.length; i += 1) {
    const a = points[i];
    const dx = a.x - meanX;
    const dy = a.y - meanY;
    const dz = a.z - meanZ;
    xx += dx * dx;
    zz += dz * dz;
    xz += dx * dz;
    xy += dx * dy;
    zy += dz * dy;
    for (let j = i + 1; j < points.length; j += 1) {
      const b = points[j];
      spanMetres = Math.max(
        spanMetres,
        Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z),
      );
    }
  }

  const determinant = xx * zz - xz * xz;
  if (spanMetres < 0.25 || determinant < 1e-8) return null;

  const slopeX = (xy * zz - zy * xz) / determinant;
  const slopeZ = (zy * xx - xy * xz) / determinant;
  const residualSquared = points.reduce((sum, point) => {
    const predictedY = meanY + slopeX * (point.x - meanX) + slopeZ * (point.z - meanZ);
    return sum + (point.y - predictedY) ** 2;
  }, 0);

  return {
    degrees: (Math.atan(Math.hypot(slopeX, slopeZ)) * 180) / Math.PI,
    fitResidualMetres: Math.sqrt(residualSquared / points.length),
    spanMetres,
  };
}