import { Platform } from 'react-native';

const HEART_RATE_MAX_AGE_MS = 30 * 60 * 1000;
const STEPS_MAX_AGE_MS = 24 * 60 * 60 * 1000;
const HEALTH_CONNECT_LOOKBACK_DAYS = 30;

export type HealthProviderStatus =
  | 'checking'
  | 'available'
  | 'not-installed'
  | 'update-required'
  | 'unavailable'
  | 'bridge-unavailable'
  | 'unsupported';

export type HealthConsentStatus =
  | 'not-requested'
  | 'granted'
  | 'partial'
  | 'denied'
  | 'read-status-hidden'
  | 'unavailable';

export type HealthMetricStatus =
  | 'not-requested'
  | 'permission-denied'
  | 'no-samples'
  | 'unavailable'
  | 'available'
  | 'stale'
  | 'error';

export interface HealthMetricSample {
  value: number;
  unit: 'bpm' | 'steps';
  measuredAt: string;
  source: string;
  device?: string;
  confidence: string;
}

export interface HealthMetricResult {
  status: HealthMetricStatus;
  sample?: HealthMetricSample;
  detail?: string;
}

export interface HealthIntegrationState {
  platform: 'android' | 'ios' | 'web' | 'other';
  bridge: 'available' | 'unavailable';
  provider: HealthProviderStatus;
  providerDetail: string;
  consent: HealthConsentStatus;
  heartRate: HealthMetricResult;
  steps: HealthMetricResult;
  healthTypes?: {
    heartRate: 'available' | 'unavailable';
    steps: 'available' | 'unavailable';
  };
  checkedAt?: string;
  error?: string;
}

const emptyMetric = (status: HealthMetricStatus): HealthMetricResult => ({
  status,
});

function initialState(): HealthIntegrationState {
  return {
    platform: Platform.OS === 'android' || Platform.OS === 'ios' ? Platform.OS : Platform.OS === 'web' ? 'web' : 'other',
    bridge: 'unavailable',
    provider: 'checking',
    providerDetail: 'Checking the native health provider.',
    consent: 'not-requested',
    heartRate: emptyMetric('not-requested'),
    steps: emptyMetric('not-requested'),
  };
}

function permissionGranted(
  permissions: readonly { accessType: string; recordType: string }[],
  recordType: 'HeartRate' | 'Steps',
): boolean {
  return permissions.some(
    (permission) => permission.accessType === 'read' && permission.recordType === recordType,
  );
}

function freshness(
  timestamp: string,
  maxAgeMs: number,
): 'available' | 'stale' {
  const sampleTime = new Date(timestamp).getTime();
  if (!Number.isFinite(sampleTime)) return 'stale';
  return Date.now() - sampleTime > maxAgeMs ? 'stale' : 'available';
}

function originName(origin?: string, device?: { manufacturer?: string; model?: string }): string {
  const deviceName = [device?.manufacturer, device?.model].filter(Boolean).join(' ');
  return [origin, deviceName].filter(Boolean).join(' · ') || 'Source not reported by provider';
}

function healthConnectErrorState(
  state: HealthIntegrationState,
  error: unknown,
): HealthIntegrationState {
  const message = error instanceof Error ? error.message : 'The native health provider returned an unknown error.';
  const bridgeMissing = /not linked|not using Expo Go|rebuild the app|native module|nitro|turbomodule/i.test(message);
  return {
    ...state,
    bridge: bridgeMissing ? 'unavailable' : state.bridge,
    provider: bridgeMissing ? 'bridge-unavailable' : state.provider === 'checking' ? 'unavailable' : state.provider,
    providerDetail: bridgeMissing
      ? 'The Health Connect native bridge is not included in this app build.'
      : state.providerDetail,
    error: message,
    checkedAt: new Date().toISOString(),
  };
}

async function inspectAndroid(): Promise<HealthIntegrationState> {
  const state = initialState();
  let healthConnect: typeof import('react-native-health-connect');
  try {
    healthConnect = await import('react-native-health-connect');
  } catch {
    return {
      ...state,
      provider: 'bridge-unavailable',
      providerDetail: 'The Health Connect native bridge is not included in this app build.',
    };
  }

  state.bridge = 'available';
  try {
    const sdkStatus = await healthConnect.getSdkStatus();
    if (sdkStatus === healthConnect.SdkAvailabilityStatus.SDK_UNAVAILABLE) {
      return {
        ...state,
        provider: 'not-installed',
        providerDetail: 'Health Connect is not available to this app on the device.',
        checkedAt: new Date().toISOString(),
      };
    }
    if (sdkStatus === healthConnect.SdkAvailabilityStatus.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED) {
      return {
        ...state,
        provider: 'update-required',
        providerDetail: 'The installed Health Connect provider needs an update.',
        checkedAt: new Date().toISOString(),
      };
    }
    if (sdkStatus !== healthConnect.SdkAvailabilityStatus.SDK_AVAILABLE) {
      return {
        ...state,
        provider: 'unavailable',
        providerDetail: `Health Connect returned an unrecognized availability status (${sdkStatus}).`,
        checkedAt: new Date().toISOString(),
      };
    }

    const initialized = await healthConnect.initialize();
    if (!initialized) {
      return {
        ...state,
        provider: 'unavailable',
        providerDetail: 'Health Connect is installed but its client could not initialize.',
        checkedAt: new Date().toISOString(),
      };
    }

    const permissions = await healthConnect.getGrantedPermissions();
    const hasHeartRate = permissionGranted(permissions, 'HeartRate');
    const hasSteps = permissionGranted(permissions, 'Steps');
    const consent: HealthConsentStatus = hasHeartRate && hasSteps
      ? 'granted'
      : hasHeartRate || hasSteps
        ? 'partial'
        : 'not-requested';
    return {
      ...state,
      bridge: 'available',
      provider: 'available',
      providerDetail: 'Health Connect SDK is available. Its current bridge reports availability and update-required status, but not a numeric provider version.',
      consent,
      heartRate: {
        status: 'not-requested',
        detail: hasHeartRate
          ? 'Read access is already granted. Tap Refresh health data to retrieve the latest sample.'
          : 'No heart-rate read permission is currently detected.',
      },
      steps: {
        status: 'not-requested',
        detail: hasSteps
          ? 'Read access is already granted. Tap Refresh health data to retrieve the latest sample.'
          : 'No steps read permission is currently detected.',
      },
      checkedAt: new Date().toISOString(),
    };
  } catch (error) {
    return healthConnectErrorState(state, error);
  }
}

async function readAndroidMetrics(
  healthConnect: typeof import('react-native-health-connect'),
  granted: { heartRate: boolean; steps: boolean },
): Promise<Pick<HealthIntegrationState, 'heartRate' | 'steps'>> {
  const now = new Date();
  const startTime = new Date(now.getTime() - HEALTH_CONNECT_LOOKBACK_DAYS * 24 * 60 * 60 * 1000).toISOString();
  const timeRangeFilter = { operator: 'between' as const, startTime, endTime: now.toISOString() };
  const [heartRateRecords, stepRecords] = await Promise.all([
    granted.heartRate
      ? healthConnect.readRecords('HeartRate', { timeRangeFilter, pageSize: 100, ascendingOrder: false })
      : Promise.resolve(undefined),
    granted.steps
      ? healthConnect.readRecords('Steps', { timeRangeFilter, pageSize: 100, ascendingOrder: false })
      : Promise.resolve(undefined),
  ]);

  const heartRateSamples = heartRateRecords?.records
    .flatMap((record) => record.samples.map((sample) => ({
      value: sample.beatsPerMinute,
      measuredAt: sample.time,
      source: originName(record.metadata?.dataOrigin, record.metadata?.device),
    })))
    .filter((sample) => Number.isFinite(sample.value) && Number.isFinite(new Date(sample.measuredAt).getTime()))
    .sort((a, b) => new Date(b.measuredAt).getTime() - new Date(a.measuredAt).getTime());
  const latestHeartRate = heartRateSamples?.[0];

  const latestStepsRecord = stepRecords?.records
    .filter((record) => Number.isFinite(record.count) && Number.isFinite(new Date(record.endTime).getTime()))
    .sort((a, b) => new Date(b.endTime).getTime() - new Date(a.endTime).getTime())[0];

  return {
    heartRate: !granted.heartRate
      ? { status: 'permission-denied', detail: 'Read access to heart rate was not granted.' }
      : latestHeartRate
        ? {
            status: freshness(latestHeartRate.measuredAt, HEART_RATE_MAX_AGE_MS),
            sample: {
              value: latestHeartRate.value,
              unit: 'bpm',
              measuredAt: latestHeartRate.measuredAt,
              source: latestHeartRate.source,
              confidence: 'Not reported by Health Connect.',
            },
          }
        : emptyMetric('no-samples'),
    steps: !granted.steps
      ? { status: 'permission-denied', detail: 'Read access to steps was not granted.' }
      : latestStepsRecord
        ? {
            status: freshness(latestStepsRecord.endTime, STEPS_MAX_AGE_MS),
            sample: {
              value: latestStepsRecord.count,
              unit: 'steps',
              measuredAt: latestStepsRecord.endTime,
              source: originName(latestStepsRecord.metadata?.dataOrigin, latestStepsRecord.metadata?.device),
              confidence: 'Not reported by Health Connect.',
            },
          }
        : emptyMetric('no-samples'),
  };
}

async function inspectIOS(): Promise<HealthIntegrationState> {
  const state = initialState();
  let healthKit: typeof import('@kingstinct/react-native-healthkit');
  try {
    healthKit = await import('@kingstinct/react-native-healthkit');
  } catch {
    return {
      ...state,
      provider: 'bridge-unavailable',
      providerDetail: 'The HealthKit native bridge is not included in this app build.',
    };
  }

  state.bridge = 'available';
  try {
    const available = await healthKit.isHealthDataAvailableAsync();
    if (!available) {
      return {
        ...state,
        provider: 'unavailable',
        providerDetail: 'HealthKit reports that health data is unavailable on this device.',
        consent: 'unavailable',
        checkedAt: new Date().toISOString(),
      };
    }
    const [heartRateAvailable, stepsAvailable] = await Promise.all([
      healthKit.isObjectTypeAvailableAsync('HKQuantityTypeIdentifierHeartRate'),
      healthKit.isObjectTypeAvailableAsync('HKQuantityTypeIdentifierStepCount'),
    ]);
    return {
      ...state,
      provider: 'available',
      providerDetail: 'HealthKit is available. iOS does not expose a numeric provider version or whether read access was granted.',
      consent: 'read-status-hidden',
      healthTypes: {
        heartRate: heartRateAvailable ? 'available' : 'unavailable',
        steps: stepsAvailable ? 'available' : 'unavailable',
      },
      checkedAt: new Date().toISOString(),
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown HealthKit bridge error.';
    const bridgeMissing = /not linked|not using Expo Go|rebuild the app|native module|nitro|turbomodule/i.test(message);
    return {
      ...state,
      bridge: bridgeMissing ? 'unavailable' : state.bridge,
      provider: bridgeMissing ? 'bridge-unavailable' : 'unavailable',
      providerDetail: bridgeMissing
        ? 'The HealthKit native bridge is not included in this app build.'
        : 'HealthKit availability could not be checked.',
      error: message,
      checkedAt: new Date().toISOString(),
    };
  }
}

export async function inspectHealthIntegration(): Promise<HealthIntegrationState> {
  if (Platform.OS === 'android') return inspectAndroid();
  if (Platform.OS === 'ios') return inspectIOS();
  const state = initialState();
  return {
    ...state,
    provider: 'unsupported',
    providerDetail: 'Health readings require a supported native Android or iOS build. Browser and Expo Go data is not used.',
    consent: 'unavailable',
  };
}

export async function requestHealthReadAccess(): Promise<HealthIntegrationState> {
  if (Platform.OS === 'android') {
    const base = await inspectAndroid();
    if (base.provider !== 'available') return base;
    try {
      const healthConnect = await import('react-native-health-connect');
      const permissions = await healthConnect.requestPermission([
        { accessType: 'read', recordType: 'HeartRate' },
        { accessType: 'read', recordType: 'Steps' },
      ]);
      const granted = {
        heartRate: permissionGranted(permissions, 'HeartRate'),
        steps: permissionGranted(permissions, 'Steps'),
      };
      const consent: HealthConsentStatus = granted.heartRate && granted.steps
        ? 'granted'
        : granted.heartRate || granted.steps
          ? 'partial'
          : 'denied';
      const metrics = await readAndroidMetrics(healthConnect, granted);
      return {
        ...base,
        consent,
        ...metrics,
        checkedAt: new Date().toISOString(),
      };
    } catch (error) {
      return healthConnectErrorState(base, error);
    }
  }

  if (Platform.OS === 'ios') {
    const base = await inspectIOS();
    if (base.provider !== 'available') return base;
    try {
      const healthKit = await import('@kingstinct/react-native-healthkit');
      const readableTypes: (
        | 'HKQuantityTypeIdentifierHeartRate'
        | 'HKQuantityTypeIdentifierStepCount'
      )[] = [];
      if (base.healthTypes?.heartRate === 'available') {
        readableTypes.push('HKQuantityTypeIdentifierHeartRate');
      }
      if (base.healthTypes?.steps === 'available') {
        readableTypes.push('HKQuantityTypeIdentifierStepCount');
      }
      if (readableTypes.length === 0) {
        return {
          ...base,
          heartRate: { status: 'unavailable', detail: 'HealthKit does not support the heart-rate record type on this device.' },
          steps: { status: 'unavailable', detail: 'HealthKit does not support the step-count record type on this device.' },
          checkedAt: new Date().toISOString(),
        };
      }
      await healthKit.requestAuthorization({
        toRead: readableTypes,
      });
      const [heartRateSamples, stepSamples] = await Promise.all([
        base.healthTypes?.heartRate === 'available'
          ? healthKit.queryQuantitySamples('HKQuantityTypeIdentifierHeartRate', {
              limit: 1,
              ascending: false,
              unit: 'count/min',
            })
          : Promise.resolve([]),
        base.healthTypes?.steps === 'available'
          ? healthKit.queryQuantitySamples('HKQuantityTypeIdentifierStepCount', {
              limit: 1,
              ascending: false,
              unit: 'count',
            })
          : Promise.resolve([]),
      ]);
      const heartRate = heartRateSamples[0];
      const steps = stepSamples[0];
      return {
        ...base,
        consent: 'read-status-hidden',
        heartRate: base.healthTypes?.heartRate !== 'available'
          ? { status: 'unavailable', detail: 'HealthKit does not support the heart-rate record type on this device.' }
          : heartRate
          ? {
              status: freshness(heartRate.startDate.toISOString(), HEART_RATE_MAX_AGE_MS),
              sample: {
                value: heartRate.quantity,
                unit: 'bpm',
                measuredAt: heartRate.startDate.toISOString(),
                source: heartRate.sourceRevision?.source.name ?? heartRate.sourceRevision?.source.bundleIdentifier ?? 'Source not reported by HealthKit',
                confidence: 'Not reported by HealthKit.',
              },
            }
          : {
              status: 'no-samples',
              detail: 'No readable heart-rate sample was returned. HealthKit does not reveal whether read access was denied or no sample exists.',
            },
        steps: base.healthTypes?.steps !== 'available'
          ? { status: 'unavailable', detail: 'HealthKit does not support the step-count record type on this device.' }
          : steps
          ? {
              status: freshness(steps.endDate.toISOString(), STEPS_MAX_AGE_MS),
              sample: {
                value: steps.quantity,
                unit: 'steps',
                measuredAt: steps.endDate.toISOString(),
                source: steps.sourceRevision?.source.name ?? steps.sourceRevision?.source.bundleIdentifier ?? 'Source not reported by HealthKit',
                confidence: 'Not reported by HealthKit.',
              },
            }
          : {
              status: 'no-samples',
              detail: 'No readable step sample was returned. HealthKit does not reveal whether read access was denied or no sample exists.',
            },
        checkedAt: new Date().toISOString(),
      };
    } catch (error) {
      return {
        ...base,
        error: error instanceof Error ? error.message : 'HealthKit did not complete the read request.',
        consent: 'read-status-hidden',
        checkedAt: new Date().toISOString(),
      };
    }
  }

  const state = await inspectHealthIntegration();
  return {
    ...state,
    consent: 'unavailable',
  };
}

export async function openHealthConnectProviderSettings(): Promise<void> {
  if (Platform.OS !== 'android') {
    throw new Error('Health Connect settings are only available on Android.');
  }
  const healthConnect = await import('react-native-health-connect');
  healthConnect.openHealthConnectSettings();
}