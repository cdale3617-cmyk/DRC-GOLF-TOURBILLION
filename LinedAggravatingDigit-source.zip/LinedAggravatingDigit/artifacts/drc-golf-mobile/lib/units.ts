import type { Units } from './types';
const YD = 0.9144;
export const toDisp = (m: number, u: Units) => (u === 'yd' ? m / YD : m);
export const fromDisp = (v: number, u: Units) => (u === 'yd' ? v * YD : v);
export const unitLabel = (u: Units) => (u === 'yd' ? 'yd' : 'm');
export const fmtDist = (m: number | undefined, u: Units, d = 0) =>
  m == null ? '--' : `${toDisp(m, u).toFixed(d)} ${unitLabel(u)}`;
export function parseNum(s: string): number | undefined {
  const t = s.trim().replace(',', '.');
  if (!t) return undefined;
  const n = Number(t);
  return Number.isFinite(n) ? n : undefined;
}
export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 9);
export const fmtDate = (iso: string) => {
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
};
