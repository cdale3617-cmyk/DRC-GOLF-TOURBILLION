import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useApp } from '@/context/AppContext';
import { Card, F, Label, confirmAction } from '@/components/ui';
import { fmtDate, fmtDist } from '@/lib/units';
import type { Shot } from '@/lib/types';
import { T } from '@/constants/colors';

export default function ShotList({ shots, limit = 8 }: { shots: Shot[]; limit?: number }) {
  const { profile, deleteShot } = useApp();
  if (!shots.length) return null;
  return (
    <Card>
      <Label>Recent records</Label>
      {shots.slice(0, limit).map((sh) => (
        <View key={sh.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, borderTopWidth: 1, borderTopColor: T.border, paddingTop: 8 }}>
          <View style={{ flex: 1 }}>
            <Text style={{ color: T.text, fontFamily: F.s, fontSize: 14 }}>
              {sh.clubName ?? 'No club'} - {fmtDist(sh.distanceM, profile.units, 1)}
              {sh.holed != null ? (sh.holed ? ' - holed' : ' - missed') : ''}
            </Text>
            <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 11.5 }}>
              {fmtDate(sh.recordedAt)} - {sh.context}{sh.swingLength ? ` - ${sh.swingLength}` : ''}
              {sh.lateralM != null ? ` - ${fmtDist(Math.abs(sh.lateralM), profile.units, 1)} ${sh.lateralM < 0 ? 'left' : 'right'}` : ''}
              {sh.source === 'gps' ? ' - GPS' : ''}
            </Text>
          </View>
          <Pressable testID={`delete-shot-${sh.id}`} hitSlop={10} onPress={() => confirmAction('Delete record', 'Remove this recorded shot?', () => deleteShot(sh.id))}>
            <Feather name="trash-2" size={16} color={T.muted} />
          </Pressable>
        </View>
      ))}
    </Card>
  );
}
