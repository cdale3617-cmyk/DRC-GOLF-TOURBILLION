import React, { ReactNode } from 'react';
import { KeyboardTypeOptions, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { T } from '@/constants/colors';
import { openTool } from '@/lib/tools';

type IconName = React.ComponentProps<typeof Feather>['name'];
export const F = { r: 'Inter_400Regular', m: 'Inter_500Medium', s: 'Inter_600SemiBold', b: 'Inter_700Bold' } as const;

export function confirmAction(title: string, msg: string, onYes: () => void) {
  if (Platform.OS === 'web') { if (typeof window !== 'undefined' && window.confirm(`${title}\n${msg}`)) onYes(); return; }
  const { Alert } = require('react-native') as typeof import('react-native');
  Alert.alert(title, msg, [{ text: 'Cancel', style: 'cancel' }, { text: 'Delete', style: 'destructive', onPress: onYes }]);
}

export function Screen({ title, eyebrow, back, tab, guide, children, right }: {
  title: string; eyebrow?: string; back?: boolean; tab?: boolean; guide?: string; children: ReactNode; right?: ReactNode;
}) {
  const ins = useSafeAreaInsets();
  const web = Platform.OS === 'web';
  const top = web ? 67 : ins.top;
  const bottom = tab ? (web ? 24 : Platform.OS === 'ios' ? ins.bottom + 76 : 24) : (web ? 34 : ins.bottom) + 32;
  return (
    <View style={{ flex: 1, backgroundColor: T.bg }}>
      <ScrollView contentContainerStyle={{ paddingTop: top + 10, paddingBottom: bottom, paddingHorizontal: 18, gap: 14 }} keyboardShouldPersistTaps="handled">
        <View style={s.head}>
          {back ? (
            <Pressable testID="back-button" onPress={() => (router.canGoBack() ? router.back() : router.navigate('/' as never))} hitSlop={12} style={s.iconBtn}>
              <Feather name="chevron-left" size={22} color={T.goldLight} />
            </Pressable>
          ) : null}
          <View style={{ flex: 1 }}>
            {eyebrow ? <Text style={s.eyebrow}>{eyebrow}</Text> : null}
            <Text style={s.title} numberOfLines={2}>{title}</Text>
          </View>
          {right}
          {guide ? (
            <Pressable testID="guide-button" onPress={() => openTool('howto', { topic: guide })} hitSlop={12} style={s.iconBtn}>
              <Feather name="help-circle" size={20} color={T.muted} />
            </Pressable>
          ) : null}
        </View>
        {children}
      </ScrollView>
    </View>
  );
}

export function Card({ children, style, gold }: { children: ReactNode; style?: object; gold?: boolean }) {
  return <View style={[s.card, gold && { borderColor: T.goldDeep }, style]}>{children}</View>;
}
export const Label = ({ children }: { children: ReactNode }) => <Text style={s.eyebrow}>{children}</Text>;
export const Body = ({ children, dim }: { children: ReactNode; dim?: boolean }) => (
  <Text style={{ fontFamily: F.r, fontSize: 14, lineHeight: 20, color: dim ? T.muted : T.text }}>{children}</Text>
);

export function Btn({ label, onPress, icon, variant = 'gold', disabled, testID, small }: {
  label: string; onPress: () => void; icon?: IconName; variant?: 'gold' | 'ghost' | 'danger'; disabled?: boolean; testID?: string; small?: boolean;
}) {
  const gold = variant === 'gold';
  const col = gold ? T.bg : variant === 'danger' ? T.red : T.goldLight;
  return (
    <Pressable testID={testID} disabled={disabled} onPress={onPress}
      style={({ pressed }) => [s.btn, small && { paddingVertical: 9, paddingHorizontal: 12 },
        gold ? { backgroundColor: T.gold } : { borderWidth: 1, borderColor: variant === 'danger' ? T.red : T.goldDeep },
        (disabled || pressed) && { opacity: 0.55 }]}>
      {icon ? <Feather name={icon} size={small ? 14 : 16} color={col} /> : null}
      <Text style={{ fontFamily: F.s, fontSize: small ? 12 : 14, color: col, letterSpacing: 0.3 }}>{label}</Text>
    </Pressable>
  );
}

export function Field({ label, value, onChangeText, keyboardType, placeholder, suffix, testID, multiline }: {
  label: string; value: string; onChangeText: (t: string) => void; keyboardType?: KeyboardTypeOptions; placeholder?: string; suffix?: string; testID?: string; multiline?: boolean;
}) {
  return (
    <View style={{ flex: 1, gap: 5 }}>
      <Text style={s.eyebrow}>{label}</Text>
      <View style={s.input}>
        <TextInput testID={testID} value={value} onChangeText={onChangeText} keyboardType={keyboardType} placeholder={placeholder}
          placeholderTextColor={T.muted} multiline={multiline} style={{ flex: 1, color: T.text, fontFamily: F.m, fontSize: 15, paddingVertical: 10 }} />
        {suffix ? <Text style={{ color: T.muted, fontFamily: F.m, fontSize: 12 }}>{suffix}</Text> : null}
      </View>
    </View>
  );
}

export function Chips<V extends string>({ options, value, onChange, testID }: {
  options: { value: V; label: string }[]; value: V | undefined; onChange: (v: V) => void; testID?: string;
}) {
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
      {options.map((o) => {
        const on = o.value === value;
        return (
          <Pressable key={o.value} testID={testID ? `${testID}-${o.value}` : undefined} onPress={() => onChange(o.value)}
            style={[s.chip, on && { backgroundColor: T.gold, borderColor: T.gold }]}>
            <Text style={{ fontFamily: F.s, fontSize: 12, color: on ? T.bg : T.text }}>{o.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export function Stepper({ label, value, onInc, onDec, testID }: { label: string; value: number | undefined; onInc: () => void; onDec: () => void; testID?: string }) {
  return (
    <View style={{ alignItems: 'center', gap: 4 }}>
      <Text style={s.eyebrow}>{label}</Text>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
        <Pressable testID={testID ? `${testID}-dec` : undefined} onPress={onDec} hitSlop={6} style={s.step}><Feather name="minus" size={14} color={T.goldLight} /></Pressable>
        <Text style={{ minWidth: 26, textAlign: 'center', color: T.text, fontFamily: F.b, fontSize: 17 }}>{value ?? '-'}</Text>
        <Pressable testID={testID ? `${testID}-inc` : undefined} onPress={onInc} hitSlop={6} style={s.step}><Feather name="plus" size={14} color={T.goldLight} /></Pressable>
      </View>
    </View>
  );
}

export function Empty({ icon, title, text, action }: { icon: IconName; title: string; text: string; action?: ReactNode }) {
  return (
    <Card style={{ alignItems: 'center', gap: 10, paddingVertical: 28 }}>
      <View style={s.emptyRing}><Feather name={icon} size={22} color={T.gold} /></View>
      <Text style={{ fontFamily: F.b, color: T.text, fontSize: 16, textAlign: 'center' }}>{title}</Text>
      <Text style={{ fontFamily: F.r, color: T.muted, fontSize: 13, lineHeight: 19, textAlign: 'center' }}>{text}</Text>
      {action}
    </Card>
  );
}

export function Stat({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <View style={{ flex: 1, minWidth: 90, gap: 2 }}>
      <Text style={s.eyebrow}>{label}</Text>
      <Text style={{ fontFamily: F.b, color: T.goldLight, fontSize: 22 }}>{value}</Text>
      {sub ? <Text style={{ fontFamily: F.r, color: T.muted, fontSize: 11 }}>{sub}</Text> : null}
    </View>
  );
}

export function Sheet({ visible, title, onClose, children }: { visible: boolean; title: string; onClose: () => void; children: ReactNode }) {
  const ins = useSafeAreaInsets();
  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' }}>
        <View style={{ backgroundColor: T.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, maxHeight: '92%', borderWidth: 1, borderColor: T.border }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', padding: 18, paddingBottom: 6 }}>
            <Text style={{ flex: 1, fontFamily: F.b, fontSize: 18, color: T.text }}>{title}</Text>
            <Pressable testID="sheet-close" onPress={onClose} hitSlop={12}><Feather name="x" size={22} color={T.muted} /></Pressable>
          </View>
          <ScrollView contentContainerStyle={{ padding: 18, gap: 14, paddingBottom: (Platform.OS === 'web' ? 34 : ins.bottom) + 24 }} keyboardShouldPersistTaps="handled">
            {children}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

export function Row({ children, gap = 10 }: { children: ReactNode; gap?: number }) {
  return <View style={{ flexDirection: 'row', gap, alignItems: 'flex-end' }}>{children}</View>;
}
export function ErrorText({ children }: { children?: string }) {
  return children ? <Text style={{ color: T.red, fontFamily: F.m, fontSize: 13 }}>{children}</Text> : null;
}

const s = StyleSheet.create({
  head: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 4 },
  eyebrow: { fontFamily: F.s, fontSize: 10.5, letterSpacing: 1.6, color: T.gold, textTransform: 'uppercase' },
  title: { fontFamily: F.b, fontSize: 28, color: T.text, letterSpacing: -0.5 },
  iconBtn: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: T.border },
  card: { backgroundColor: T.surface, borderRadius: 18, borderWidth: 1, borderColor: T.border, padding: 16, gap: 10 },
  btn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 13, paddingHorizontal: 18, borderRadius: 12 },
  input: { flexDirection: 'row', alignItems: 'center', backgroundColor: T.bg, borderRadius: 12, borderWidth: 1, borderColor: T.border, paddingHorizontal: 12 },
  chip: { paddingHorizontal: 13, paddingVertical: 8, borderRadius: 999, borderWidth: 1, borderColor: T.border, backgroundColor: T.bg },
  step: { width: 28, height: 28, borderRadius: 14, borderWidth: 1, borderColor: T.goldDeep, alignItems: 'center', justifyContent: 'center' },
  emptyRing: { width: 52, height: 52, borderRadius: 26, borderWidth: 1, borderColor: T.goldDeep, alignItems: 'center', justifyContent: 'center' },
});
