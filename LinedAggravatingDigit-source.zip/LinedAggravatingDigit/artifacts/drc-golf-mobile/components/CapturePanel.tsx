import React, { useState } from 'react';
import {
  ActivityIndicator,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import {
  CameraPermissionError,
  captureVideo,
  importVideo,
  openDeviceSettings,
} from '@/lib/device';

type CapturePanelProps = {
  title: string;
  onSave: (record: { uri: string; recordedAt: string; kind: string }) => void;
  kind: string;
};

type SavedVideo = {
  uri: string;
  recordedAt: string;
};

export default function CapturePanel({
  title,
  onSave,
  kind,
}: CapturePanelProps) {
  const colors = useColors();
  const [busyAction, setBusyAction] = useState<'capture' | 'import' | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showSettingsAction, setShowSettingsAction] = useState(false);
  const [video, setVideo] = useState<SavedVideo | null>(null);

  const handleVideoAction = async (action: 'capture' | 'import') => {
    setBusyAction(action);
    setError(null);
    setShowSettingsAction(false);
    try {
      const selectedVideo =
        action === 'capture' ? await captureVideo() : await importVideo();
      if (selectedVideo) {
        setVideo(selectedVideo);
        onSave({ ...selectedVideo, kind });
      }
    } catch (actionError) {
      const message =
        actionError instanceof Error
          ? actionError.message
          : 'The video could not be opened. Please try again.';
      setError(message);
      setShowSettingsAction(
        actionError instanceof CameraPermissionError &&
          !actionError.canAskAgain,
      );
    } finally {
      setBusyAction(null);
    }
  };

  const handleOpenSettings = async () => {
    try {
      await openDeviceSettings();
    } catch (settingsError) {
      setError(
        settingsError instanceof Error
          ? settingsError.message
          : 'Device settings could not be opened.',
      );
      setShowSettingsAction(false);
    }
  };

  return (
    <View
      style={[
        styles.panel,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          borderRadius: colors.radius,
        },
      ]}
    >
      <View style={styles.headingRow}>
        <View
          style={[
            styles.headingIcon,
            { backgroundColor: colors.secondary },
          ]}
        >
          <Feather name="video" size={18} color={colors.primary} />
        </View>
        <View style={styles.headingCopy}>
          <Text style={[styles.title, { color: colors.foreground }]}>
            {title}
          </Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            Add a swing video to this session
          </Text>
        </View>
      </View>

      <View style={styles.actions}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Capture video"
          disabled={busyAction !== null}
          onPress={() => handleVideoAction('capture')}
          style={({ pressed }) => [
            styles.actionButton,
            styles.primaryButton,
            {
              backgroundColor: colors.primary,
              borderRadius: colors.radius,
              opacity: busyAction !== null ? 0.55 : pressed ? 0.86 : 1,
            },
          ]}
          testID="capture-video-button"
        >
          {busyAction === 'capture' ? (
            <ActivityIndicator color={colors.primaryForeground} size="small" />
          ) : (
            <Feather name="video" size={17} color={colors.primaryForeground} />
          )}
          <Text style={[styles.actionText, { color: colors.primaryForeground }]}>
            {busyAction === 'capture' ? 'Opening camera…' : 'Capture video'}
          </Text>
        </Pressable>

        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Import a video"
          disabled={busyAction !== null}
          onPress={() => handleVideoAction('import')}
          style={({ pressed }) => [
            styles.actionButton,
            styles.secondaryButton,
            {
              backgroundColor: colors.secondary,
              borderColor: colors.border,
              borderRadius: colors.radius,
              opacity: busyAction !== null ? 0.55 : pressed ? 0.75 : 1,
            },
          ]}
          testID="import-video-button"
        >
          {busyAction === 'import' ? (
            <ActivityIndicator color={colors.secondaryForeground} size="small" />
          ) : (
            <Feather
              name="upload"
              size={17}
              color={colors.secondaryForeground}
            />
          )}
          <Text
            style={[styles.actionText, { color: colors.secondaryForeground }]}
          >
            {busyAction === 'import' ? 'Opening library…' : 'Import video'}
          </Text>
        </Pressable>
      </View>

      {Platform.OS === 'web' ? (
        <Text style={[styles.helper, { color: colors.mutedForeground }]}>
          Camera capture is unavailable on web. Import a video instead.
        </Text>
      ) : null}

      {error ? (
        <View
          accessibilityLiveRegion="polite"
          style={[
            styles.messageBox,
            {
              backgroundColor: colors.muted,
              borderColor: colors.border,
              borderRadius: colors.radius,
            },
          ]}
        >
          <Feather
            name="alert-circle"
            size={16}
            color={colors.destructive}
            style={styles.messageIcon}
          />
          <View style={styles.messageContent}>
            <Text style={[styles.errorText, { color: colors.destructive }]}>
              {error}
            </Text>
            {showSettingsAction ? (
              <Pressable
                accessibilityRole="button"
                onPress={handleOpenSettings}
                style={({ pressed }) => [
                  styles.settingsButton,
                  { opacity: pressed ? 0.7 : 1 },
                ]}
                testID="open-camera-settings-button"
              >
                <Feather
                  name="settings"
                  size={14}
                  color={colors.primary}
                />
                <Text style={[styles.settingsText, { color: colors.primary }]}>
                  Open Settings
                </Text>
              </Pressable>
            ) : null}
          </View>
        </View>
      ) : null}

      {video ? (
        <View
          style={[
            styles.resultBox,
            {
              backgroundColor: colors.background,
              borderColor: colors.border,
              borderRadius: colors.radius,
            },
          ]}
        >
          <View style={styles.resultHeading}>
            <Feather name="check-circle" size={16} color={colors.primary} />
            <Text style={[styles.resultTitle, { color: colors.foreground }]}>
              Video added
            </Text>
          </View>
          <Text
            selectable
            style={[styles.uri, { color: colors.mutedForeground }]}
            testID="video-result-uri"
          >
            {video.uri}
          </Text>
          <Text style={[styles.timestamp, { color: colors.mutedForeground }]}>
            Added {new Date(video.recordedAt).toLocaleString()}
          </Text>
        </View>
      ) : null}

      <View
        style={[
          styles.analysisNote,
          {
            borderTopColor: colors.border,
          },
        ]}
      >
        <Feather name="info" size={15} color={colors.mutedForeground} />
        <Text style={[styles.analysisText, { color: colors.mutedForeground }]}>
          Video analysis is not connected. No swing metrics or trajectories are
          generated.
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  panel: {
    width: '100%',
    padding: 18,
    borderWidth: 1,
    gap: 18,
  },
  headingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  headingIcon: {
    width: 42,
    height: 42,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 21,
  },
  headingCopy: {
    flex: 1,
    gap: 3,
  },
  title: {
    fontSize: 18,
    lineHeight: 24,
    fontWeight: '700',
  },
  subtitle: {
    fontSize: 13,
    lineHeight: 18,
  },
  actions: {
    gap: 10,
  },
  actionButton: {
    minHeight: 48,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 9,
    borderWidth: 1,
  },
  primaryButton: {
    borderColor: 'transparent',
  },
  secondaryButton: {},
  actionText: {
    fontSize: 15,
    fontWeight: '600',
  },
  helper: {
    marginTop: -8,
    fontSize: 12,
    lineHeight: 17,
  },
  messageBox: {
    padding: 12,
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  messageIcon: {
    marginTop: 2,
    marginRight: 9,
  },
  messageContent: {
    flex: 1,
    gap: 8,
  },
  errorText: {
    fontSize: 13,
    lineHeight: 19,
  },
  settingsButton: {
    minHeight: 36,
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  settingsText: {
    fontSize: 13,
    fontWeight: '600',
  },
  resultBox: {
    padding: 12,
    borderWidth: 1,
    gap: 7,
  },
  resultHeading: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
  },
  resultTitle: {
    fontSize: 14,
    fontWeight: '600',
  },
  uri: {
    fontSize: 12,
    lineHeight: 17,
  },
  timestamp: {
    fontSize: 11,
    lineHeight: 16,
  },
  analysisNote: {
    paddingTop: 13,
    borderTopWidth: StyleSheet.hairlineWidth,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
  },
  analysisText: {
    flex: 1,
    fontSize: 12,
    lineHeight: 17,
  },
});