import React, { useState } from 'react';
import { Text, View } from 'react-native';
import { useApp } from '@/context/AppContext';
import { Btn, Chips, ErrorText, Field, Label, Row } from '@/components/ui';
import { fromDisp, parseNum, unitLabel } from '@/lib/units';
import type { ShotContext } from '@/lib/types';
import { T } from '@/constants/colors';

const CTX_LABEL: Record<ShotContext, string> = { tee: 'Tee', full: 'Full', wedge: 'Wedge', chip: 'Chip', putt: 'Putt', swing: 'Swing' };
export const SWING_LENGTHS = ['Quarter', 'Half', 'Three-quarter', 'Full'];

export default function ShotForm({ contexts, distanceLabel = 'Measured distance', showSwingLength, showHoled, onSaved }: {
  contexts: ShotContext[]; distanceLabel?: string; showSwingLength?: boolean; showHoled?: boolean; onSaved?: () => void;
}) {
  const { clubs, profile, addShot, activeRound } = useApp();
  const u = profile.units;
  const [context, setContext] = useState<ShotContext>(contexts[0]);
  const [clubId, setClubId] = useState<string>('');
  const [swing, setSwing] = useState<string>('');
  const [dist, setDist] = useState('');
  const [side, setSide] = useState<'L' | 'R'>('R');
  const [lat, setLat] = useState('');
  const [holed, setHoled] = useState<'yes' | 'no' | ''>('');
  const [note, setNote] = useState('');
  const [err, setErr] = useState('');

  const save = () => {
    const d = parseNum(dist);
    if (d == null || d <= 0) { setErr('Enter a distance greater than zero.'); return; }
    const l = parseNum(lat);
    if (lat.trim() && l == null) { setErr('Lateral offset must be a number.'); return; }
    if (showHoled && !holed) { setErr('Record whether the putt was holed.'); return; }
    const club = clubs.find((c) => c.id === clubId);
    addShot({
      context, distanceM: fromDisp(d, u), source: 'manual', roundId: activeRound?.id,
      lateralM: l == null ? undefined : fromDisp(Math.abs(l), u) * (side === 'L' ? -1 : 1),
      clubId: club?.id, clubName: club?.name, swingLength: swing || undefined,
      holed: showHoled ? holed === 'yes' : undefined, note: note.trim() || undefined,
    });
    setDist(''); setLat(''); setNote(''); setErr(''); setHoled('');
    onSaved?.();
  };

  return (
    <View style={{ gap: 12 }}>
      {contexts.length > 1 ? (<><Label>Context</Label><Chips testID="shot-context" options={contexts.map((c) => ({ value: c, label: CTX_LABEL[c] }))} value={context} onChange={setContext} /></>) : null}
      <Label>Club</Label>
      {clubs.length ? (
        <Chips testID="shot-club" options={[{ value: '', label: 'None' }, ...clubs.map((c) => ({ value: c.id, label: c.name }))]} value={clubId} onChange={setClubId} />
      ) : <Text style={{ color: T.muted, fontSize: 12 }}>No clubs in your bag yet. You can still record without one.</Text>}
      {showSwingLength ? (<><Label>Swing length</Label><Chips testID="shot-swing" options={SWING_LENGTHS.map((x) => ({ value: x, label: x }))} value={swing} onChange={setSwing} /></>) : null}
      <Row>
        <Field testID="shot-distance" label={distanceLabel} value={dist} onChangeText={setDist} keyboardType="decimal-pad" suffix={unitLabel(u)} />
        <Field testID="shot-lateral" label="Lateral offset (optional)" value={lat} onChangeText={setLat} keyboardType="decimal-pad" suffix={unitLabel(u)} />
      </Row>
      <Label>Offset side</Label>
      <Chips testID="shot-side" options={[{ value: 'L', label: 'Left of target' }, { value: 'R', label: 'Right of target' }]} value={side} onChange={setSide} />
      {showHoled ? (<><Label>Holed</Label><Chips testID="shot-holed" options={[{ value: 'yes', label: 'Holed' }, { value: 'no', label: 'Missed' }]} value={holed} onChange={setHoled} /></>) : null}
      <Field testID="shot-note" label="Note (optional)" value={note} onChangeText={setNote} />
      <ErrorText>{err}</ErrorText>
      <Btn testID="shot-save" label="Record shot" icon="check" onPress={save} />
    </View>
  );
}
