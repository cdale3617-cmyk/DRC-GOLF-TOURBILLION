import React from 'react';
import { useLocalSearchParams } from 'expo-router';
import { Screen, Empty } from '@/components/ui';
import ClubManager from '@/screens/Equipment';
import Courses from '@/screens/Courses';
import { PreRound, ScorecardScreen } from '@/screens/Rounds';
import { History, Compare, Overview } from '@/screens/Records';
import { Dispersion, WedgeMatrix } from '@/screens/Analysis';
import { Putting, ShortGame, Chipping } from '@/screens/Practice';
import { Tracer, SwingMonitor } from '@/screens/Capture';
import { Biometrics, GreenReading, ProfileScreen, HowTo } from '@/screens/Info';

export default function ToolRoute() {
  const p = useLocalSearchParams<{ id: string; rid?: string; topic?: string }>();
  switch (p.id) {
    case 'equipment': return <ClubManager />;
    case 'courses': return <Courses />;
    case 'preround': return <PreRound />;
    case 'scorecard': return <ScorecardScreen rid={p.rid} />;
    case 'history': return <History />;
    case 'compare': return <Compare />;
    case 'overview': return <Overview rid={p.rid} />;
    case 'dispersion': return <Dispersion />;
    case 'wedges': return <WedgeMatrix />;
    case 'putting': return <Putting />;
    case 'shortgame': return <ShortGame />;
    case 'chipping': return <Chipping />;
    case 'tracer': return <Tracer />;
    case 'swing': return <SwingMonitor />;
    case 'biometrics': return <Biometrics />;
    case 'greenreading': return <GreenReading />;
    case 'profile': return <ProfileScreen />;
    case 'howto': return <HowTo topic={p.topic} />;
    default:
      return <Screen back title="Not found"><Empty icon="alert-circle" title="Unknown tool" text="This tool does not exist." /></Screen>;
  }
}
