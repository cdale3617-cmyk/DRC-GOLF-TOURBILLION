import LiveHole from '@/screens/LiveHole';
export default function CaddieTab() { return <LiveHole />; }
