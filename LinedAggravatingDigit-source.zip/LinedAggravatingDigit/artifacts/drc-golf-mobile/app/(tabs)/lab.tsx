import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { Screen, Card, Label, F } from '@/components/ui';
import { TOOLS, openTool } from '@/lib/tools';
import { useApp } from '@/context/AppContext';
import { T } from '@/constants/colors';

export default function LabTab() {
  const { shots, captures } = useApp();
  const tools = TOOLS.filter((t) => t.group === 'Lab');
  return (
    <Screen tab eyebrow="Measured practice" title="Golf Lab">
      <Card gold>
        <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 13, lineHeight: 19 }}>
          Everything here is built from what you record. {shots.length} measured shot{shots.length === 1 ? '' : 's'} and {captures.length} capture{captures.length === 1 ? '' : 's'} on this device.
        </Text>
      </Card>
      {tools.map((t) => (
        <Pressable key={t.id} testID={`lab-tool-${t.id}`} onPress={() => openTool(t.id)}>
          <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
            <View style={{ width: 42, height: 42, borderRadius: 21, borderWidth: 1, borderColor: T.goldDeep, alignItems: 'center', justifyContent: 'center' }}>
              <Feather name={t.icon} size={18} color={T.gold} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: T.text, fontFamily: F.b, fontSize: 16 }}>{t.title}</Text>
              <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 12.5 }}>{t.blurb}</Text>
            </View>
            <Feather name="chevron-right" size={18} color={T.muted} />
          </Card>
        </Pressable>
      ))}
      <Label>Native-dependent tools report their status honestly.</Label>
    </Screen>
  );
}
