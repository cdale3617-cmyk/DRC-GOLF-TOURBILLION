import ClubManager from '@/screens/Equipment';
export default function BagTab() { return <ClubManager tab />; }
