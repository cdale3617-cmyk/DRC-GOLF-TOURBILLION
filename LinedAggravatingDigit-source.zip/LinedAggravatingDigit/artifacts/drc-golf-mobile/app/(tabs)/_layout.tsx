import React from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { isLiquidGlassAvailable } from 'expo-glass-effect';
import { Tabs } from 'expo-router';
import { NativeTabs } from 'expo-router/unstable-native-tabs';
import { SymbolView } from 'expo-symbols';
import { T } from '@/constants/colors';

const TABS = [
  { name: 'index', title: 'Home', icon: 'home', sf: 'house' },
  { name: 'caddie', title: 'Caddie', icon: 'flag', sf: 'flag' },
  { name: 'lab', title: 'Golf Lab', icon: 'activity', sf: 'waveform.path.ecg' },
  { name: 'bag', title: 'My Bag', icon: 'briefcase', sf: 'bag' },
  { name: 'more', title: 'More', icon: 'menu', sf: 'ellipsis' },
] as const;

function NativeTabLayout() {
  return (
    <NativeTabs>
      {TABS.map((t) => (
        <NativeTabs.Trigger key={t.name} name={t.name}>
          <NativeTabs.Trigger.Icon sf={t.sf as never} />
          <NativeTabs.Trigger.Label>{t.title}</NativeTabs.Trigger.Label>
        </NativeTabs.Trigger>
      ))}
    </NativeTabs>
  );
}

function ClassicTabLayout() {
  const isIOS = Platform.OS === 'ios';
  const isWeb = Platform.OS === 'web';
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: T.gold,
        tabBarInactiveTintColor: T.muted,
        tabBarLabelStyle: { fontFamily: 'Inter_600SemiBold', fontSize: 10.5 },
        tabBarStyle: {
          position: isIOS ? 'absolute' : 'relative',
          backgroundColor: isIOS ? 'transparent' : T.surface,
          borderTopWidth: 1,
          borderTopColor: T.border,
          elevation: 0,
          ...(isWeb ? { height: 84 } : {}),
        },
        tabBarBackground: () =>
          isIOS ? <BlurView intensity={90} tint="dark" style={StyleSheet.absoluteFill} /> :
          isWeb ? <View style={[StyleSheet.absoluteFill, { backgroundColor: T.surface }]} /> : null,
      }}
    >
      {TABS.map((t) => (
        <Tabs.Screen
          key={t.name}
          name={t.name}
          options={{
            title: t.title,
            tabBarButtonTestID: `tab-${t.name}`,
            tabBarIcon: ({ color }) =>
              isIOS ? <SymbolView name={t.sf as never} tintColor={color} size={22} /> : <Feather name={t.icon} size={21} color={color} />,
          }}
        />
      ))}
    </Tabs>
  );
}

export default function TabLayout() {
  return isLiquidGlassAvailable() ? <NativeTabLayout /> : <ClassicTabLayout />;
}
