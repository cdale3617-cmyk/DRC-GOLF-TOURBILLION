import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { Screen, Card, Label, F } from '@/components/ui';
import { TOOLS, openTool } from '@/lib/tools';
import { T } from '@/constants/colors';

export default function MoreTab() {
  return (
    <Screen tab eyebrow="Everything else" title="More">
      {(['Play', 'Records', 'Setup', 'Lab'] as const).map((g) => (
        <View key={g} style={{ gap: 8 }}>
          <Label>{g}</Label>
          <Card style={{ padding: 4, gap: 0 }}>
            {TOOLS.filter((t) => t.group === g).map((t, i) => (
              <Pressable key={t.id} testID={`more-${t.id}`} onPress={() => openTool(t.id)}
                style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderTopWidth: i ? 1 : 0, borderTopColor: T.border }}>
                <Feather name={t.icon} size={18} color={T.gold} />
                <View style={{ flex: 1 }}>
                  <Text style={{ color: T.text, fontFamily: F.s, fontSize: 15 }}>{t.title}</Text>
                  <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 12 }}>{t.blurb}</Text>
                </View>
                <Feather name="chevron-right" size={16} color={T.muted} />
              </Pressable>
            ))}
          </Card>
        </View>
      ))}
    </Screen>
  );
}
