import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Circle } from 'react-native-svg';
import { Feather } from '@expo/vector-icons';
import { Screen, Card, Label, Stat, Btn, F } from '@/components/ui';
import { useApp } from '@/context/AppContext';
import { roundTotals, fmtToPar, mean } from '@/lib/stats';
import { openTool } from '@/lib/tools';
import { T } from '@/constants/colors';

function Ring({ frac, label, sub }: { frac: number; label: string; sub: string }) {
  const r = 46, c = 2 * Math.PI * r;
  return (
    <View style={{ width: 120, height: 120, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={120} height={120} style={{ position: 'absolute', transform: [{ rotate: '-90deg' }] }}>
        <Circle cx={60} cy={60} r={r} stroke={T.goldDeep} strokeOpacity={0.35} strokeWidth={3} fill="none" />
        <Circle cx={60} cy={60} r={r} stroke={T.gold} strokeWidth={3} fill="none" strokeLinecap="round" strokeDasharray={`${c * frac} ${c}`} />
      </Svg>
      <Text style={{ color: T.goldLight, fontFamily: F.b, fontSize: 26 }}>{label}</Text>
      <Text style={{ color: T.muted, fontFamily: F.m, fontSize: 10, letterSpacing: 1.2 }}>{sub}</Text>
    </View>
  );
}

export default function Home() {
  const { rounds, activeRound, shots, clubs, courses, captures, profile } = useApp();
  const done = rounds.filter((r) => r.endedAt);
  const scored = done.map((r) => ({ r, t: roundTotals(r) })).filter((x) => x.t.played > 0);
  const best = scored.length ? scored.reduce((a, b) => (b.t.toPar < a.t.toPar ? b : a)) : null;
  const putts = scored.filter((x) => x.t.putts > 0).map((x) => x.t.putts);
  const at = activeRound ? roundTotals(activeRound) : null;
  const frac = activeRound && activeRound.holes.length ? (at?.played ?? 0) / activeRound.holes.length : 0;

  return (
    <Screen tab eyebrow="DRC Golf" title="Tourbillion">
      <LinearGradient colors={[T.green, T.surface, T.bg]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
        style={{ borderRadius: 24, padding: 20, borderWidth: 1, borderColor: T.goldDeep, gap: 14 }}>
        <Label>{profile.name ? `Welcome, ${profile.name}` : 'Your caddie and lab'}</Label>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
          <Ring frac={frac} label={activeRound ? `${at?.played}/${activeRound.holes.length}` : '--'} sub={activeRound ? 'HOLES SCORED' : 'NO ROUND'} />
          <View style={{ flex: 1, gap: 8 }}>
            {activeRound ? (
              <>
                <Text style={{ color: T.text, fontFamily: F.b, fontSize: 18 }}>{activeRound.courseName}</Text>
                <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 13 }}>
                  {at && at.played ? `${at.strokes} strokes, ${fmtToPar(at.toPar)} through ${at.played}` : 'Round in progress, nothing scored yet'}
                </Text>
                <Btn testID="home-resume" small label="Resume hole" icon="flag" onPress={() => openTool('live')} />
              </>
            ) : (
              <>
                <Text style={{ color: T.text, fontFamily: F.b, fontSize: 18 }}>No round in progress</Text>
                <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 13 }}>
                  {courses.length ? 'Pick a course to begin recording.' : 'Create a course to start your first round.'}
                </Text>
                <Btn testID="home-start" small label={courses.length ? 'Start round' : 'Add course'} icon="play-circle" onPress={() => openTool(courses.length ? 'preround' : 'courses')} />
              </>
            )}
          </View>
        </View>
      </LinearGradient>

      <Card>
        <Label>Record summary</Label>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 14 }}>
          <Stat label="Rounds" value={`${done.length}`} sub="completed" />
          <Stat label="Best" value={best ? fmtToPar(best.t.toPar) : '--'} sub={best ? best.r.courseName : 'none scored'} />
          <Stat label="Avg putts" value={putts.length ? mean(putts).toFixed(1) : '--'} sub="per round" />
          <Stat label="Shots" value={`${shots.length}`} sub="measured" />
          <Stat label="Clubs" value={`${clubs.length}`} sub="in bag" />
          <Stat label="Captures" value={`${captures.length}`} sub="clips" />
        </View>
      </Card>

      <Label>Quick access</Label>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {([['dispersion', 'crosshair', 'Shot Pattern'], ['putting', 'circle', 'Putting'], ['wedges', 'grid', 'Wedge Matrix'], ['history', 'clock', 'History'], ['courses', 'map', 'Courses'], ['howto', 'book-open', 'How To']] as const).map(([id, icon, title]) => (
          <Pressable key={id} testID={`home-${id}`} onPress={() => openTool(id)}
            style={{ width: '48%', backgroundColor: T.surface, borderRadius: 16, borderWidth: 1, borderColor: T.border, padding: 14, gap: 8 }}>
            <Feather name={icon} size={18} color={T.gold} />
            <Text style={{ color: T.text, fontFamily: F.s, fontSize: 14 }}>{title}</Text>
          </Pressable>
        ))}
      </View>
    </Screen>
  );
}
