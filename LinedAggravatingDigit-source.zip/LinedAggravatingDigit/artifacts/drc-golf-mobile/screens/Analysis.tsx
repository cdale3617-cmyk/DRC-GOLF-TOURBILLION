import React, { useState } from 'react';
import { Text, View } from 'react-native';
import Svg, { Circle, Line, Text as SvgText } from 'react-native-svg';
import { useApp } from '@/context/AppContext';
import { Btn, Card, Chips, Empty, F, Label, Screen, Sheet, Stat } from '@/components/ui';
import ShotForm from '@/components/ShotForm';
import ShotList from '@/components/ShotList';
import { dispersion, mean, sd } from '@/lib/stats';
import { fmtDist, toDisp, unitLabel } from '@/lib/units';
import type { Shot, ShotContext } from '@/lib/types';
import { T } from '@/constants/colors';

const FULL: ShotContext[] = ['tee', 'full', 'wedge', 'chip', 'swing'];

export function Dispersion() {
  const { shots, clubs, profile } = useApp();
  const u = profile.units;
  const [club, setClub] = useState<string>('all');
  const [ctx, setCtx] = useState<string>('all');
  const [open, setOpen] = useState(false);
  const base = shots.filter((s) => s.context !== 'putt');
  const filt = base.filter((s) => (club === 'all' || (club === 'none' ? !s.clubId : s.clubId === club)) && (ctx === 'all' || s.context === ctx));
  const d = dispersion(filt);
  const pts = filt.filter((s): s is Shot & { lateralM: number } => s.lateralM != null);
  const W = 320, H = 280, pad = 28;
  const maxLat = Math.max(1, ...pts.map((p) => Math.abs(p.lateralM))) * 1.15;
  const dMin = pts.length ? Math.min(...pts.map((p) => p.distanceM)) : 0;
  const dMax = pts.length ? Math.max(...pts.map((p) => p.distanceM)) : 1;
  const span = Math.max(dMax - dMin, 1);
  const px = (l: number) => W / 2 + (l / maxLat) * (W / 2 - pad);
  const py = (m: number) => H - pad - ((m - dMin) / span) * (H - 2 * pad);
  return (
    <Screen back guide="dispersion" eyebrow="Lab" title="Shot Pattern"
      right={<Btn testID="record-shot" small label="Record" icon="plus" onPress={() => setOpen(true)} />}>
      <Chips testID="disp-club" options={[{ value: 'all', label: 'All clubs' }, ...clubs.map((c) => ({ value: c.id, label: c.name })), { value: 'none', label: 'No club' }]} value={club} onChange={setClub} />
      <Chips testID="disp-ctx" options={[{ value: 'all', label: 'All contexts' }, ...FULL.map((c) => ({ value: c, label: c }))]} value={ctx} onChange={setCtx} />
      {!filt.length ? (
        <Empty icon="crosshair" title="No measured shots" text="Only shots you record appear here. Record distance and lateral offset to build a pattern."
          action={<Btn testID="record-shot-empty" label="Record shot" icon="plus" onPress={() => setOpen(true)} />} />
      ) : (
        <>
          <Card gold>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 14 }}>
              <Stat label="Shots" value={`${d.n}`} sub={`${d.nLat} with offset`} />
              <Stat label="Mean distance" value={fmtDist(d.meanDist ?? undefined, u, 1)} sub={d.sdDist != null ? `sd ${fmtDist(d.sdDist, u, 1)}` : 'sd needs 2+ shots'} />
              <Stat label="Mean offset" value={d.meanLat != null ? `${fmtDist(Math.abs(d.meanLat), u, 1)} ${d.meanLat < 0 ? 'L' : 'R'}` : '--'} sub={d.sdLat != null ? `sd ${fmtDist(d.sdLat, u, 1)}` : 'sd needs 2+ offsets'} />
              <Stat label="Range" value={d.minDist != null ? `${toDisp(d.minDist, u).toFixed(0)}-${toDisp(d.maxDist ?? 0, u).toFixed(0)}` : '--'} sub={unitLabel(u)} />
            </View>
          </Card>
          <Card>
            <Label>Plot - recorded offsets only</Label>
            {pts.length ? (
              <Svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`}>
                <Line x1={W / 2} y1={pad / 2} x2={W / 2} y2={H - pad / 2} stroke={T.border} strokeWidth={1} />
                {pts.map((p) => <Circle key={p.id} cx={px(p.lateralM)} cy={py(p.distanceM)} r={5} fill={T.gold} fillOpacity={0.85} />)}
                <SvgText x={4} y={H - 6} fill={T.muted} fontSize={10}>{`left`}</SvgText>
                <SvgText x={W - 26} y={H - 6} fill={T.muted} fontSize={10}>{`right`}</SvgText>
                <SvgText x={4} y={12} fill={T.muted} fontSize={10}>{`${toDisp(dMax, u).toFixed(0)} ${unitLabel(u)}`}</SvgText>
                <SvgText x={4} y={H - 18} fill={T.muted} fontSize={10}>{`${toDisp(dMin, u).toFixed(0)} ${unitLabel(u)}`}</SvgText>
              </Svg>
            ) : <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 13 }}>None of these shots has a recorded lateral offset, so nothing can be plotted.</Text>}
            <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 11.5 }}>Offsets are relative to the target line you judged. Small samples are noisy.</Text>
          </Card>
        </>
      )}
      <ShotList shots={filt} />
      <Sheet visible={open} title="Record measured shot" onClose={() => setOpen(false)}>
        <ShotForm contexts={FULL} onSaved={() => setOpen(false)} />
      </Sheet>
    </Screen>
  );
}

export function WedgeMatrix() {
  const { shots, profile } = useApp();
  const u = profile.units;
  const [open, setOpen] = useState(false);
  const w = shots.filter((s) => s.context === 'wedge');
  const lens = ['Quarter', 'Half', 'Three-quarter', 'Full'];
  const names = Array.from(new Set(w.map((s) => s.clubName ?? 'No club')));
  const hasOther = w.some((s) => !s.swingLength);
  const cols = hasOther ? [...lens, 'Unspecified'] : lens;
  return (
    <Screen back guide="wedges" eyebrow="Lab" title="Wedge Matrix"
      right={<Btn testID="record-wedge" small label="Record" icon="plus" onPress={() => setOpen(true)} />}>
      {!w.length ? (
        <Empty icon="grid" title="No wedge records" text="Cells fill only from wedge shots you record with a club and swing length."
          action={<Btn testID="record-wedge-empty" label="Record wedge shot" icon="plus" onPress={() => setOpen(true)} />} />
      ) : (
        names.map((n) => (
          <Card key={n}>
            <Text style={{ color: T.text, fontFamily: F.b, fontSize: 16 }}>{n}</Text>
            {cols.map((c) => {
              const g = w.filter((s) => (s.clubName ?? 'No club') === n && (c === 'Unspecified' ? !s.swingLength : s.swingLength === c));
              const lat = g.filter((s) => s.lateralM != null).map((s) => s.lateralM as number);
              const sl = sd(lat);
              return (
                <View key={c} style={{ flexDirection: 'row', justifyContent: 'space-between', borderTopWidth: 1, borderTopColor: T.border, paddingTop: 7 }}>
                  <Text style={{ color: T.muted, fontFamily: F.m, width: 110, fontSize: 13 }}>{c}</Text>
                  <Text style={{ color: g.length ? T.goldLight : T.muted, fontFamily: F.b, fontSize: 14, flex: 1 }}>{g.length ? fmtDist(mean(g.map((s) => s.distanceM)), u, 1) : 'no data'}</Text>
                  <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 11.5 }}>{g.length ? `n=${g.length}${sl != null ? `, offset sd ${fmtDist(sl, u, 1)}` : ''}` : ''}</Text>
                </View>
              );
            })}
          </Card>
        ))
      )}
      <ShotList shots={w} />
      <Sheet visible={open} title="Record wedge shot" onClose={() => setOpen(false)}>
        <ShotForm contexts={['wedge']} showSwingLength onSaved={() => setOpen(false)} />
      </Sheet>
    </Screen>
  );
}
