import React, { useState } from 'react';
import { Text, View } from 'react-native';
import { useApp } from '@/context/AppContext';
import { Btn, Card, Empty, F, Label, Screen, Stat, Stepper, confirmAction } from '@/components/ui';
import { fmtToPar, roundTotals } from '@/lib/stats';
import { fmtDate, fmtDist } from '@/lib/units';
import { openTool } from '@/lib/tools';
import { T } from '@/constants/colors';

export function PreRound() {
  const { courses, clubs, activeRound, startRound, profile } = useApp();
  const [sel, setSel] = useState<string | undefined>();
  const course = courses.find((c) => c.id === sel);
  if (activeRound) {
    return (
      <Screen back guide="preround" eyebrow="Play" title="Pre-Round">
        <Card gold>
          <Text style={{ color: T.text, fontFamily: F.b, fontSize: 17 }}>{activeRound.courseName} is in progress</Text>
          <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 13 }}>End the current round before starting another.</Text>
          <Btn testID="resume-round" label="Go to live hole" icon="flag" onPress={() => openTool('live')} />
        </Card>
      </Screen>
    );
  }
  return (
    <Screen back guide="preround" eyebrow="Play" title="Pre-Round">
      {!courses.length ? (
        <Empty icon="map" title="No courses" text="Create a course with hole pars before starting a round."
          action={<Btn testID="preround-add-course" label="Create course" icon="plus" onPress={() => openTool('courses')} />} />
      ) : (
        <>
          <Label>Choose course</Label>
          {courses.map((c) => (
            <Card key={c.id} gold={c.id === sel}>
              <Text testID={`select-course-${c.id}`} onPress={() => setSel(c.id)} style={{ color: c.id === sel ? T.goldLight : T.text, fontFamily: F.b, fontSize: 16 }}>
                {c.name}  -  {c.holes.length} holes, par {c.holes.reduce((s, h) => s + h.par, 0)}
              </Text>
            </Card>
          ))}
          {course ? (
            <Card>
              <View style={{ flexDirection: 'row', gap: 12 }}>
                <Stat label="Holes" value={`${course.holes.length}`} />
                <Stat label="Par" value={`${course.holes.reduce((s, h) => s + h.par, 0)}`} />
                <Stat label="Pins entered" value={`${course.holes.filter((h) => h.pin).length}`} />
              </View>
              <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 12.5 }}>
                {course.holes.every((h) => h.lengthM != null) ? `Total ${fmtDist(course.holes.reduce((s, h) => s + (h.lengthM ?? 0), 0), profile.units)}` : 'Some hole lengths not entered.'}
                {` ${clubs.length} club${clubs.length === 1 ? '' : 's'} in bag.`}
              </Text>
              <Btn testID="start-round" label="Start round" icon="play-circle" onPress={() => { if (startRound(course.id)) openTool('live'); }} />
            </Card>
          ) : null}
        </>
      )}
    </Screen>
  );
}

export function ScorecardScreen({ rid }: { rid?: string }) {
  const { rounds, activeRound, setScore, endRound } = useApp();
  const round = rounds.find((r) => r.id === rid) ?? activeRound ?? rounds[0];
  if (!round) {
    return (
      <Screen back guide="scorecard" eyebrow="Play" title="Scorecard">
        <Empty icon="edit-3" title="No round recorded" text="Start a round to keep a scorecard." action={<Btn testID="sc-start" label="Pre-Round" onPress={() => openTool('preround')} />} />
      </Screen>
    );
  }
  const t = roundTotals(round);
  return (
    <Screen back guide="scorecard" eyebrow={`${round.courseName} - ${fmtDate(round.startedAt)}`} title="Scorecard">
      <Card gold>
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <Stat label="Strokes" value={t.played ? `${t.strokes}` : '--'} sub={t.played ? fmtToPar(t.toPar) : 'none yet'} />
          <Stat label="Putts" value={`${t.putts}`} />
          <Stat label="Penalties" value={`${t.penalties}`} />
        </View>
        {!round.endedAt ? (
          <Btn testID="end-round" variant="ghost" label="End round" icon="flag" onPress={() => confirmAction('End round', 'Mark this round complete?', () => endRound(round.id))} />
        ) : <Label>Completed round</Label>}
      </Card>
      {round.holes.map((h) => {
        const sc = round.scores[h.number] ?? {};
        const set = (k: 'strokes' | 'putts' | 'penalties', v: number) => setScore(round.id, h.number, { [k]: Math.max(0, v) });
        return (
          <Card key={h.number} style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 10 }}>
            <View style={{ width: 44 }}>
              <Text style={{ color: T.goldLight, fontFamily: F.b, fontSize: 20 }}>{h.number}</Text>
              <Text style={{ color: T.muted, fontFamily: F.m, fontSize: 11 }}>Par {h.par}</Text>
            </View>
            <Stepper testID={`h${h.number}-strokes`} label="Strokes" value={sc.strokes}
              onInc={() => set('strokes', sc.strokes == null ? h.par : sc.strokes + 1)} onDec={() => set('strokes', (sc.strokes ?? 1) - 1)} />
            <Stepper testID={`h${h.number}-putts`} label="Putts" value={sc.putts} onInc={() => set('putts', (sc.putts ?? 0) + 1)} onDec={() => set('putts', (sc.putts ?? 1) - 1)} />
            <Stepper testID={`h${h.number}-pen`} label="Pen" value={sc.penalties} onInc={() => set('penalties', (sc.penalties ?? 0) + 1)} onDec={() => set('penalties', (sc.penalties ?? 1) - 1)} />
          </Card>
        );
      })}
    </Screen>
  );
}
