import React, { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useApp } from '@/context/AppContext';
import { Btn, Card, Chips, Empty, ErrorText, F, Field, Row, Screen, Sheet, confirmAction } from '@/components/ui';
import { dispersion } from '@/lib/stats';
import { fmtDist, parseNum } from '@/lib/units';
import type { Club, ClubCategory } from '@/lib/types';
import { T } from '@/constants/colors';

const CATS: ClubCategory[] = ['Driver', 'Wood', 'Hybrid', 'Iron', 'Wedge', 'Putter', 'Other'];

export default function ClubManager({ tab }: { tab?: boolean }) {
  const { clubs, shots, profile, saveClub, deleteClub } = useApp();
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<string | undefined>();
  const [name, setName] = useState('');
  const [cat, setCat] = useState<ClubCategory>('Iron');
  const [loft, setLoft] = useState('');
  const [brand, setBrand] = useState('');
  const [notes, setNotes] = useState('');
  const [err, setErr] = useState('');

  const openNew = () => { setEditId(undefined); setName(''); setCat('Iron'); setLoft(''); setBrand(''); setNotes(''); setErr(''); setOpen(true); };
  const openEdit = (c: Club) => { setEditId(c.id); setName(c.name); setCat(c.category); setLoft(c.loftDeg?.toString() ?? ''); setBrand(c.brand ?? ''); setNotes(c.notes ?? ''); setErr(''); setOpen(true); };
  const save = () => {
    if (!name.trim()) { setErr('Give the club a name.'); return; }
    const l = parseNum(loft);
    if (loft.trim() && (l == null || l < 0 || l > 90)) { setErr('Loft must be between 0 and 90 degrees.'); return; }
    saveClub({ id: editId, name: name.trim(), category: cat, loftDeg: l, brand: brand.trim() || undefined, notes: notes.trim() || undefined });
    setOpen(false);
  };

  return (
    <Screen tab={tab} back={!tab} guide="equipment" eyebrow={tab ? 'Your clubs' : 'Setup'} title={tab ? 'My Bag' : 'Equipment'}
      right={<Pressable testID="add-club" onPress={openNew} hitSlop={10}><Feather name="plus-circle" size={28} color={T.gold} /></Pressable>}>
      {!clubs.length ? (
        <Empty icon="briefcase" title="Your bag is empty" text="Add the clubs you actually carry. Nothing is pre-filled."
          action={<Btn testID="add-club-empty" label="Add club" icon="plus" onPress={openNew} />} />
      ) : null}
      {clubs.map((c) => {
        const own = shots.filter((s) => s.clubId === c.id);
        const d = dispersion(own);
        return (
          <Card key={c.id}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ color: T.text, fontFamily: F.b, fontSize: 17 }}>{c.name}</Text>
                <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 12 }}>
                  {c.category}{c.loftDeg != null ? ` - ${c.loftDeg} deg` : ''}{c.brand ? ` - ${c.brand}` : ''}
                </Text>
              </View>
              <Pressable testID={`edit-club-${c.id}`} onPress={() => openEdit(c)} hitSlop={10}><Feather name="edit-2" size={17} color={T.goldLight} /></Pressable>
              <Pressable testID={`delete-club-${c.id}`} hitSlop={10} onPress={() => confirmAction('Delete club', `Remove ${c.name} from your bag?`, () => deleteClub(c.id))}>
                <Feather name="trash-2" size={17} color={T.muted} />
              </Pressable>
            </View>
            <Text style={{ color: d.n ? T.goldLight : T.muted, fontFamily: F.m, fontSize: 12.5 }}>
              {d.n ? `${d.n} recorded - average ${fmtDist(d.meanDist ?? undefined, profile.units, 1)}` : 'No recorded shots with this club'}
            </Text>
            {c.notes ? <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 12.5 }}>{c.notes}</Text> : null}
          </Card>
        );
      })}
      <Sheet visible={open} title={editId ? 'Edit club' : 'New club'} onClose={() => setOpen(false)}>
        <Field testID="club-name" label="Name" value={name} onChangeText={setName} placeholder="e.g. 7 iron" />
        <Chips testID="club-cat" options={CATS.map((x) => ({ value: x, label: x }))} value={cat} onChange={setCat} />
        <Row>
          <Field testID="club-loft" label="Loft (optional)" value={loft} onChangeText={setLoft} keyboardType="decimal-pad" suffix="deg" />
          <Field testID="club-brand" label="Brand / model" value={brand} onChangeText={setBrand} />
        </Row>
        <Field testID="club-notes" label="Notes" value={notes} onChangeText={setNotes} multiline />
        <ErrorText>{err}</ErrorText>
        <Btn testID="club-save" label={editId ? 'Save changes' : 'Add to bag'} icon="check" onPress={save} />
      </Sheet>
    </Screen>
  );
}
