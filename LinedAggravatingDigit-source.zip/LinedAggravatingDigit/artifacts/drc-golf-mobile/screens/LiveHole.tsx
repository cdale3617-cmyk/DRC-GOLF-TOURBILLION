import React, { useEffect, useState } from 'react';
import { Pressable, Text, View, useWindowDimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Feather } from '@expo/vector-icons';
import { useApp } from '@/context/AppContext';
import { Btn, Card, Chips, Empty, ErrorText, F, Field, Label, Row, Screen, Sheet, Stepper } from '@/components/ui';
import { distanceMetres, getGPSFix, openDeviceSettings, type GPSFix } from '@/lib/device';
import { fmtDist, fromDisp, parseNum, unitLabel } from '@/lib/units';
import { roundTotals, fmtToPar } from '@/lib/stats';
import { openTool } from '@/lib/tools';
import type { ShotContext } from '@/lib/types';
import { T } from '@/constants/colors';

export default function LiveHole() {
  const { activeRound, setScore, clubs, profile, addShot } = useApp();
  const u = profile.units;
  const { width } = useWindowDimensions();
  const wide = width >= 340;
  const [idx, setIdx] = useState(0);
  const [fix, setFix] = useState<GPSFix | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [now, setNow] = useState(Date.now());
  const [start, setStart] = useState<GPSFix | null>(null);
  const [end, setEnd] = useState<GPSFix | null>(null);
  const [pinLat, setPinLat] = useState('');
  const [pinLon, setPinLon] = useState('');
  const [sheet, setSheet] = useState(false);
  const [clubId, setClubId] = useState('');
  const [ctx, setCtx] = useState<ShotContext>('full');
  const [lat, setLat] = useState('');
  const [side, setSide] = useState<'L' | 'R'>('R');
  const [shotErr, setShotErr] = useState('');

  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t); }, []);

  if (!activeRound) {
    return (
      <Screen tab guide="live" eyebrow="On course" title="Caddie">
        <Empty icon="flag" title="No round in progress" text="Start a round to score holes and measure shots with GPS."
          action={<Btn testID="caddie-start" label="Start a round" icon="play-circle" onPress={() => openTool('preround')} />} />
      </Screen>
    );
  }
  const hole = activeRound.holes[Math.min(idx, activeRound.holes.length - 1)];
  const sc = activeRound.scores[hole.number] ?? {};
  const t = roundTotals(activeRound);
  const set = (k: 'strokes' | 'putts' | 'penalties', v: number) => setScore(activeRound.id, hole.number, { [k]: Math.max(0, v) });

  const pin = hole.pin ?? (() => {
    const a = parseNum(pinLat), b = parseNum(pinLon);
    return a != null && b != null && Math.abs(a) <= 90 && Math.abs(b) <= 180 ? { latitude: a, longitude: b } : undefined;
  })();
  const pinDist = fix && pin ? distanceMetres(fix, { latitude: pin.latitude, longitude: pin.longitude, accuracy: null, timestamp: fix.timestamp }) : undefined;

  const grab = async (): Promise<GPSFix | null> => {
    setBusy(true); setErr('');
    try { const f = await getGPSFix(); setFix(f); return f; }
    catch (e) { setErr(e instanceof Error ? e.message : 'Could not read GPS.'); return null; }
    finally { setBusy(false); }
  };
  const markStart = async () => { const f = await grab(); if (f) { setStart(f); setEnd(null); } };
  const markEnd = async () => { const f = await grab(); if (f) { setEnd(f); setSheet(true); setShotErr(''); } };
  const dist = start && end ? distanceMetres(start, end) : 0;
  const combined = start && end && start.accuracy != null && end.accuracy != null ? Math.sqrt(start.accuracy ** 2 + end.accuracy ** 2) : null;

  const saveShot = () => {
    if (!start || !end) return;
    const l = parseNum(lat);
    if (lat.trim() && l == null) { setShotErr('Lateral offset must be a number.'); return; }
    const club = clubs.find((c) => c.id === clubId);
    addShot({
      context: ctx, distanceM: dist, source: 'gps', roundId: activeRound.id, clubId: club?.id, clubName: club?.name,
      lateralM: l == null ? undefined : fromDisp(Math.abs(l), u) * (side === 'L' ? -1 : 1),
      gps: { startAcc: start.accuracy, endAcc: end.accuracy }, note: `Hole ${hole.number}`,
    });
    setStart(null); setEnd(null); setSheet(false); setLat('');
  };

  const age = fix ? Math.max(0, Math.round((now - fix.timestamp) / 1000)) : 0;

  const holeView = (
    <LinearGradient colors={[T.green, T.surface, T.bg]} style={{ flex: 1, minHeight: 470, borderRadius: 22, borderWidth: 1, borderColor: T.goldDeep, padding: 16, justifyContent: 'space-between' }}>
      <View>
        <Label>Uncharted hole</Label>
        <Text style={{ color: T.goldLight, fontFamily: F.b, fontSize: 64, letterSpacing: -2, lineHeight: 70 }}>{hole.number}</Text>
        <Text style={{ color: T.text, fontFamily: F.s, fontSize: 15 }}>Par {hole.par}{hole.lengthM != null ? `  -  ${fmtDist(hole.lengthM, u)}` : ''}</Text>
      </View>
      <View style={{ gap: 6 }}>
        <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 12, lineHeight: 17 }}>
          No mapped geometry for this hole. Nothing is drawn; distances come only from your GPS fix and pin coordinates.
        </Text>
        {pinDist != null ? (
          <><Label>To pin</Label><Text testID="pin-distance" style={{ color: T.goldLight, fontFamily: F.b, fontSize: 36 }}>{fmtDist(pinDist, u, 0)}</Text></>
        ) : <Text style={{ color: T.muted, fontFamily: F.m, fontSize: 12 }}>{pin ? 'Pin set. Get a GPS fix for distance.' : 'No pin coordinates for this hole.'}</Text>}
        {fix ? (
          <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 11 }}>
            {fix.latitude.toFixed(6)}, {fix.longitude.toFixed(6)}{'\n'}accuracy {fix.accuracy != null ? `${fmtDist(fix.accuracy, u, 0)}` : 'unknown'} - {age}s old
          </Text>
        ) : <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 11 }}>No GPS fix yet.</Text>}
        {start && !end ? <Text style={{ color: T.goldLight, fontFamily: F.m, fontSize: 11.5 }}>Shot start marked. Walk to the ball, then mark end.</Text> : null}
      </View>
    </LinearGradient>
  );

  const controls = (
    <View style={{ width: wide ? 148 : '100%', gap: 10 }}>
      <Card style={{ padding: 10, gap: 8 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Pressable testID="prev-hole" disabled={idx === 0} onPress={() => { setIdx(idx - 1); setStart(null); setEnd(null); }} hitSlop={8}><Feather name="chevron-left" size={22} color={idx === 0 ? T.border : T.goldLight} /></Pressable>
          <Text style={{ color: T.text, fontFamily: F.b }}>Hole {hole.number}</Text>
          <Pressable testID="next-hole" disabled={idx >= activeRound.holes.length - 1} onPress={() => { setIdx(idx + 1); setStart(null); setEnd(null); }} hitSlop={8}><Feather name="chevron-right" size={22} color={idx >= activeRound.holes.length - 1 ? T.border : T.goldLight} /></Pressable>
        </View>
        <Stepper testID="live-strokes" label="Strokes" value={sc.strokes} onInc={() => set('strokes', sc.strokes == null ? hole.par : sc.strokes + 1)} onDec={() => set('strokes', (sc.strokes ?? 1) - 1)} />
        <Stepper testID="live-putts" label="Putts" value={sc.putts} onInc={() => set('putts', (sc.putts ?? 0) + 1)} onDec={() => set('putts', (sc.putts ?? 1) - 1)} />
        <Stepper testID="live-pen" label="Penalty" value={sc.penalties} onInc={() => set('penalties', (sc.penalties ?? 0) + 1)} onDec={() => set('penalties', (sc.penalties ?? 1) - 1)} />
      </Card>
      <Btn testID="get-gps" small label={busy ? 'Reading' : 'GPS fix'} icon="navigation" disabled={busy} onPress={grab} />
      <Btn testID="mark-start" small variant="ghost" label="Mark start" icon="map-pin" disabled={busy} onPress={markStart} />
      <Btn testID="mark-end" small variant="ghost" label="Mark end" icon="flag" disabled={busy || !start} onPress={markEnd} />
      <Btn testID="open-scorecard" small variant="ghost" label="Scorecard" icon="edit-3" onPress={() => openTool('scorecard', { rid: activeRound.id })} />
    </View>
  );

  return (
    <Screen tab guide="live" eyebrow={`${activeRound.courseName} - ${t.played ? `${fmtToPar(t.toPar)} thru ${t.played}` : 'not scored'}`} title="Live Hole">
      <View style={{ flexDirection: wide ? 'row' : 'column', gap: 12, alignItems: 'stretch' }}>
        {holeView}
        {controls}
      </View>
      <ErrorText>{err}</ErrorText>
      {err ? <Btn testID="open-settings" small variant="ghost" label="Open device settings" icon="settings" onPress={() => { openDeviceSettings().catch(() => {}); }} /> : null}
      {!hole.pin ? (
        <Card>
          <Label>Pin coordinates for this hole (optional, typed by you)</Label>
          <Row>
            <Field testID="pin-lat" label="Latitude" value={pinLat} onChangeText={setPinLat} keyboardType="numbers-and-punctuation" />
            <Field testID="pin-lon" label="Longitude" value={pinLon} onChangeText={setPinLon} keyboardType="numbers-and-punctuation" />
          </Row>
          <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 11.5 }}>Entered here for this session only. Add permanent pins in Courses.</Text>
        </Card>
      ) : null}
      <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 11.5, lineHeight: 16 }}>
        Phone GPS is typically accurate to several metres. Short shots can be dominated by error; accuracy is stored with each shot.
      </Text>
      <Sheet visible={sheet} title="Save GPS shot" onClose={() => setSheet(false)}>
        <Card gold>
          <Label>Measured distance</Label>
          <Text style={{ color: T.goldLight, fontFamily: F.b, fontSize: 34 }}>{fmtDist(dist, u, 1)}</Text>
          <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 12 }}>
            Start accuracy {start?.accuracy != null ? fmtDist(start.accuracy, u, 1) : 'unknown'}, end {end?.accuracy != null ? fmtDist(end.accuracy, u, 1) : 'unknown'}.
            {combined != null ? ` Combined error is roughly ${fmtDist(combined, u, 1)}${dist < combined * 2 ? ', which is large compared with this distance' : ''}.` : ''}
          </Text>
        </Card>
        <Label>Club</Label>
        <Chips testID="gps-club" options={[{ value: '', label: 'None' }, ...clubs.map((c) => ({ value: c.id, label: c.name }))]} value={clubId} onChange={setClubId} />
        <Label>Context</Label>
        <Chips testID="gps-ctx" options={(['tee', 'full', 'wedge', 'chip'] as ShotContext[]).map((c) => ({ value: c, label: c }))} value={ctx} onChange={setCtx} />
        <Row>
          <Field testID="gps-lateral" label="Lateral offset (optional)" value={lat} onChangeText={setLat} keyboardType="decimal-pad" suffix={unitLabel(u)} />
        </Row>
        <Chips testID="gps-side" options={[{ value: 'L', label: 'Left' }, { value: 'R', label: 'Right' }]} value={side} onChange={setSide} />
        <ErrorText>{shotErr}</ErrorText>
        <Btn testID="gps-save" label="Save recorded shot" icon="check" onPress={saveShot} />
      </Sheet>
    </Screen>
  );
}
