import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Platform, Text, View } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { useFocusEffect } from 'expo-router';
import type {
  ArViewHandle,
  Capabilities,
  ExpoArViewProps,
} from '@stewmore/expo-ar';
import { Body, Btn, Card, F, Label, Screen } from '@/components/ui';
import { T } from '@/constants/colors';
import { DepthSurfacePoint, fitDepthSurface, SurfaceTilt } from '@/lib/green-reading-math';
import { openDeviceSettings } from '@/lib/device';

type ArModule = typeof import('@stewmore/expo-ar');
type ArViewComponent = React.ForwardRefExoticComponent<
  ExpoArViewProps & React.RefAttributes<ArViewHandle>
>;
type HitKind = 'depth' | 'mesh';
interface CapturedPoint extends DepthSurfacePoint {
  target: HitKind;
  capturedAt: string;
  screenX: number;
  screenY: number;
}

const REQUIRED_POINTS = 5;

export function GreenReading() {
  const [module, setModule] = useState<ArModule | null>(null);
  const [bridgeState, setBridgeState] = useState<'checking' | 'available' | 'unavailable'>('checking');
  const [cameraPermission, setCameraPermission] = useState<'checking' | 'not-requested' | 'granted' | 'denied'>('checking');
  const [canAskCameraAgain, setCanAskCameraAgain] = useState(true);
  const [capabilities, setCapabilities] = useState<Capabilities | null>(null);
  const [sessionReady, setSessionReady] = useState(false);
  const [tracking, setTracking] = useState('initializing');
  const [points, setPoints] = useState<CapturedPoint[]>([]);
  const [reading, setReading] = useState<SurfaceTilt | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const viewRef = useRef<ArViewHandle>(null);
  const capturingRef = useRef(false);

  useEffect(() => {
    let active = true;
    if (Platform.OS !== 'ios' && Platform.OS !== 'android') {
      setBridgeState('unavailable');
      setCameraPermission('not-requested');
      return () => { active = false; };
    }
    void (async () => {
      try {
        const nativeModule = await import('@stewmore/expo-ar');
        if (!active) return;
        setModule(nativeModule);
        setBridgeState('available');
      } catch {
        if (!active) return;
        setBridgeState('unavailable');
      }
      try {
        const permission = await ImagePicker.getCameraPermissionsAsync();
        if (!active) return;
        setCameraPermission(permission.granted ? 'granted' : 'not-requested');
        setCanAskCameraAgain(permission.canAskAgain);
      } catch {
        if (active) setCameraPermission('not-requested');
      }
    })();
    return () => { active = false; };
  }, []);

  useFocusEffect(useCallback(() => {
    void viewRef.current?.resume().catch(() => undefined);
    return () => {
      void viewRef.current?.pause().catch(() => undefined);
    };
  }, []));

  const checkPermissionAndDevice = async () => {
    if (!module) return;
    setBusy(true);
    setError(null);
    try {
      let permission = await ImagePicker.getCameraPermissionsAsync();
      if (!permission.granted) {
        permission = await ImagePicker.requestCameraPermissionsAsync();
      }
      setCameraPermission(permission.granted ? 'granted' : 'denied');
      setCanAskCameraAgain(permission.canAskAgain);
      if (!permission.granted) {
        setCapabilities(null);
        setSessionReady(false);
        setError('Camera permission was denied. Device depth support has not been checked.');
        return;
      }

      const checked = module.getCapabilities();
      setCapabilities(checked);
      setSessionReady(false);
      setPoints([]);
      setReading(null);
      if (!checked.arSupported) {
        setError('The native AR runtime reports that AR is unavailable on this device.');
      } else if (!checked.depthOrLidarAvailable) {
        setError('AR is available, but the native runtime reports no supported depth or LiDAR capability.');
      }
    } catch (e) {
      setCapabilities(null);
      setSessionReady(false);
      const message = e instanceof Error ? e.message : 'The native AR device check failed.';
      if (/not linked|not using Expo Go|native module|view manager/i.test(message)) {
        setModule(null);
        setBridgeState('unavailable');
      }
      setError(message);
    } finally {
      setBusy(false);
    }
  };

  const captureSurfacePoint = async (screenX: number, screenY: number) => {
    if (!sessionReady || tracking !== 'normal' || !viewRef.current || capturingRef.current || points.length >= REQUIRED_POINTS) {
      return;
    }
    capturingRef.current = true;
    setError(null);
    try {
      const result = await viewRef.current.raycast(screenX, screenY);
      if (!result.worldTransform || (result.target !== 'depth' && result.target !== 'mesh')) {
        setError('No direct depth/mesh hit at that spot. Aim at the same green area and try another position.');
        return;
      }
      const [x, y, z] = [
        result.worldTransform[12],
        result.worldTransform[13],
        result.worldTransform[14],
      ];
      if (![x, y, z].every(Number.isFinite)) {
        setError('The native bridge returned an invalid surface position. No sample was added.');
        return;
      }
      const point: CapturedPoint = {
        x, y, z,
        target: result.target,
        capturedAt: new Date().toISOString(),
        screenX,
        screenY,
      };
      const nextPoints = [...points, point];
      setPoints(nextPoints);
      if (nextPoints.length === REQUIRED_POINTS) {
        const fit = fitDepthSurface(nextPoints);
        if (fit) setReading(fit);
        else setError('The five hits did not cover a stable, non-collinear surface area. Reset and scan five farther-apart spots.');
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'The native depth raycast failed.');
    } finally {
      capturingRef.current = false;
    }
  };

  const resetScan = () => {
    setPoints([]);
    setReading(null);
    setError(null);
  };

  const providerName = Platform.OS === 'ios' ? 'ARKit' : Platform.OS === 'android' ? 'ARCore' : 'Native AR';
  const ArView = module?.ExpoArView as ArViewComponent | undefined;
  const depthHits = points.filter((point) => point.target === 'depth' || point.target === 'mesh').length;

  return (
    <Screen back guide="greenreading" eyebrow="Golf Lab" title="Green Reading">
      <Card gold>
        <Label>Native device check</Label>
        <Body>Bridge: {bridgeState === 'checking' ? 'Checking' : bridgeState === 'available' ? 'Available' : 'Unavailable in this build'}</Body>
        <Body>Camera consent: {cameraPermission === 'checking' ? 'Checking' : cameraPermission === 'granted' ? 'Granted' : cameraPermission === 'denied' ? 'Denied' : 'Not requested'}</Body>
        <Body>AR runtime / device: {capabilities ? (capabilities.arSupported ? 'Supported by runtime' : 'Unavailable') : 'Not checked'}</Body>
        <Body>Depth / LiDAR: {capabilities ? (capabilities.depthOrLidarAvailable ? 'Supported by runtime' : 'Not supported') : 'Not checked'}</Body>
        {bridgeState === 'unavailable' ? (
          <Body dim>A supported native development build is required. Expo Go, browser previews, and OS identity alone cannot verify AR or depth.</Body>
        ) : null}
        {capabilities?.depthOrLidarAvailable ? (
          <Body dim>{providerName} device capability was queried after camera permission. The native session must still report stable tracking before sampling.</Body>
        ) : null}
        {bridgeState === 'available' && !(ArView && capabilities?.arSupported && capabilities.depthOrLidarAvailable) ? (
          <Btn
            testID="green-check-device"
            label={busy ? 'Checking device' : cameraPermission === 'granted' ? 'Check depth support' : 'Allow camera and check depth'}
            icon={busy ? 'loader' : 'camera'}
            disabled={busy}
            onPress={() => void checkPermissionAndDevice()}
          />
        ) : null}
        {cameraPermission === 'denied' && !canAskCameraAgain ? (
          <Btn variant="ghost" small label="Open device settings" icon="settings" onPress={() => void openDeviceSettings()} />
        ) : null}
        {error ? <Body dim>{error}</Body> : null}
      </Card>

      {ArView && capabilities?.arSupported && capabilities.depthOrLidarAvailable ? (
        <>
          <Card>
            <Label>Depth scan</Label>
            <Body>Keep the camera over one small patch of green. Tap five different spots spread across it. Only native depth/mesh hits with normal tracking are accepted.</Body>
            <Body dim>Accepted hits: {points.length} / {REQUIRED_POINTS} · depth-backed: {depthHits}</Body>
            <View style={{ height: 330, overflow: 'hidden', borderRadius: 14, borderWidth: 1, borderColor: T.border }}>
              <ArView
                ref={viewRef}
                style={{ flex: 1 }}
                planeDetection="horizontal"
                depthEnabled
                onReady={(event) => {
                  const liveCapabilities = event.nativeEvent.capabilities;
                  setCapabilities(liveCapabilities);
                  if (liveCapabilities.arSupported && liveCapabilities.depthOrLidarAvailable) {
                    setSessionReady(true);
                  } else {
                    setSessionReady(false);
                    setError('The live AR session did not confirm depth support. No surface reading is available.');
                  }
                }}
                onTrackingStateChange={(event) => {
                  setTracking(event.nativeEvent.state);
                }}
                onTap={(event) => {
                  void captureSurfacePoint(event.nativeEvent.x, event.nativeEvent.y);
                }}
                onError={(event) => {
                  setError(`${event.nativeEvent.code}: ${event.nativeEvent.message}`);
                }}
              />
              <View pointerEvents="none" style={{ position: 'absolute', inset: 0 }}>
                {points.map((point, index) => (
                  <View
                    key={`${point.capturedAt}-${index}`}
                    style={{
                      position: 'absolute',
                      left: point.screenX - 12,
                      top: point.screenY - 12,
                      width: 24,
                      height: 24,
                      borderRadius: 12,
                      alignItems: 'center',
                      justifyContent: 'center',
                      backgroundColor: T.gold,
                      borderWidth: 2,
                      borderColor: T.bg,
                    }}
                  >
                    <Text style={{ color: T.bg, fontFamily: F.b, fontSize: 11 }}>{index + 1}</Text>
                  </View>
                ))}
              </View>
            </View>
            <Body dim>Tracking: {tracking}. Samples are temporary and are not saved.</Body>
            {points.length > 0 ? (
              <Btn testID="green-reset-scan" variant="ghost" small label="Reset scan" icon="rotate-ccw" onPress={resetScan} />
            ) : null}
          </Card>
        </>
      ) : null}

      {reading ? (
        <Card gold>
          <Label>Measured local surface tilt</Label>
          <Text style={{ color: T.goldLight, fontFamily: F.b, fontSize: 38 }}>
            {reading.degrees.toFixed(2)}°
          </Text>
          <Body dim>Plane-fit residual: {(reading.fitResidualMetres * 1000).toFixed(0)} mm · point span: {reading.spanMetres.toFixed(2)} m</Body>
          <Body dim>Provenance: {providerName} {Platform.OS === 'ios' ? 'scene-mesh' : 'DepthPoint'} raycasts; {depthHits}/{REQUIRED_POINTS} depth/mesh hits; AR tracking was normal.</Body>
          <Body dim>Confidence: per-sample depth confidence is not exposed by this bridge. The plane-fit residual describes sample spread only; it is not sensor accuracy.</Body>
          <Body dim>The local AR frame is gravity-aligned but has no calibrated ball-to-hole axis. This is surface tilt only, not a putting-break direction or aim line.</Body>
          <Body dim>Captured {new Date(points[points.length - 1]?.capturedAt ?? Date.now()).toLocaleString()} · not saved</Body>
        </Card>
      ) : null}

      {ArView && capabilities?.arSupported && capabilities.depthOrLidarAvailable && !sessionReady ? (
        <Card>
          <Label>Starting native session</Label>
          <Body dim>Waiting for {providerName} to report a ready session and normal tracking. No measurements are shown until then.</Body>
        </Card>
      ) : null}

      {cameraPermission === 'denied' ? (
        <Card>
          <Label>Camera access denied</Label>
          <Body dim>Camera permission is separate from AR/depth hardware support. The device capability remains unverified until access is granted.</Body>
        </Card>
      ) : null}

      <Card>
        <Label>Measurement limits</Label>
        <Body dim>No GPS altitude, phone-only tilt, simulated sample, or inferred putting break is used. If the native bridge reports no depth/mesh hit or loses tracking, the scan stays incomplete.</Body>
        <Body dim>The bridge does not expose ARCore's provider version or per-point confidence; those values are not guessed.</Body>
      </Card>
    </Screen>
  );
}