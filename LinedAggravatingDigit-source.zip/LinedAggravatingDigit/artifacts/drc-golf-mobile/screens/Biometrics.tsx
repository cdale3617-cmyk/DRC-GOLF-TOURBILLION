import React, { useCallback, useEffect, useState } from 'react';
import { Text, View } from 'react-native';
import { Body, Btn, Card, F, Label, Screen } from '@/components/ui';
import { T } from '@/constants/colors';
import {
  HealthIntegrationState,
  HealthMetricResult,
  inspectHealthIntegration,
  openHealthConnectProviderSettings,
  requestHealthReadAccess,
} from '@/lib/health-integrations';

function providerLabel(status: HealthIntegrationState['provider']): string {
  switch (status) {
    case 'checking': return 'Checking';
    case 'available': return 'Available';
    case 'not-installed': return 'Not installed';
    case 'update-required': return 'Update required';
    case 'unavailable': return 'Unavailable';
    case 'bridge-unavailable': return 'Native bridge unavailable';
    case 'unsupported': return 'Native build required';
  }
}

function consentLabel(status: HealthIntegrationState['consent']): string {
  switch (status) {
    case 'not-requested': return 'No readable access detected';
    case 'granted': return 'Read access granted';
    case 'partial': return 'Some read access granted';
    case 'denied': return 'Permission denied';
    case 'read-status-hidden': return 'HealthKit hides read-access status';
    case 'unavailable': return 'Consent unavailable';
  }
}

function metricStatusLabel(status: HealthMetricResult['status']): string {
  switch (status) {
    case 'not-requested': return 'Not read';
    case 'permission-denied': return 'Permission denied';
    case 'no-samples': return 'No samples';
    case 'unavailable': return 'Data type unavailable';
    case 'available': return 'Current sample';
    case 'stale': return 'Stale sample';
    case 'error': return 'Read failed';
  }
}

function MetricCard({
  title,
  metric,
}: {
  title: string;
  metric: HealthMetricResult;
}) {
  const sample = metric.sample;
  const value = sample
    ? `${new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 }).format(sample.value)} ${sample.unit}`
    : metricStatusLabel(metric.status);
  return (
    <Card>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
        <Label>{title}</Label>
        <Text style={{ color: metric.status === 'stale' ? T.goldLight : T.muted, fontFamily: F.s, fontSize: 11 }}>
          {metricStatusLabel(metric.status)}
        </Text>
      </View>
      <Text style={{ color: sample ? T.goldLight : T.text, fontFamily: F.b, fontSize: 25 }}>
        {value}
      </Text>
      {sample ? (
        <>
          <Body dim>Measured {new Date(sample.measuredAt).toLocaleString()}</Body>
          <Body dim>Source: {sample.source}{sample.device ? ` · ${sample.device}` : ''}</Body>
          <Body dim>Confidence: {sample.confidence}</Body>
        </>
      ) : (
        <Body dim>{metric.detail ?? 'Connect a health provider and allow this specific read type to see its actual samples.'}</Body>
      )}
    </Card>
  );
}

export function Biometrics() {
  const [state, setState] = useState<HealthIntegrationState | null>(null);
  const [busy, setBusy] = useState(false);
  const [hasRead, setHasRead] = useState(false);

  const inspect = useCallback(async () => {
    setBusy(true);
    try {
      setState(await inspectHealthIntegration());
    } finally {
      setBusy(false);
    }
  }, []);

  useEffect(() => {
    void inspect();
  }, [inspect]);

  const connect = async () => {
    setBusy(true);
    try {
      setState(await requestHealthReadAccess());
      setHasRead(true);
    } finally {
      setBusy(false);
    }
  };

  const canRequest = state?.bridge === 'available' && state.provider === 'available';
  return (
    <Screen back guide="biometrics" eyebrow="Records" title="Biometrics">
      <Card gold>
        <Label>Health data connection</Label>
        <Body>Health readings are not fingerprint or face sign-in. Nothing is read until you choose to request access.</Body>
        <View style={{ gap: 5 }}>
          <Body dim>Native bridge: {state ? (state.bridge === 'available' ? 'Available' : 'Unavailable') : 'Checking'}</Body>
          <Body dim>Provider: {state ? providerLabel(state.provider) : 'Checking'}</Body>
          {state ? <Body dim>{state.providerDetail}</Body> : null}
          <Body dim>Consent: {state ? consentLabel(state.consent) : 'Checking'}</Body>
          {state?.healthTypes ? (
            <>
              <Body dim>HealthKit heart-rate type: {state.healthTypes.heartRate}</Body>
              <Body dim>HealthKit step-count type: {state.healthTypes.steps}</Body>
            </>
          ) : null}
        </View>
        {state?.error ? <Body dim>Read error: {state.error}</Body> : null}
        {canRequest ? (
          <Btn
            testID="health-connect"
            label={busy ? 'Checking health data' : hasRead ? 'Refresh health data' : 'Connect health data'}
            icon={busy ? 'loader' : 'heart'}
            disabled={busy}
            onPress={connect}
          />
        ) : null}
        {state?.provider === 'bridge-unavailable' || state?.provider === 'unsupported' ? (
          <Body dim>A supported native development build is required. Expo Go and browser previews cannot verify these native integrations.</Body>
        ) : null}
        {state?.provider === 'not-installed' ? (
          <Body dim>Install or enable Health Connect on the device, then check again.</Body>
        ) : null}
        {state?.provider === 'update-required' ? (
          <Body dim>Update the Health Connect provider, then check again.</Body>
        ) : null}
        {state?.consent === 'read-status-hidden' ? (
          <Body dim>Apple does not reveal whether an app has HealthKit read permission. An empty query can mean no samples or hidden read access.</Body>
        ) : null}
        {state?.platform === 'android' && (state.consent === 'denied' || state.consent === 'partial') ? (
          <Btn
            variant="ghost"
            small
            label="Manage Health Connect access"
            icon="settings"
            onPress={() => {
              void openHealthConnectProviderSettings().catch((error: unknown) => {
                setState((current) => current ? {
                  ...current,
                  error: error instanceof Error ? error.message : 'Could not open Health Connect settings.',
                } : current);
              });
            }}
          />
        ) : null}
      </Card>

      {state?.provider === 'available' ? (
        <>
          <MetricCard title="Heart rate" metric={state.heartRate} />
          <MetricCard title="Steps" metric={state.steps} />
          <Card>
            <Label>Data handling</Label>
            <Body dim>Only heart-rate and step samples are requested. Measurements stay on this screen; no readiness, calories, or pulse values are inferred from missing data.</Body>
            <Body dim>Providers do not supply a confidence score for these readings, so the app does not invent one.</Body>
            {state.platform === 'android' ? (
              <Body dim>A hardware or data source is confirmed only when Health Connect returns a real record. The app does not infer a heart-rate sensor from the phone model or operating system.</Body>
            ) : null}
          </Card>
        </>
      ) : null}
      <Btn
        testID="health-recheck"
        variant="ghost"
        small
        label="Check provider again"
        icon="refresh-cw"
        disabled={busy}
        onPress={() => void inspect()}
      />
    </Screen>
  );
}