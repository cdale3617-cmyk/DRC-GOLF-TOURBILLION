import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import CapturePanel from '@/components/CapturePanel';
import { useApp } from '@/context/AppContext';
import { Card, Empty, F, Label, Screen, confirmAction } from '@/components/ui';
import { T } from '@/constants/colors';

function CaptureScreen({ title, kind, guide, limitation }: { title: string; kind: string; guide: string; limitation: string }) {
  const { captures, addCapture, deleteCapture } = useApp();
  const mine = captures.filter((c) => c.kind === kind);
  return (
    <Screen back guide={guide} eyebrow="Lab" title={title}>
      <Card gold>
        <Label>Analysis status</Label>
        <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 13, lineHeight: 19 }}>{limitation}</Text>
      </Card>
      <CapturePanel title={title} kind={kind} onSave={(r) => addCapture(r)} />
      {!mine.length ? <Empty icon="video" title="No captures saved" text="Clips you capture or import are listed here by date." /> : (
        <Card>
          <Label>Saved captures</Label>
          {mine.map((c) => (
            <View key={c.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, borderTopWidth: 1, borderTopColor: T.border, paddingTop: 8 }}>
              <Feather name="film" size={16} color={T.gold} />
              <View style={{ flex: 1 }}>
                <Text style={{ color: T.text, fontFamily: F.s, fontSize: 13 }}>{new Date(c.recordedAt).toLocaleString()}</Text>
                <Text numberOfLines={1} style={{ color: T.muted, fontFamily: F.r, fontSize: 11 }}>{c.uri}</Text>
              </View>
              <Pressable testID={`delete-capture-${c.id}`} hitSlop={10} onPress={() => confirmAction('Delete capture', 'Remove this capture record? The file itself is not deleted.', () => deleteCapture(c.id))}>
                <Feather name="trash-2" size={16} color={T.muted} />
              </Pressable>
            </View>
          ))}
        </Card>
      )}
    </Screen>
  );
}
export const Tracer = () => <CaptureScreen title="Shot Tracer" kind="tracer" guide="tracer" limitation="Capture and import work. Ball-flight tracing analysis is not connected, so no trace is drawn or inferred." />;
export const SwingMonitor = () => <CaptureScreen title="Swing Monitor" kind="swing" guide="swing" limitation="Capture and import work. Kinetics analysis and sensors are not connected, so no tempo, speed or sequence values are shown." />;
