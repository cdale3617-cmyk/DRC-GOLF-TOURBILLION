import React, { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { useApp } from '@/context/AppContext';
import { Btn, Card, Chips, Empty, F, Label, Row, Screen, Stat, confirmAction } from '@/components/ui';
import { fmtToPar, roundTotals } from '@/lib/stats';
import { fmtDate } from '@/lib/units';
import { openTool } from '@/lib/tools';
import type { Round } from '@/lib/types';
import { T } from '@/constants/colors';

const opts = (rs: Round[]) => rs.map((r) => ({ value: r.id, label: `${r.courseName} ${fmtDate(r.startedAt)}` }));

export function History() {
  const { rounds, deleteRound } = useApp();
  return (
    <Screen back guide="history" eyebrow="Records" title="Round History">
      {!rounds.length ? <Empty icon="clock" title="No rounds recorded" text="Completed and active rounds appear here." action={<Btn testID="history-start" label="Start a round" onPress={() => openTool('preround')} />} /> : null}
      {rounds.map((r) => {
        const t = roundTotals(r);
        return (
          <Card key={r.id}>
            <Pressable testID={`round-${r.id}`} onPress={() => openTool('overview', { rid: r.id })} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ color: T.text, fontFamily: F.b, fontSize: 16 }}>{r.courseName}</Text>
                <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 12 }}>{fmtDate(r.startedAt)} - {r.endedAt ? 'completed' : 'in progress'} - {t.played}/{r.holes.length} holes</Text>
              </View>
              <Text style={{ color: T.goldLight, fontFamily: F.b, fontSize: 22 }}>{t.played ? `${t.strokes}` : '--'}</Text>
            </Pressable>
            <Row>
              <Btn small variant="ghost" testID={`card-${r.id}`} label="Scorecard" icon="edit-3" onPress={() => openTool('scorecard', { rid: r.id })} />
              <Btn small variant="danger" testID={`del-round-${r.id}`} label="Delete" icon="trash-2" onPress={() => confirmAction('Delete round', 'Permanently remove this round?', () => deleteRound(r.id))} />
            </Row>
          </Card>
        );
      })}
    </Screen>
  );
}

export function Overview({ rid }: { rid?: string }) {
  const { rounds } = useApp();
  const [sel, setSel] = useState<string | undefined>(rid);
  const round = rounds.find((r) => r.id === (sel ?? rounds[0]?.id));
  if (!round) return <Screen back guide="overview" eyebrow="Records" title="Round Overview"><Empty icon="layers" title="No rounds recorded" text="Record a round to see its overview." /></Screen>;
  const t = roundTotals(round);
  const half = (hs: Round['holes']) => {
    const sc = hs.filter((h) => round.scores[h.number]?.strokes != null);
    return sc.length ? `${sc.reduce((s, h) => s + (round.scores[h.number].strokes ?? 0), 0)} (${sc.length} holes)` : '--';
  };
  const scored = round.holes.filter((h) => round.scores[h.number]?.strokes != null).map((h) => ({ h, d: (round.scores[h.number].strokes ?? 0) - h.par }));
  const bestH = scored.length ? scored.reduce((a, b) => (b.d < a.d ? b : a)) : null;
  const worstH = scored.length ? scored.reduce((a, b) => (b.d > a.d ? b : a)) : null;
  return (
    <Screen back guide="overview" eyebrow="Records" title="Round Overview">
      {rounds.length > 1 ? <Chips testID="overview-pick" options={opts(rounds)} value={round.id} onChange={setSel} /> : null}
      <Card gold>
        <Text style={{ color: T.text, fontFamily: F.b, fontSize: 18 }}>{round.courseName}</Text>
        <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 12 }}>{fmtDate(round.startedAt)} - {round.endedAt ? 'completed' : 'in progress'}</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 14 }}>
          <Stat label="Strokes" value={t.played ? `${t.strokes}` : '--'} sub={t.played ? `${fmtToPar(t.toPar)} vs par ${t.par}` : undefined} />
          <Stat label="Putts" value={`${t.putts}`} />
          <Stat label="Penalties" value={`${t.penalties}`} />
          <Stat label="Front" value={half(round.holes.slice(0, 9))} />
          <Stat label="Back" value={half(round.holes.slice(9))} />
        </View>
      </Card>
      <Card>
        <Label>Highlights</Label>
        <Text style={{ color: T.text, fontFamily: F.m, fontSize: 14 }}>Best hole: {bestH ? `${bestH.h.number} (${fmtToPar(bestH.d)})` : 'none scored'}</Text>
        <Text style={{ color: T.text, fontFamily: F.m, fontSize: 14 }}>Hardest hole: {worstH ? `${worstH.h.number} (${fmtToPar(worstH.d)})` : 'none scored'}</Text>
        <Btn testID="overview-card" variant="ghost" label="Open scorecard" icon="edit-3" onPress={() => openTool('scorecard', { rid: round.id })} />
      </Card>
    </Screen>
  );
}

export function Compare() {
  const { rounds } = useApp();
  const [a, setA] = useState<string | undefined>();
  const [b, setB] = useState<string | undefined>();
  if (rounds.length < 2) return <Screen back guide="compare" eyebrow="Records" title="Score Comparison"><Empty icon="bar-chart-2" title="Two rounds needed" text={`You have ${rounds.length} recorded round${rounds.length === 1 ? '' : 's'}. Comparison uses only your records.`} /></Screen>;
  const ra = rounds.find((r) => r.id === (a ?? rounds[0].id))!;
  const rb = rounds.find((r) => r.id === (b ?? rounds[1].id))!;
  const ta = roundTotals(ra), tb = roundTotals(rb);
  const n = Math.max(ra.holes.length, rb.holes.length);
  const cell = (r: Round, i: number) => r.scores[i + 1]?.strokes;
  return (
    <Screen back guide="compare" eyebrow="Records" title="Score Comparison">
      <Label>Round A</Label>
      <Chips testID="cmp-a" options={opts(rounds)} value={ra.id} onChange={setA} />
      <Label>Round B</Label>
      <Chips testID="cmp-b" options={opts(rounds)} value={rb.id} onChange={setB} />
      <Card gold>
        {([['Strokes', ta.played ? ta.strokes : null, tb.played ? tb.strokes : null], ['To par', ta.played ? ta.toPar : null, tb.played ? tb.toPar : null], ['Putts', ta.putts, tb.putts], ['Penalties', ta.penalties, tb.penalties]] as const).map(([l, x, y]) => (
          <View key={l} style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ color: T.muted, fontFamily: F.m, width: 90 }}>{l}</Text>
            <Text style={{ color: T.goldLight, fontFamily: F.b, flex: 1, textAlign: 'center' }}>{x == null ? '--' : l === 'To par' ? fmtToPar(x) : x}</Text>
            <Text style={{ color: T.goldLight, fontFamily: F.b, flex: 1, textAlign: 'center' }}>{y == null ? '--' : l === 'To par' ? fmtToPar(y) : y}</Text>
          </View>
        ))}
      </Card>
      <Card>
        <Label>Hole by hole (strokes, A / B / difference)</Label>
        {Array.from({ length: n }, (_, i) => {
          const x = cell(ra, i), y = cell(rb, i);
          return (
            <View key={i} style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ color: T.muted, fontFamily: F.m, width: 50 }}>{i + 1}</Text>
              <Text style={{ color: T.text, fontFamily: F.m, flex: 1, textAlign: 'center' }}>{x ?? '--'}</Text>
              <Text style={{ color: T.text, fontFamily: F.m, flex: 1, textAlign: 'center' }}>{y ?? '--'}</Text>
              <Text style={{ color: T.goldLight, fontFamily: F.s, width: 40, textAlign: 'right' }}>{x != null && y != null ? fmtToPar(x - y) : ''}</Text>
            </View>
          );
        })}
      </Card>
    </Screen>
  );
}
