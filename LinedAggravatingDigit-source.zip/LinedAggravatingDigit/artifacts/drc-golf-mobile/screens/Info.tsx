import React, { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useApp } from '@/context/AppContext';
import { Btn, Card, Chips, Field, F, Label, Body, Screen, Stat, confirmAction } from '@/components/ui';
import { GUIDES } from '@/lib/guides';
import { T } from '@/constants/colors';

export { Biometrics } from './Biometrics';
export { GreenReading } from './GreenReading';

export function ProfileScreen() {
  const { profile, setName, setUnits, courses, rounds, clubs, shots, captures, resetAll } = useApp();
  const [n, setN] = useState(profile.name);
  return (
    <Screen back guide="profile" eyebrow="Setup" title="Profile">
      <Card>
        <Field testID="profile-name" label="Name" value={n} onChangeText={setN} />
        <Btn testID="profile-save" small variant="ghost" label="Save name" icon="check" onPress={() => setName(n.trim())} />
      </Card>
      <Card>
        <Label>Distance units</Label>
        <Chips testID="units" options={[{ value: 'm', label: 'Metres' }, { value: 'yd', label: 'Yards' }]} value={profile.units} onChange={setUnits} />
        <Body dim>Records are stored in metres and converted for display and input. Switching never alters them.</Body>
      </Card>
      <Card>
        <Label>On this device</Label>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
          <Stat label="Courses" value={`${courses.length}`} /><Stat label="Rounds" value={`${rounds.length}`} />
          <Stat label="Clubs" value={`${clubs.length}`} /><Stat label="Shots" value={`${shots.length}`} /><Stat label="Captures" value={`${captures.length}`} />
        </View>
        <Btn testID="reset-all" variant="danger" label="Erase all records" icon="trash-2" onPress={() => confirmAction('Erase all records', 'Removes every course, round, club, shot and capture record. Profile is kept.', resetAll)} />
      </Card>
    </Screen>
  );
}

export function HowTo({ topic }: { topic?: string }) {
  const [open, setOpen] = useState<string | undefined>(topic ?? GUIDES[0].id);
  return (
    <Screen back eyebrow="Setup" title="How To">
      {GUIDES.map((g) => {
        const on = open === g.id;
        return (
          <Card key={g.id} gold={on}>
            <Pressable testID={`guide-${g.id}`} onPress={() => setOpen(on ? undefined : g.id)} style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text style={{ flex: 1, color: T.text, fontFamily: F.b, fontSize: 16 }}>{g.title}</Text>
              <Feather name={on ? 'chevron-up' : 'chevron-down'} size={18} color={T.muted} />
            </Pressable>
            {on ? (
              <View style={{ gap: 8 }}>
                <Body>{g.what}</Body>
                <Label>Steps</Label>
                {g.steps.map((s, i) => <Body key={i} dim>{`${i + 1}. ${s}`}</Body>)}
                <Label>Limitations</Label>
                {g.limits.map((s, i) => <Body key={i} dim>{`- ${s}`}</Body>)}
              </View>
            ) : null}
          </Card>
        );
      })}
    </Screen>
  );
}
