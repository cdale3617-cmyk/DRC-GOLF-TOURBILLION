import React from 'react';
import { Text, View } from 'react-native';
import { useApp } from '@/context/AppContext';
import { Card, Label, Screen, Stat } from '@/components/ui';
import ShotForm from '@/components/ShotForm';
import ShotList from '@/components/ShotList';
import { dispersion } from '@/lib/stats';
import { fmtDist } from '@/lib/units';
import type { ShotContext } from '@/lib/types';
import { T } from '@/constants/colors';

function Practice({ title, guide, contexts, showSwing, showHoled, label, blurb }: {
  title: string; guide: string; contexts: ShotContext[]; showSwing?: boolean; showHoled?: boolean; label: string; blurb: string;
}) {
  const { shots, profile } = useApp();
  const mine = shots.filter((s) => contexts.includes(s.context));
  const d = dispersion(mine);
  const holed = mine.filter((s) => s.holed).length;
  return (
    <Screen back guide={guide} eyebrow="Lab" title={title}>
      <Card gold>
        <Text style={{ color: T.muted, fontSize: 13, lineHeight: 19 }}>{blurb}</Text>
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <Stat label="Recorded" value={`${d.n}`} />
          <Stat label="Average" value={fmtDist(d.meanDist ?? undefined, profile.units, 1)} />
          {showHoled ? <Stat label="Holed" value={d.n ? `${holed}/${d.n}` : '--'} sub={d.n ? `${((holed / d.n) * 100).toFixed(1)}%` : undefined} /> : <Stat label="Offset sd" value={d.sdLat != null ? fmtDist(d.sdLat, profile.units, 1) : '--'} />}
        </View>
      </Card>
      <Card>
        <Label>Log a session entry</Label>
        <ShotForm contexts={contexts} showSwingLength={showSwing} showHoled={showHoled} distanceLabel={label} />
      </Card>
      <ShotList shots={mine} limit={12} />
    </Screen>
  );
}

export const Putting = () => <Practice title="Putting Practice" guide="putting" contexts={['putt']} showHoled label="Putt length" blurb="Log each putt you hit with the length you measured. Make rate is computed from your attempts only." />;
export const ShortGame = () => <Practice title="Short Game" guide="shortgame" contexts={['wedge', 'chip']} showSwing label="Distance" blurb="Log pitches, wedges and chips with the distance you measured and any lateral miss." />;
export const Chipping = () => <Practice title="Greenside Chipping" guide="chipping" contexts={['chip']} label="Chip distance" blurb="Log chips around the green. Lateral offset is optional and entered by you." />;
