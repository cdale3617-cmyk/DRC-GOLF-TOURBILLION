import React, { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useApp } from '@/context/AppContext';
import { Btn, Card, Chips, Empty, ErrorText, F, Field, Label, Row, Screen, Sheet, confirmAction } from '@/components/ui';
import { fmtDist, fromDisp, parseNum, toDisp, unitLabel } from '@/lib/units';
import type { Course, HoleDef } from '@/lib/types';
import { T } from '@/constants/colors';

interface Draft { par: string; len: string; lat: string; lon: string }
const blank = (): Draft => ({ par: '4', len: '', lat: '', lon: '' });

export default function Courses() {
  const { courses, profile, saveCourse, deleteCourse } = useApp();
  const u = profile.units;
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<string | undefined>();
  const [name, setName] = useState('');
  const [count, setCount] = useState<'9' | '18'>('18');
  const [drafts, setDrafts] = useState<Draft[]>([]);
  const [err, setErr] = useState('');

  const setN = (n: '9' | '18', cur: Draft[]) => {
    setCount(n);
    const k = Number(n);
    setDrafts(Array.from({ length: k }, (_, i) => cur[i] ?? blank()));
  };
  const openNew = () => { setEditId(undefined); setName(''); setErr(''); setN('18', []); setOpen(true); };
  const openEdit = (c: Course) => {
    setEditId(c.id); setName(c.name); setErr('');
    setCount(c.holes.length === 9 ? '9' : '18');
    setDrafts(c.holes.map((h) => ({
      par: String(h.par), len: h.lengthM != null ? toDisp(h.lengthM, u).toFixed(0) : '',
      lat: h.pin ? String(h.pin.latitude) : '', lon: h.pin ? String(h.pin.longitude) : '',
    })));
    setOpen(true);
  };
  const upd = (i: number, k: keyof Draft, v: string) => setDrafts((d) => d.map((x, j) => (j === i ? { ...x, [k]: v } : x)));

  const save = () => {
    if (!name.trim()) { setErr('Course name is required.'); return; }
    const holes: HoleDef[] = [];
    for (let i = 0; i < drafts.length; i++) {
      const d = drafts[i];
      const par = parseNum(d.par);
      if (par == null || !Number.isInteger(par) || par < 3 || par > 6) { setErr(`Hole ${i + 1}: par must be 3 to 6.`); return; }
      const len = parseNum(d.len);
      if (d.len.trim() && (len == null || len <= 0)) { setErr(`Hole ${i + 1}: length must be positive.`); return; }
      const lat = parseNum(d.lat), lon = parseNum(d.lon);
      if ((d.lat.trim() || d.lon.trim()) && (lat == null || lon == null || Math.abs(lat) > 90 || Math.abs(lon) > 180)) {
        setErr(`Hole ${i + 1}: enter both a valid latitude and longitude, or neither.`); return;
      }
      holes.push({ number: i + 1, par, lengthM: len == null ? undefined : fromDisp(len, u), pin: lat != null && lon != null ? { latitude: lat, longitude: lon } : undefined });
    }
    saveCourse({ id: editId, name: name.trim(), holes });
    setOpen(false);
  };

  return (
    <Screen back guide="courses" eyebrow="Setup" title="Courses"
      right={<Pressable testID="add-course" onPress={openNew} hitSlop={10}><Feather name="plus-circle" size={28} color={T.gold} /></Pressable>}>
      {!courses.length ? (
        <Empty icon="map" title="No courses yet" text="Enter a course by hand: par per hole, plus optional lengths and pin coordinates."
          action={<Btn testID="add-course-empty" label="Create course" icon="plus" onPress={openNew} />} />
      ) : null}
      {courses.map((c) => {
        const len = c.holes.reduce((s, h) => s + (h.lengthM ?? 0), 0);
        const allLen = c.holes.every((h) => h.lengthM != null);
        return (
          <Card key={c.id}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ color: T.text, fontFamily: F.b, fontSize: 17 }}>{c.name}</Text>
                <Text style={{ color: T.muted, fontFamily: F.r, fontSize: 12 }}>
                  {c.holes.length} holes - par {c.holes.reduce((s, h) => s + h.par, 0)}
                  {allLen ? ` - ${fmtDist(len, u)}` : ' - lengths incomplete'}
                  {` - ${c.holes.filter((h) => h.pin).length} pins`}
                </Text>
              </View>
              <Pressable testID={`edit-course-${c.id}`} onPress={() => openEdit(c)} hitSlop={10}><Feather name="edit-2" size={17} color={T.goldLight} /></Pressable>
              <Pressable testID={`delete-course-${c.id}`} hitSlop={10} onPress={() => confirmAction('Delete course', `Remove ${c.name}? Recorded rounds are kept.`, () => deleteCourse(c.id))}>
                <Feather name="trash-2" size={17} color={T.muted} />
              </Pressable>
            </View>
          </Card>
        );
      })}
      <Sheet visible={open} title={editId ? 'Edit course' : 'New course'} onClose={() => setOpen(false)}>
        <Field testID="course-name" label="Course name" value={name} onChangeText={setName} />
        <Chips testID="course-count" options={[{ value: '9', label: '9 holes' }, { value: '18', label: '18 holes' }]} value={count} onChange={(n) => setN(n, drafts)} />
        {drafts.map((d, i) => (
          <View key={i} style={{ gap: 8, borderTopWidth: 1, borderTopColor: T.border, paddingTop: 10 }}>
            <Label>{`Hole ${i + 1}`}</Label>
            <Row>
              <Field testID={`hole-${i + 1}-par`} label="Par" value={d.par} onChangeText={(v) => upd(i, 'par', v)} keyboardType="number-pad" />
              <Field testID={`hole-${i + 1}-len`} label="Length" value={d.len} onChangeText={(v) => upd(i, 'len', v)} keyboardType="decimal-pad" suffix={unitLabel(u)} />
            </Row>
            <Row>
              <Field testID={`hole-${i + 1}-lat`} label="Pin lat (optional)" value={d.lat} onChangeText={(v) => upd(i, 'lat', v)} keyboardType="numbers-and-punctuation" />
              <Field testID={`hole-${i + 1}-lon`} label="Pin lon (optional)" value={d.lon} onChangeText={(v) => upd(i, 'lon', v)} keyboardType="numbers-and-punctuation" />
            </Row>
          </View>
        ))}
        <ErrorText>{err}</ErrorText>
        <Btn testID="course-save" label={editId ? 'Save course' : 'Create course'} icon="check" onPress={save} />
      </Sheet>
    </Screen>
  );
}
