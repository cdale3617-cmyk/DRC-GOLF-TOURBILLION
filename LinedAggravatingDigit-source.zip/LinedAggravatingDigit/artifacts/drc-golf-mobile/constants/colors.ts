export const T = {
  bg: '#05110c',
  surface: '#0b1f16',
  surface2: '#11291d',
  border: '#1f3b2d',
  gold: '#c9a24b',
  goldLight: '#e8d296',
  goldDeep: '#7d6425',
  text: '#eee9d8',
  muted: '#8ea597',
  red: '#b5432f',
  green: '#1e5a3f',
};

const palette = {
  text: T.text,
  tint: T.gold,
  background: T.bg,
  foreground: T.text,
  card: T.surface,
  cardForeground: T.text,
  primary: T.gold,
  primaryForeground: T.bg,
  secondary: T.surface2,
  secondaryForeground: T.text,
  muted: T.surface2,
  mutedForeground: T.muted,
  accent: T.surface2,
  accentForeground: T.goldLight,
  destructive: T.red,
  destructiveForeground: T.text,
  border: T.border,
  input: T.border,
};

const colors = { light: palette, radius: 14 };
export default colors;
