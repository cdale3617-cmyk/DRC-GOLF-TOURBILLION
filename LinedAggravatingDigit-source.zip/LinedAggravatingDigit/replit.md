# DRC Golf Tourbillion — Mobile Foundation

A separate Android-first, native-capable premium golf caddie and golf-lab app. The approved Base44 web master must remain unchanged.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

_Populate as you build — short repo map plus pointers to the source-of-truth file for DB schema, API contracts, theme files, etc._

## Architecture decisions

_Populate as you build — non-obvious choices a reader couldn't infer from the code (3-5 bullets)._

## Product

The mobile product covers caddie and round management, bag/equipment, measured practice, video capture, course records, profile and guides. Device integration status must be truthful: a video recording is not swing analysis, a GPS fix is not surveyed course geometry, and unconnected health or AR/depth bridges must never generate readings.

## User preferences

- Preserve the approved racing-green/black depth, polished metallic-gold identity and restrained red accents. Do not redesign approved screens for novelty.
- Metres are the default, with a yards option.
- Live Hole should emphasize a large tall hole view on the left and compact controls on the right where screen width permits.
- Do not fake sensors, camera-analysis, biometrics, depth, AR, or shot-dispersion data.

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
- Mobile native integration boundaries: `artifacts/drc-golf-mobile/docs/DEVICE-INTEGRATION.md`
- Later physical Android testing: `artifacts/drc-golf-mobile/docs/ANDROID-DEVICE-CHECKLIST.md`
